package com.prodevans.assessmenttool.resolver.mutation

import com.coxautodev.graphql.tools.GraphQLMutationResolver
import com.prodevans.assessmenttool.model.Answer
import com.prodevans.assessmenttool.model.Option
import com.prodevans.assessmenttool.repository.AnswerRepository
import com.prodevans.assessmenttool.repository.OptionRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component

@Component
class AnswerMutationResolver(
    private val answerRepository: AnswerRepository,
    private val optionRepository: OptionRepository,
    private val getValues: GetValues
): GraphQLMutationResolver {


    fun newAnswer(submissionId: Int, questionId: Int, group: String, score: Float, selectedOptions: List<Int>): Answer {
        val answer = Answer(submissionId,  questionId, group, score)
        answer.id = getValues.getSequence("answer")
        val answerList: ArrayList<Option> = arrayListOf()
        selectedOptions.forEach { opt -> answerList.add(optionRepository.findById(opt).get()) }
        answer.options = answerList
        answerRepository.save(answer)
        return answer
    }
}