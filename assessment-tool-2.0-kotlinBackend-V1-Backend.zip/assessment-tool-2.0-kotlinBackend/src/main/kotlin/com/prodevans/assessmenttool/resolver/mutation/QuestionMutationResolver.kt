package com.prodevans.assessmenttool.resolver.mutation

import com.coxautodev.graphql.tools.GraphQLMutationResolver
import com.prodevans.assessmenttool.model.Question
import com.prodevans.assessmenttool.repository.QuestionRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component

@Component
class QuestionMutationResolver (
    private val questionRepository: QuestionRepository,
    private val getValues: GetValues
): GraphQLMutationResolver {
    fun newQuestion(assessmentId: Int, value: String, type: String, group: String): Question {
        val question = Question(assessmentId, value, type, group)
        question.id = getValues.getSequence("question")
        questionRepository.save(question)
        return question
    }

    fun deleteQuestion(id: Int) : Boolean {
        questionRepository.deleteById(id)
        return true
    }

    fun updateQuestion(id: Int, value: String, type: String, group: String) : Question {
        val question = questionRepository.findById(id)
        question.ifPresent {
            if (value.isNotEmpty()) it.value = value
            if (type.isNotEmpty()) it.type = type
            if (group.isNotEmpty()) it.group = group
            questionRepository.save(it)
        }
        return question.get()
    }
}
