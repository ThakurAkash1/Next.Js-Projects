package com.prodevans.assessmenttool.utility

import com.prodevans.assessmenttool.model.Answer
import com.prodevans.assessmenttool.model.Option
import com.prodevans.assessmenttool.model.Question
import com.prodevans.assessmenttool.model.Sequencer
import com.prodevans.assessmenttool.repository.SequencerRepository
import org.springframework.data.mongodb.core.MongoOperations
import org.springframework.data.mongodb.core.query.Criteria
import org.springframework.data.mongodb.core.query.Query
import org.springframework.stereotype.Component

@Component
class GetValues(
    private val mongoOperations: MongoOperations,
    private val sequencerRepository: SequencerRepository
) {

    fun questions(key: String, assessmentId: Int): List<Question> {
        val query = Query()
        query.addCriteria(Criteria.where(key).`is`(assessmentId))
        return mongoOperations.find(query, Question::class.java)
    }

    fun answers(key: String, submissionId: Int): List<Answer> {
        val query = Query()
        query.addCriteria(Criteria.where(key).`is`(submissionId))
        return mongoOperations.find(query, Answer::class.java)
    }

    fun options(key: String, questionId: Int): List<Option> {
        val query = Query()
        query.addCriteria(Criteria.where(key).`is`(questionId))
        return mongoOperations.find(query, Option::class.java)
    }

    fun getSequence(id: String): Int {
        val sequencerList = sequencerRepository.findById(id)
        return if (sequencerList.isEmpty) {
            val sequence = Sequencer(1)
            sequence.id = id
            sequencerRepository.save(sequence)
            sequence.value
        } else {
            val sequence = sequencerList.get()
            sequence.value += 1
            sequencerRepository.save(sequence)
            sequence.value
        }
    }
}