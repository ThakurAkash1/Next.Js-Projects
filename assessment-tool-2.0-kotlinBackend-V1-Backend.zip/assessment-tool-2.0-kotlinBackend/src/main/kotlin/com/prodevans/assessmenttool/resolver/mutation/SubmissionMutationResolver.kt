package com.prodevans.assessmenttool.resolver.mutation

import com.coxautodev.graphql.tools.GraphQLMutationResolver
import com.prodevans.assessmenttool.model.AssessmentStatus
import com.prodevans.assessmenttool.model.Submission
import com.prodevans.assessmenttool.model.SubmissionStatus
import com.prodevans.assessmenttool.repository.SubmissionRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Component
class SubmissionMutationResolver(
    private val submissionRepository: SubmissionRepository,
    private val getValues: GetValues
): GraphQLMutationResolver {

    val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

    fun newSubmission(assessmentId: Int, userId: Int,userName: String, userEmail: String, userRole: String, status: Int, totalScore: Float): Submission {
        val submission = Submission(assessmentId, userId,userName,userEmail,userRole, SubmissionStatus.values()[status], totalScore, LocalDateTime.now().format(formatter))
        submission.id = getValues.getSequence("submission")
        submissionRepository.save(submission)
        return submission
    }

    fun updateSubmission(id: Int, status: Int, totalScore: Float, selectedOptions: List<Int>): Submission {
        val submission = submissionRepository.findById(id)
        submission.ifPresent { sub ->
            sub.status = SubmissionStatus.values()[status]
            sub.totalScore = totalScore
            sub.time = LocalDateTime.now().format(formatter)
            submissionRepository.save(sub)
        }
        return submission.get()
    }
}