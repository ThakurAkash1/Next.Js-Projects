package com.prodevans.assessmenttool.repository

import com.prodevans.assessmenttool.model.Sequencer
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface SequencerRepository : MongoRepository<Sequencer, String> {
}