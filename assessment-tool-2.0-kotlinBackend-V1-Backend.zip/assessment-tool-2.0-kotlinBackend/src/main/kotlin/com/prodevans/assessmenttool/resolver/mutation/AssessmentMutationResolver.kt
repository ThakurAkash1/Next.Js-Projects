package com.prodevans.assessmenttool.resolver.mutation

import com.coxautodev.graphql.tools.GraphQLMutationResolver
import com.prodevans.assessmenttool.model.Assessment
import com.prodevans.assessmenttool.model.AssessmentStatus
import com.prodevans.assessmenttool.repository.AssessmentRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Component
class AssessmentMutationResolver (
    private val assessmentRepository: AssessmentRepository,
    private val getValues: GetValues
): GraphQLMutationResolver {
    val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

    fun newAssessment(name: String, createdBy: String, assessmentGroup: String,status: Int,description: String, language: String, assessmentTime: String, questionTime: String): Assessment {
        val assessment = Assessment(name, createdBy, assessmentGroup, AssessmentStatus.values()[status],description, language, assessmentTime, questionTime, LocalDateTime.now().format(formatter))
        assessment.id = getValues.getSequence("assessment")
        assessmentRepository.save(assessment)
        return assessment
    }

    fun deleteAssessment(id: Int): Boolean {
        assessmentRepository.deleteById(id)
        return true
    }

    fun updateAssessment(
        id: Int,
        name: String?,
        description: String?,
        assessmentGroup: String?,
        status: Int?,
        language: String?,
        assessmentTime: String?,
        questionTime: String?
    ): Assessment {
        val assessment = assessmentRepository.findById(id)
        assessment.ifPresent {
            it.name = name ?: it.name
            it.description = description ?: it.description
            it.assessmentGroup = assessmentGroup ?: it.assessmentGroup
            it.status = status?.takeIf { s -> s in 0 until AssessmentStatus.values().size }?.let { AssessmentStatus.values()[it] } ?: it.status
            it.language = language ?: it.language
            it.assessmentTime = assessmentTime ?: it.assessmentTime
            it.questionTime = questionTime ?: it.questionTime
            assessmentRepository.save(it)
        }
        return assessment.get()
    }

}
