package com.prodevans.assessmenttool.model

enum class SubmissionStatus {
    NOT_ATTEMPTED,
    PENDING,
    ATTEMPTED
}