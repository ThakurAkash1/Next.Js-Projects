package com.prodevans.assessmenttool.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "answers")
data class Answer(
    var submissionId: Int,
    var questionId: Int,
    var group: String,
    var score: Float
) {
    @Id
    var id: Int = 0

    @Transient
    var options: List<Option> = ArrayList()
}
