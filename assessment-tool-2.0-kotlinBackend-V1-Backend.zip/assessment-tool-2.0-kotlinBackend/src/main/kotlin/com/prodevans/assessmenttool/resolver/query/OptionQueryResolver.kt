package com.prodevans.assessmenttool.resolver.query

import com.coxautodev.graphql.tools.GraphQLQueryResolver
import com.prodevans.assessmenttool.model.Option
import com.prodevans.assessmenttool.repository.OptionRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component

@Component
class OptionQueryResolver(
    private val getValues: GetValues,
    private val optionRepository: OptionRepository
) : GraphQLQueryResolver {
    fun options(questionId: Int): List<Option> {
        return getValues.options("questionId", questionId)
    }

    fun option(id: Int): Option {
        return optionRepository.findById(id).get()
    }
}