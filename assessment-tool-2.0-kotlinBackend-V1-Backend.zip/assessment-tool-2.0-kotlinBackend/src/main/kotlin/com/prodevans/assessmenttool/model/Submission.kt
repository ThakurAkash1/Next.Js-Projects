package com.prodevans.assessmenttool.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "submissions")
data class Submission(
    var assessmentId: Int,
    var userId: Int,
    var userName: String,
    var userEmail: String,
    var userRole: String,
    var status: SubmissionStatus  = SubmissionStatus.NOT_ATTEMPTED,
//    var status: String,
    var totalScore: Float,
    var time: String
) {
    @Id
    var id: Int = 0

    @Transient
    var answers: List<Answer> = ArrayList()
}
