package com.prodevans.assessmenttool.resolver.query

import com.coxautodev.graphql.tools.GraphQLQueryResolver
import com.prodevans.assessmenttool.model.Assessment
import com.prodevans.assessmenttool.repository.AssessmentRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component

@Component
class AssessmentQueryResolver(
    val assessmentRepository: AssessmentRepository,
    private val getValues: GetValues
) : GraphQLQueryResolver {

    fun assessments(): List<Assessment> {
        val list = assessmentRepository.findAll()
        for (assessment in list) {
            assessment.questions = getValues.questions("assessmentId", assessment.id)
            for (question in assessment.questions) question.options = getValues.options("questionId", question.id)
        }
        return list
    }

    fun assessment(assessmentId: Int): Assessment {
        val assessment = assessmentRepository.findById(assessmentId)
        assessment.ifPresent {
            it.questions = getValues.questions("assessmentId", assessmentId)
            for (question in it.questions) question.options = getValues.options("questionId", question.id)
        }
        return assessment.get()
    }

    fun assessmentsByGroup(group: String): List<Assessment> {
        val list = assessmentRepository.findAllByAssessmentGroup(group)
        for(assessment in list) {
            assessment.questions = getValues.questions("assessmentId", assessment.id)
            for(question in assessment.questions) question.options = getValues.options("questionId", question.id)
        }
        return list
    }
}
