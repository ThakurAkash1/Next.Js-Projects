package com.prodevans.assessmenttool.utility

import org.springframework.stereotype.Component

//@Component
//class KeycloakUserData {
//
//    fun getUsername(): String {
//        val auth = SecurityContextHolder.getContext().authentication as KeycloakAuthenticationToken
//        val keycloakSecurityContext = auth.account.keycloakSecurityContext
//        return keycloakSecurityContext.token.name
//    }
//
//}