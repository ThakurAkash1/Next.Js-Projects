package com.prodevans.assessmenttool.resolver.query

import com.coxautodev.graphql.tools.GraphQLQueryResolver
import com.prodevans.assessmenttool.model.Question
import com.prodevans.assessmenttool.repository.QuestionRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component

@Component
class QuestionQueryResolver(
    private val getValues: GetValues,
    private val questionRepository: QuestionRepository
) : GraphQLQueryResolver {

    fun questions(assessmentId: Int): List<Question> {
        val questions = getValues.questions("assessmentId", assessmentId)
        for (question in questions) question.options = getValues.options("questionId", question.id)
        return questions
    }

    fun question(id: Int): Question {
        return questionRepository.findById(id).get()
    }
}
