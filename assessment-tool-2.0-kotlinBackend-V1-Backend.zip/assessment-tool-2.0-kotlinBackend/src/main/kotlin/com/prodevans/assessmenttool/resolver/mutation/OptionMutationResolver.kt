package com.prodevans.assessmenttool.resolver.mutation

import com.coxautodev.graphql.tools.GraphQLMutationResolver
import com.prodevans.assessmenttool.model.Option
import com.prodevans.assessmenttool.repository.OptionRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component

@Component
class OptionMutationResolver(
    private val optionRepository: OptionRepository,
    private val getValues: GetValues
) : GraphQLMutationResolver {

    fun newOption(questionId: Int, value: String, weightage: Float): Option {
        val option = Option(questionId, value, weightage)
        option.id = getValues.getSequence("option")
        optionRepository.save(option)
        return option
    }

    fun deleteOption(id: Int): Boolean {
        optionRepository.deleteById(id)
        return true
    }

    fun updateOption(id: Int, value: String, weightage: Float): Option {
        val option = optionRepository.findById(id)
        option.ifPresent {
            if (value.isNotEmpty()) it.value = value
            if (weightage >= 0) it.weightage = weightage
            optionRepository.save(it)
        }
        return option.get()
    }
}