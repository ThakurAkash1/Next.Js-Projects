package com.prodevans.assessmenttool.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "assessments")
data class Assessment(
    var name: String,
    var createdBy: String,
    var assessmentGroup: String,
    var status: AssessmentStatus, //= AssessmentStatus.NOT_ATTEMPTED,
    var description: String,
    var language: String,
    var assessmentTime :String,
    var questionTime :String,
    var createdOn: String,
) {
    @Id
    var id: Int = 0

    @Transient
    var questions: List<Question> = ArrayList()
}

