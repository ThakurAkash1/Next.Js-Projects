package com.prodevans.assessmenttool.repository

import com.prodevans.assessmenttool.model.Submission
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface SubmissionRepository: MongoRepository<Submission, Int> {
    fun findAllByUserId(userId: Int): List<Submission>
}