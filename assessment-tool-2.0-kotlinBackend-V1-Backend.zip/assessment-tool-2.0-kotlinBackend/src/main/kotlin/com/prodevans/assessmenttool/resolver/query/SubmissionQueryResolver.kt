package com.prodevans.assessmenttool.resolver.query

import com.coxautodev.graphql.tools.GraphQLQueryResolver
import com.prodevans.assessmenttool.model.Submission
import com.prodevans.assessmenttool.repository.SubmissionRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component

@Component
class SubmissionQueryResolver(
    private val getValues: GetValues,
    private val submissionRepository: SubmissionRepository
): GraphQLQueryResolver {

    fun submissions(): List<Submission> {
        val list = submissionRepository.findAll()
        for (submission in list) {
            submission.answers = getValues.answers("submissionId", submission.id)
        }
        return list
    }

    fun submission(submissionId: Int): Submission {
        val submission = submissionRepository.findById(submissionId)
        submission.ifPresent {
            it.answers = getValues.answers("submissionId", submissionId)
            for (answer in it.answers) answer.options = getValues.options("questionId", answer.questionId)
        }
        return submission.get()
    }

    fun submissionsByUserId(userId: Int): List<Submission> {
       val list = submissionRepository.findAllByUserId(userId = userId)
        for (submission in list) {
            submission.answers = getValues.answers("submissionId", submission.id)
            for (answer in submission.answers) answer.options = getValues.options("questionId", answer.questionId)
        }
        return list
    }
}