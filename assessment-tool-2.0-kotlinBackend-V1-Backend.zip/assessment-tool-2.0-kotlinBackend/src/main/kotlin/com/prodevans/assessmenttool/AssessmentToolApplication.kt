package com.prodevans.assessmenttool

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AssessmentToolApplication

fun main(args: Array<String>) {
	runApplication<AssessmentToolApplication>(*args)
}
