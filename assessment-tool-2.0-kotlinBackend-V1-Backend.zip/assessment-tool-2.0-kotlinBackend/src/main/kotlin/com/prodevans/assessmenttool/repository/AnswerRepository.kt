package com.prodevans.assessmenttool.repository

import com.prodevans.assessmenttool.model.Answer
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface AnswerRepository: MongoRepository<Answer, Int> {
    fun findAllBySubmissionId(submissionId: Int): List<Answer>
}