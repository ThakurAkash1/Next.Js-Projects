package com.prodevans.assessmenttool.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "questions")
data class Question (
    var assessmentId: Int,
    var value: String,
    var type: String,
    var group: String
) {
    @Id
    var id: Int = 0

    @Transient
    var options: List<Option> = ArrayList()
}