package com.prodevans.assessmenttool.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "options")
data class Option(
    var questionId: Int,
    var value: String,
    var weightage: Float
) {
    @Id
    var id: Int = 0
}
