package com.prodevans.assessmenttool.repository
import com.prodevans.assessmenttool.model.Question
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface QuestionRepository: MongoRepository<Question, Int> {
}
