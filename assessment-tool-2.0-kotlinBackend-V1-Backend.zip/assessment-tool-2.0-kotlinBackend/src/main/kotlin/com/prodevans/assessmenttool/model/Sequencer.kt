package com.prodevans.assessmenttool.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "sequencer")
data class Sequencer(
    var value: Int
) {
    @Id
    var id: String = ""
}