package com.prodevans.assessmenttool.model

enum class AssessmentStatus {
    PUBLISHED,
    DRAFT,
    DELETED
}