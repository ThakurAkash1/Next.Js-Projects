package com.prodevans.assessmenttool.resolver.query

import com.coxautodev.graphql.tools.GraphQLQueryResolver
import com.prodevans.assessmenttool.model.Answer
import com.prodevans.assessmenttool.repository.AnswerRepository
import com.prodevans.assessmenttool.utility.GetValues
import org.springframework.stereotype.Component

@Component
class AnswerQueryResolver(
    private val answerRepository: AnswerRepository,
    private val getValues: GetValues
): GraphQLQueryResolver {

    fun answer(id: Int): Answer {
        val answer = answerRepository.findById(id)
        answer.ifPresent { ans ->
            ans.options = getValues.options("questionId", ans.questionId)
        }
        return answer.get()
    }

    fun answersBySubmissionId(submissionId: Int): List<Answer> {
        val answers = answerRepository.findAllBySubmissionId(submissionId)
        for (answer in answers) answer.options = getValues.options("questionId", answer.questionId)
        return answers
    }
}