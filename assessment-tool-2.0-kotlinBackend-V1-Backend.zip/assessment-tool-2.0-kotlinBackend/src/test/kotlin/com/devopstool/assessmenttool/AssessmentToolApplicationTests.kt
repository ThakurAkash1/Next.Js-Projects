package com.devopstool.assessmenttool

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AssessmentToolApplicationTests {

	@Test
	fun contextLoads() {
	}

}
