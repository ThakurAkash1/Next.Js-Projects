import React from 'react';

const AllAssessmentsData  = [
    {
      sno: 1,
      AssessmentName: 'Java Test',
      GroupAssigned: 'Development',
      Status: 'Published',
      CreatedOn: '20-03-2023, 11:00 AM',
      CreatedBy: 'David'
    },
    {
        sno: 2,
        AssessmentName: 'Testing',
        GroupAssigned: 'Development',
        Status: 'Draft',
        CreatedOn: '20-03-2023, 10:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 3,
        AssessmentName: 'Cloud Assessment',
        GroupAssigned: 'Development',
        Status: 'Draft',
        CreatedOn: '20-03-2023, 9:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 4,
        AssessmentName: 'Python',
        GroupAssigned: 'Development',
        Status: 'Deleted',
        CreatedOn: '20-03-2023, 8:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 5,
        AssessmentName: 'Angular',
        GroupAssigned: 'Development',
        Status: 'Deleted',
        CreatedOn: '20-03-2023, 7:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 6,
        AssessmentName: 'Cloud Assessment',
        GroupAssigned: 'Development',
        Status: 'Draft',
        CreatedOn: '20-03-2023, 9:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 7,
        AssessmentName: 'Python',
        GroupAssigned: 'Development',
        Status: 'Deleted',
        CreatedOn: '20-03-2023, 8:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 8
        ,
        AssessmentName: 'Angular',
        GroupAssigned: 'Development',
        Status: 'Deleted',
        CreatedOn: '20-03-2023, 7:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 9,
        AssessmentName: 'Python',
        GroupAssigned: 'Development',
        Status: 'Deleted',
        CreatedOn: '20-03-2023, 8:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 10,
        AssessmentName: 'Angular',
        GroupAssigned: 'Development',
        Status: 'Deleted',
        CreatedOn: '20-03-2023, 7:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 11,
        AssessmentName: 'Cloud Assessment',
        GroupAssigned: 'Development',
        Status: 'Draft',
        CreatedOn: '20-03-2023, 9:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 12,
        AssessmentName: 'Python',
        GroupAssigned: 'Development',
        Status: 'Deleted',
        CreatedOn: '20-03-2023, 8:00 AM',
        CreatedBy: 'David'
    },
    {
        sno: 13,
        AssessmentName: 'Angular',
        GroupAssigned: 'Development',
        Status: 'Deleted',
        CreatedOn: '20-03-2023, 7:00 AM',
        CreatedBy: 'David'
    },
  ];
  
export default AllAssessmentsData;