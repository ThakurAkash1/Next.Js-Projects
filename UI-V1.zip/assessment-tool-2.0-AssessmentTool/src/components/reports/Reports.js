import React from "react";
import Image from "next/image"
import styles from '@/styles/report.module.css';
import report from "@/assets/images/report.svg"
import reportarrow from "@/assets/images/reportArrow.svg"

const Reports = (props) => {
 

  return (
    <div className="container mt-4 bg-light">
      <h6 className={`ml-mt-4 w-75 h-15 ${styles.headingReports}`}>Reports</h6>
      <div className={`row custom-row mt-4 w-100  ${styles.reportContent}`} onClick={() => props.stepChange(props.step + 1)}>
        <div className="col-3 col-md-4 col-sm-4 ">
          <Image alt="#" src={report} />
        </div>
        <div className="col-7 col-md-7 col-sm-7">
          <p className={`h6 text-dark w-50 d-flex   ${styles.reportText}`} >Activity Log</p>
        </div>
        <div className="col-1 col-md-1 col-sm-1">
          <Image alt="#" src={reportarrow} />
        </div>
      </div>
      <div className={`row custom-row mt-4 w-100 ${styles.reportContent}`} onClick={() => props.stepChange(props.step + 2)}>
        <div className="col-3 col-sm-4 col-md-4">
          <Image alt="#" src={report} />
        </div>
        <div className="col-7 col-sm-7 col-md-7">
          <p className={`h6 text-dark w-50 d-flex  ${styles.reportText}`}>All Assessments</p>
        </div>
        <div className="col-1 col-sm-1 col-md-1">
          <Image alt="#" src={reportarrow} />
        </div>
      </div>
      <div className={`row custom-row mt-4 w-100 ${styles.reportContent}`} onClick={() => props.stepChange(props.step + 3)}>
        <div className="col-3 col-sm-4 col-md-4">
          <Image alt="#" src={report} />
        </div>
        <div className="col-7 col-sm-7 col-md-7">
          <p className={`h6 text-dark w-50 d-flex  ${styles.reportText}`}>Assessment Intakes</p>
        </div>
        <div className="col-1 col-sm-1 col-md-1">
          <Image alt="#" src={reportarrow} />
        </div>
      </div>
      <div className={`row custom-row mt-4 w-100 ${styles.reportContent}`} onClick={() => props.stepChange(props.step + 4)}>
        <div className="col-3 col-sm-4 col-md-4">
          <Image alt="#" src={report} />
        </div>
        <div className="col-7 col-sm-7 col-md-7">
          <p className={`h6 text-dark w-50 d-flex ${styles.reportText}`}>User Management</p>
        </div>
        <div className="col-1 col-sm-1 col-md-1">
          <Image alt="#" src={reportarrow} />
        </div>
      </div>
      <style jsx>{`
        .custom-row {
          border: 2px solid #ccc; 
          margin-bottom: 20px; 
          padding: 10px;
          box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3); 
        }
      `}</style>
    </div>
  );
};

export default Reports;