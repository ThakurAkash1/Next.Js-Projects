import React from 'react';

const AssessmentIntakeData  = [
    {
      sno: 1,
      CandidateName: 'Sravani',
      Assessment: 'Java Development',
      SubmittedOn: '24-05-2023,11:00 AM',
      Score: '80%'
    },
    {
      sno: 2,
      CandidateName: 'Dammu',
      Assessment: 'Python',
      SubmittedOn: '22-05-2023,12:00 PM',
      Score: '20%'
    },
    {
      sno: 3,
      CandidateName: 'Sravani',
      Assessment: 'Java Development',
      SubmittedOn: '24-05-2023,11:00 AM',
      Score: '80%'
    },
    {
      sno: 4,
      CandidateName: 'Dammu',
      Assessment: 'Python',
      SubmittedOn: '22-05-2023,12:00 PM',
      Score: '20%'
    },
  ];
  
export default AssessmentIntakeData;