import React from 'react';

const UserManagmentData  = [
    {
      sno: 1,
      Name: 'Sravani',
      EmailId: 'sravanidammu7@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-03-2023, 10:00 AM'
    },
    {
      sno: 2,
      Name: 'Dammu',
      EmailId: 'sravanidammu6@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-04-2023, 10:00 AM'
    },
    {
      sno: 3,
      Name: 'Ammulu',
      EmailId: 'sravanidammu5@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-05-2023, 10:00 AM'
    },
    {
      sno: 4,
      Name: 'Ammulu',
      EmailId: 'sravanidammu4@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-06-2023, 10:00 AM'
    },
    {
      sno: 5,
      Name: 'Ramana',
      EmailId: 'sravanidammu3@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-07-2023, 10:00 AM'
    },
    {
      sno: 6,
      Name: 'Sravani',
      EmailId: 'sravanidammu7@gamil.com',
      Group: 'Changed role from Admin to Team leader',
      Role: 'Admin',
      CreatedOn: '20-08-2023, 10:00 AM'
    },
    {
      sno: 7,
      Name: 'Dammu',
      EmailId: 'sravanidammu6@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-09-2023, 10:00 AM'
    },
    {
      sno: 8,
      Name: 'Ammulu',
      EmailId: 'sravanidammu5@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-10-2023, 10:00 AM'
    },
    {
      sno: 9,
      Name: 'Ammulu',
      EmailId: 'sravanidammu4@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-11-2023, 10:00 AM'
    },
    {
      sno: 10,
      Name: 'Ramana',
      EmailId: 'sravanidammu3@gamil.com',
      Group: 'Development',
      Role: 'Admin',
      CreatedOn: '20-12-2023, 10:00 AM'
    },
  ];
  
export default UserManagmentData;