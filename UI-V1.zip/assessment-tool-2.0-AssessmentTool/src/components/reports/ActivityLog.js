import React, { useState } from 'react';
import Image from 'next/image';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import ActivityData from './ActivityData';
import styles from '@/styles/report.module.css';
import CalendarImage from '@/assets/images/calender.svg';
import { TbMathGreater } from 'react-icons/tb';
import { Container, Table, Pagination, Button } from 'react-bootstrap';
import Sorting from '@/assets/images/sorting.svg';

const ActivityLog = (props) => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [sortColumn, setSortColumn] = useState(null);
  const [sortOrder, setSortOrder] = useState('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  const totalItems = ActivityData.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = ActivityData.slice(indexOfFirstItem, indexOfLastItem);

  const handlePaginationClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleSort = (column) => {
    if (column === sortColumn) {
      const newSortOrder = sortOrder === 'asc' ? 'desc' : 'asc';
      setSortOrder(newSortOrder);
    } else {
      setSortOrder('asc');
      setSortColumn(column);
    }
  };

  const sortedItems = [...currentItems].sort((a, b) => {
    if (sortColumn) {
      if (sortOrder === 'asc') {
        return a[sortColumn].localeCompare(b[sortColumn]);
      } else {
        return b[sortColumn].localeCompare(a[sortColumn]);
      }
    }
    return 0;
  });

  return (
    <div className="table-responsive mt-1">
      <div className={`mt-1 ${styles.Totalcard}`}>
      <div className="d-flex justify-content-between">
          <div className="d-flex align-items-center mt-1">
            <h5 className={` mt-4 h6 text-dark d-none d-md-block ${styles.Activitytitle}`}>Activity Log</h5>
            <Button variant="link" onClick={() => props.stepChange(props.step - 1)} >

            <h5 className={`h-15 mt-4 ${styles.title1} `}>
              Reports
              <span className={styles.greaterThanSymbol}>
                <TbMathGreater />
              </span>
            </h5>
            </Button>
            <h6 className={`h-15 mt-4 ${styles.title2}`}>Activity Log</h6>
          </div>
          <div className= "w-100 mt-3 ">
            <div className={`float-end ${styles.dropdowns}`}>
              <div className={styles.datepickerContainer}>
                <DatePicker
                  selected={selectedDate}
                  onChange={handleDateChange}
                  placeholderText="DD/MM/YYYY"
                  dateFormat="dd/MM/yyyy"
                  className={`${styles.datepickerCustom}`}
                  wrapperClassName={`${styles.datepickerWrapper}`}
                />
                <Image src={CalendarImage} alt="Calendar" className={styles.calendarImage} width={20} height={20} />
              </div>
            </div>
          </div>
        </div>
        <table className={`${styles.table}`}>
          <thead>
            <tr>
              <th>S.No.</th>
              <th>
                <div className="d-flex align-items-center">
                  User
                  <Button variant="link" onClick={() => handleSort('User')}>
                    <Image alt="#" src={Sorting} />
                  </Button>
                </div>
              </th>
              <th>IP Address</th>
              <th>Activity</th>
              <th>
                <div className="d-flex align-items-center">
                  Date & Time
                  <Button variant="link" onClick={() => handleSort('DateTime')}>
                    <Image alt="#" src={Sorting} />
                  </Button>
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            {sortedItems.map((activity, index) => (
              <tr key={index} className={`m-4 ${styles.row}`}>
                <td>{activity.sno}</td>
                <td>{activity.User}</td>
                <td>{activity.IpAddress}</td>
                <td>{activity.Activity}</td>
                <td>{activity.DateTime}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="d-flex justify-content-center">
          <Pagination>
            <Pagination.Prev onClick={() => handlePaginationClick(currentPage - 1)} disabled={currentPage === 1} />
            {Array.from({ length: totalPages }, (_, index) => (
              <Pagination.Item
                key={index + 1}
                active={index + 1 === currentPage}
                onClick={() => handlePaginationClick(index + 1)}
              >
                {index + 1}
              </Pagination.Item>
            ))}
            <Pagination.Next
              onClick={() => handlePaginationClick(currentPage + 1)}
              disabled={currentPage === totalPages}
            />
          </Pagination>
        </div>
      </div>
    </div>
  );
};

export default ActivityLog;
