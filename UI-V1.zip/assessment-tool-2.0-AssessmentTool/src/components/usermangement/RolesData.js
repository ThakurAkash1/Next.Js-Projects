import React from 'react';

const RolesData  = [
    {
      sno: 1,
      role: 'Admin',
      createdon: '24-07-2024,1:00 PM',
      createdby: 'Akash Thakur',
      action: ''
    },
    {
      sno: 2,
      role: 'Leader',
      createdon: '26-07-2024,1:00 PM',
      createdby: 'Akash',
      action: ''
    },
    {
      sno: 3,
      role: 'Super Admin',
      createdon: '22-07-2024,1:00 PM',
      createdby: 'Thakur',
      action: ''
    }
  ];
  
export default RolesData;