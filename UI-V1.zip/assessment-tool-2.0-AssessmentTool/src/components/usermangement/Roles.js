import React, { useState } from 'react';
import Image from 'next/image';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import RolesData from './RolesData';
import styles from '@/styles/usermanagement.module.css';
import CalendarImage from '@/assets/images/calender.svg';
import { TbMathGreater } from 'react-icons/tb';
import { Container, Table, Pagination, Button, Modal, Form } from 'react-bootstrap';
import Sorting from '@/assets/images/sorting.svg';
import { BsPlusSquare } from 'react-icons/bs';
import RoleEdit from '@/assets/images/Propertyedit.svg';
import RoleEDelete from '@/assets/images/PropertyDelete.svg';

const Roles = (props) => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [sortColumn, setSortColumn] = useState(null);
  const [sortOrder, setSortOrder] = useState('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  const [showPopup, setShowPopup] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [role, setRole] = useState('');
  const [allCheckbox, setAllCheckbox] = useState(false);
  const [dashboardCheckbox, setDashboardCheckbox] = useState(false);
  const [assessmentCheckbox, setAssessmentCheckbox] = useState(false);
  const [reportCheckbox, setReportCheckbox] = useState(false);
  const [userManagementCheckbox, setUserManagementCheckbox] = useState(false);
  const [roleData, setRoleData] = useState([...RolesData]);

  const totalItems = roleData.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = roleData.slice(indexOfFirstItem, indexOfLastItem);

  const handlePaginationClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleAddRoleClick = () => {
    setShowPopup(true);
    setIsEditMode(false);
  };

  const handleEditRoleClick = () => {
    setShowPopup(true);
    setIsEditMode(true);
  };

  const handleAddMember = () => {
    const newRole = {
      sno: RolesData.length + 1,
      Name: role,
      role: role,
      AddeddOn: new Date().toLocaleDateString(),
      All: allCheckbox,
      Dashboard: dashboardCheckbox,
      'My Assessment': assessmentCheckbox,
      Reports: reportCheckbox,
      'User Management': userManagementCheckbox,
    };

    setRoleData([...roleData, newRole]);
    setRole('');
    setShowPopup(false);
    setIsEditMode(false);
    setAllCheckbox(false);
    setDashboardCheckbox(false);
    setAssessmentCheckbox(false);
    setReportCheckbox(false);
    setUserManagementCheckbox(false);
  };

  const handleRowDeletion = (rowIndex) => {
    const updatedData = [...roleData];
    updatedData.splice(rowIndex + indexOfFirstItem, 1);
    setRoleData(updatedData);
  };

  const handleSort = (column) => {
    if (column === sortColumn) {
      const newSortOrder = sortOrder === 'asc' ? 'desc' : 'asc';
      setSortOrder(newSortOrder);
    } else {
      setSortOrder('asc');
      setSortColumn(column);
    }
  };

  const sortedItems = [...currentItems].sort((a, b) => {
    if (sortColumn) {
      if (sortOrder === 'asc') {
        return a[sortColumn].localeCompare(b[sortColumn]);
      } else {
        return b[sortColumn].localeCompare(a[sortColumn]);
      }
    }
    return 0;
  });

  return (
    <div className="table-responsive mt-1">
      <div className={`mt-1 ${styles.Totalcard}`}>
        <div className="d-flex justify-content-between">
          <div className="d-flex align-items-center mt-1">
            <h5 className={` mt-4 h6 text-dark ${styles.Rolestitle}`}>Roles</h5>
          </div>
          <div className="w-100 mt-3">
            <div className={`float-end ${styles.Newrole}`}>
              <Button className={`${styles.Newrolebtn}`} onClick={handleAddRoleClick}>
                <BsPlusSquare className={`${styles.RoleAdd}`} />
                <span className="d-none d-md-inline">New Role</span>
              </Button>
            </div>
          </div>
        </div>
        <Modal show={showPopup} onHide={() => setShowPopup(false)}>
          <div className={`${styles.AddMember}`}>
            <Modal.Header closeButton className={`${styles.AddRoleTitle}`}>
              <Modal.Title>{isEditMode ? 'Edit Role' : 'Add Role'}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form.Group controlId="formRoles">
                <Form.Label>Role Name</Form.Label>
                <Form.Control
                  type="role"
                  placeholder="Enter Name"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                />
              </Form.Group>
              <Form.Group>
                <div className={`${styles.popupBox}`}>
                  <div className="row">
                    <div className="col-12 justify-content-start mt-4 mb-4 ">
                      <label>Access To:</label>
                    </div>
                    <div className="col-lg-4 col-md-4 col-sm-6 ">
                      <div className="form-check">
                        <input
                          type="checkbox"
                          className="form-check-input"
                          id="allCheckbox"
                          checked={allCheckbox}
                          onChange={() => setAllCheckbox(!allCheckbox)}
                        />
                        <span>All</span>
                      </div>
                    </div>
                    <div className="col-lg-4  col-md-4 col-sm-6">
                      <div className="form-check">
                        <input
                          type="checkbox"
                          className="form-check-input"
                          id="DashboardCheckbox"
                          checked={dashboardCheckbox}
                          onChange={() => setDashboardCheckbox(!dashboardCheckbox)}
                        />
                        <span>Dashboard</span>
                      </div>
                    </div>
                    <div className="col-lg-4  col-md-4 col-sm-6">
                      <div className="form-check">
                        <input
                          type="checkbox"
                          className="form-check-input"
                          id="AssessmentCheckbox"
                          checked={assessmentCheckbox}
                          onChange={() => setAssessmentCheckbox(!assessmentCheckbox)}
                        />
                        <span>My&nbsp;Assessment</span>
                      </div>
                    </div>
                    <div className="col-lg-4  col-md-4 col-sm-6">
                      <div className="form-check">
                        <input
                          type="checkbox"
                          className="form-check-input"
                          id="reportCheckbox"
                          checked={reportCheckbox}
                          onChange={() => setReportCheckbox(!reportCheckbox)}
                        />
                        <span>Reports</span>
                      </div>
                    </div>
                    <div className="col-lg-4  col-md-4 col-sm-6">
                      <div className="form-check">
                        <input
                          type="checkbox"
                          className="form-check-input"
                          id="UserManagementCheckbox"
                          checked={userManagementCheckbox}
                          onChange={() => setUserManagementCheckbox(!userManagementCheckbox)}
                        />
                        <span>User&nbsp;Management</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Form.Group>
            </Modal.Body>
            <Modal.Footer>
              <div className="col-12 d-flex justify-content-end py-2">
                <button type="submit" className={`${styles.Formcancel}`} onClick={() => setShowPopup(false)}>
                  Cancel
                </button>
                <button type="submit" className={`${styles.Formcreate}`} onClick={handleAddMember}>
                  {isEditMode ? 'Save' : 'Create'}
                </button>
              </div>
            </Modal.Footer>
          </div>
        </Modal>

        <table className={`${styles.table}`}>
          <thead>
            <tr>
              <th>S.No.</th>
              <th>
                <div className="d-flex align-items-center">Role</div>
              </th>
              <th>
                Created On
                <Button variant="link" onClick={() => handleSort('createdon')}>
                  <Image alt="#" src={Sorting} />
                </Button>
              </th>
              <th>Created By</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {sortedItems.map((activity, index) => (
              <tr key={index} className={`m-4 ${styles.row}`}>
                <td>{activity.sno}</td>
                <td>{activity.role}</td>
                <td>{activity.createdon}</td>
                <td>{activity.createdby}</td>
                <td>
                  <div className="d-flex align-items-center  g-5">
                    <div className={`${styles.RoleEditContainer} me-2`}>
                      <span onClick={handleEditRoleClick}>
                        <Image className={`${styles.custommessageframerole}`} alt="#" src={RoleEdit} />
                      </span>
                    </div>
                    <div className={`${styles.RoledeleteContainer} `}>
                      <span onClick={() => handleRowDeletion(index)}>
                        <Image className={`${styles.custommessageframerole}`} alt="#" src={RoleEDelete} />
                      </span>
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="d-flex justify-content-center">
          <Pagination>
            <Pagination.Prev onClick={() => handlePaginationClick(currentPage - 1)} disabled={currentPage === 1} />
            {Array.from({ length: totalPages }, (_, index) => (
              <Pagination.Item
                key={index + 1}
                active={index + 1 === currentPage}
                onClick={() => handlePaginationClick(index + 1)}
              >
                {index + 1}
              </Pagination.Item>
            ))}
            <Pagination.Next onClick={() => handlePaginationClick(currentPage + 1)} disabled={currentPage === totalPages} />
          </Pagination>
        </div>
      </div>
    </div>
  );
};

export default Roles;













