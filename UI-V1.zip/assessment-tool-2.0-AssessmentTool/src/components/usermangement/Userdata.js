import React from 'react';

const Userdata  = [
    {
      sno: 1,
      Name: 'Sravani',
      EmailID: 'Sravani@gmail.com',
      Group: 'Development',
      Role: 'Add Role',
      CreatedOn: '24-07-2023, 4:00 PM',
      Action: ''
    },

    {
        sno: 2,
        Name: 'Akash',
        EmailID: 'Akash@gmail.com',
        Group: 'Development',
        Role: 'Add Role',
        CreatedOn: '25-07-2023, 4:00 PM',
        Action: ''
    },
    {
        sno: 3,
        Name: 'Abhijeet',
        EmailID: 'Abhijeet@gmail.com',
        Group: 'Development',
        Role: 'Add Role',
        CreatedOn: '26-07-2023, 4:00 PM',
        Action: ''
    },
    {
        sno: 4,
        Name: 'Abhi',
        EmailID: 'Abhi@gmail.com',
        Group: 'Development',
        Role: 'Add Role',
        CreatedOn: '27-07-2023, 4:00 PM',
        Action: ''
    },
    {
        sno: 5,
        Name: 'Mahindrakar',
        EmailID: 'Mahindrakar@gmail.com',
        Group: 'Development',
        Role: 'Add Role',
        CreatedOn: '28-07-2023, 4:00 PM',
        Action: ''
    },
    {
        sno: 6,
        Name: 'Ashis',
        EmailID: 'Ashis@gmail.com',
        Group: 'Development',
        Role: 'Add Role',
        CreatedOn: '29-07-2023, 4:00 PM',
        Action: ''
    },
    {
        sno: 7,
        Name: 'Mohammad',
        EmailID: 'azar@gmail.com',
        Group: 'Development',
        Role: 'Add Role',
        CreatedOn: '30-07-2023, 4:00 PM',
        Action: ''
    },
    {
        sno: 8,
        Name: 'Lydia Baptista',
        EmailID: 'lydia@gmail.com',
        Group: 'Development',
        Role: 'Add Role',
        CreatedOn: '22-07-2023, 4:00 PM',
        Action: ''
    },
    {
        sno: 9,
        Name: 'Terry Dokidis',
        EmailID: 'terry@gmail.com',
        Group: 'Development',
        Role: 'Add Role',
        CreatedOn: '23-07-2023, 4:00 PM',
        Action: ''
    },

    
  ];
  
export default Userdata;