import React from 'react';

const DevelopmentGroupData  = [
    {
      sno: 1,
      Name: 'Sravani',
      EmailId: 'Sravani1@prodevans.com',
      AddeddOn: '24-05-2023,11:00 AM',
      Action: 'Remove'
    },
    {
      sno: 2,
      Name: 'Dammu',
      EmailId: 'Sravani8@prodevans.com',
      AddeddOn: '22-05-2023,12:00 AM',
      Action: 'Remove'
    },
    {
      sno: 3,
      Name: 'Ammulu',
      EmailId: 'Sravani7@prodevans.com',
      AddeddOn: '23-05-2023,1:00 AM',
      Action: 'Remove'
    },
    {
      sno: 4,
      Name: 'Ammulu',
      EmailId: 'Sravani6@prodevans.com',
      AddeddOn: '23-05-2023,11:00 AM',
      Action: 'Remove'
    },
    {
      sno: 5,
      Name: 'Ramana',
      EmailId: 'Sravani5@prodevans.com',
      AddeddOn: '23-05-2023,12:00 AM',
      Action: 'Remove'
    },
    {
      sno: 6,
      Name: 'Ammulu',
      EmailId: 'Sravani4@prodevans.com',
      AddeddOn: '23-05-2023,10:00 AM',
      Action: 'Remove'
    },
    {
      sno: 7,
      Name: 'Ammulu',
      EmailId: 'Sravani3@prodevans.com',
      AddeddOn: '24-05-2023,10:00 AM',
      Action: 'Remove'
    },
    {
      sno: 8,
      Name: 'Ramana',
      EmailId: 'Sravani2@prodevans.com',
      AddeddOn: '24-05-2023,9:00 AM',
      Action: 'Remove'
    },
  ];
  
export default DevelopmentGroupData;