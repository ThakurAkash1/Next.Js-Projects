import React, { useState } from 'react';
import Image from 'next/image';
import styles from '@/styles/usermangement.module.css';
import { TbMathGreater } from 'react-icons/tb';
import { Container, Table, Pagination, Button, Modal, Form } from 'react-bootstrap';
import Sorting from '@/assets/images/sorting.svg';
import { BsPlusSquare } from 'react-icons/bs';
import DesignGroupData from './DesignGroupData';

const DesignGroup = (props) => {
    const [showPopup, setShowPopup] = useState(false);
  const [email, setEmail] = useState('');
  const [designGroupData, setDesignGroupData] = useState([...DesignGroupData]);
  
  const [sortColumn, setSortColumn] = useState(null);
  const [sortOrder, setSortOrder] = useState('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

 

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  const totalItems = designGroupData.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = designGroupData.slice(indexOfFirstItem, indexOfLastItem);

  const handlePaginationClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleSort = (column) => {
    if (column === sortColumn) {
      const newSortOrder = sortOrder === 'asc' ? 'desc' : 'asc';
      setSortOrder(newSortOrder);
    } else {
      setSortOrder('asc');
      setSortColumn(column);
    }
  }; 

  const handleRowRemoval = (rowIndex) => {
    // Create a copy of the current data array to avoid directly modifying the state.
    const updatedData = [...designGroupData];
    updatedData.splice(rowIndex + indexOfFirstItem, 1); // Remove the row from the updated data array.
    setDesignGroupData(updatedData); // Update the state with the updated data array.
  };

  const sortedItems = [...currentItems].sort((a, b) => {
    if (sortColumn) {
      if (sortOrder === 'asc') {
        return a[sortColumn].localeCompare(b[sortColumn]);
      } else {
        return b[sortColumn].localeCompare(a[sortColumn]);
      }
    }
    return 0;
  });

  const handleAddMember = () => {
    const newMember = {
      sno: designGroupData.length + 1,
      Name: 'New Member',
      EmailId: email, // Use the email state value here
      AddeddOn: new Date().toLocaleDateString(), 
    };

    setDesignGroupData([...designGroupData, newMember]);
    setEmail(''); 
    setShowPopup(false); 
  };

  return (
    <div className="table-responsive mt-1">
      <div className={`mt-1 ${styles.Totalcard}`}>
        <div className="d-flex justify-content-between">
          <div className="d-flex align-items-center mt-1">
            <h5 className={`w-100 mt-4 h6 text-dark d-none  d-md-block ${styles.Activitytitle}`}>Design Group</h5>
            <Button variant="link" onClick={() => props.stepChange(props.step - 2)} >
              <h5 className={`h-15 mt-4 ${styles.title1} `}>
                Groups
                <span className={styles.greaterThanSymbol}>
                  <TbMathGreater />
                </span>
              </h5>
            </Button>
            <h6 className={`h-15 mt-4 ${styles.title2}`}>Design</h6>
          </div>
          <div className="col-6">
        <Button
        variant="primary"
          id="newbutton"
          className={` d-flex justify-content-center align-items-center p-1 gap-2 w-5 h-5 ${styles.newMember}`}
          onClick={() => setShowPopup(true)}
        >
           <BsPlusSquare className={`${styles.iconplus}`} />
          Add Member
        </Button>
      </div>

      {/* Pop-up card */}
      <Modal  show={showPopup} onHide={() => setShowPopup(false)}>
        <div className={`${styles.AddMember}`}>
        <Modal.Header closeButton className={`${styles.AddMemberTitle}`}>
          <Modal.Title >Add Member</Modal.Title>
        </Modal.Header>
        <Modal.Body >
          <Form.Group controlId="formEmail">
            <Form.Label>Select Role</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter Email ID"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer >
          <Button className='w-25 bg-light text-dark' variant="secondary" onClick={() => setShowPopup(false)}>
            Cancel
          </Button>
          <Button className={`w-25 ${styles.add}`} variant="primary" onClick={handleAddMember}>
            Add
          </Button>
        </Modal.Footer>
        </div>
      </Modal>
        </div>
        <table className={`${styles.table}`}>
          <thead>
            <tr>
              <th>S.No.</th>
              <th> Name </th>
              <th>Email ID</th>
              <th>
                <div className="d-flex align-items-center">
                  Added On
                  <Button variant="link" onClick={() => handleSort('AddeddOn')}>
                    <Image alt="#" src={Sorting} />
                  </Button>
                </div>
              </th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {sortedItems.map((designgroup, index) => (
              <tr key={index} className={`m-4 ${styles.row}`}>
                <td>{designgroup.sno}</td>
                <td>{designgroup.Name}</td>
                <td>{designgroup.EmailId}</td>
                <td>{designgroup.AddeddOn}</td>
                <td>
                  {/* Add the button to remove the row */}
                  <Button className={`${styles.removebutton}`} variant="link" onClick={() => handleRowRemoval(index)}>
                    Remove
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="d-flex justify-content-center">
          <Pagination>
            <Pagination.Prev onClick={() => handlePaginationClick(currentPage - 1)} disabled={currentPage === 1} />
            {Array.from({ length: totalPages }, (_, index) => (
              <Pagination.Item
                key={index + 1}
                active={index + 1 === currentPage}
                onClick={() => handlePaginationClick(index + 1)}
              >
                {index + 1}
              </Pagination.Item>
            ))}
            <Pagination.Next
              onClick={() => handlePaginationClick(currentPage + 1)}
              disabled={currentPage === totalPages}
            />
          </Pagination>
        </div>
      </div>
    </div>
  );
};

export default DesignGroup;