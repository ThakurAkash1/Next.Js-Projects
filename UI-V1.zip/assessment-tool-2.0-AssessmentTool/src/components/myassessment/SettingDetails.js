import React, { useState, useEffect } from "react";
import styles from "@/styles/assessments.module.css";
import Image from "next/image";
import uploadimgage from "@/assets/images/uploadimg.svg";
import { BsPlusSquare, BsPencil } from "react-icons/bs";
import { TbMathGreater } from "react-icons/tb";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import AssessmentMobileSideBar from "./AssessmentMobileSideBar";
// import { TbMathGreater } from "react-icons/tb";
import { BsExclamationCircle } from "react-icons/bs";
import { MdOutlineCopyAll } from "react-icons/md";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { useSession } from "next-auth/react";

const SettingDetails = (props) => {
  const { data: session } = useSession();
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState("option1");
  const [assessmentData, setAssessmentData] = useState(null);
  const { assessmentId } = props;
  console.log("AssessmentId:", assessmentId);

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };

  useEffect(() => {
    function fetchData() {
      var myHeaders = new Headers();
      myHeaders.append("Authorization", "Bearer " + session.user.access_token);
      myHeaders.append("Content-Type", "application/json");

      var graphql = JSON.stringify({
        query: `
        query GetAssessment($assessmentId: ID!) {
          assessment(id: $assessmentId) {
            id,
            assessmentTime
            questionTime
          }
        }
      `,
        variables: {
          assessmentId: assessmentId, // This assumes assessmentId is the correct id you want to fetch
        },
      });

      var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: graphql,
        redirect: "follow",
      };

      fetch("http://localhost:9001/assessment-tool/admin", requestOptions)
        .then((response) => response.json())
        .then((result) => {
          const assessment = result.data.assessment;
          if (assessment) {
            setAssessmentData(assessment);
          }
        })
        .catch((error) => console.log("error", error));
    }

    fetchData();
  }, [assessmentId, session.user.access_token]);

  const handleRadioChange = (event) => {
    setSelectedOption(event.target.value);
  };

  return (
    <div
      className={`${styles.MyAssessmentcontainerDetail}`}
      onBlur={handleOutsideClick}
    >
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => {}}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}
      <div className="row mt-4">
        <div className="col-12">
          <div className={`d-flex align-items-center ${styles.Detailheader}`}>
            <strong>Test</strong>
            <div className={`d-flex align-items-center ${styles.Dtitle1}`}>
              <span onClick={() => props.stepChange(props.step - 9)}>
                My Assessment
              </span>
              <span className={styles.DtlgreaterSyb}>
                <TbMathGreater />
              </span>
              <strong>Assessment Details</strong>
            </div>
          </div>
        </div>
      </div>
      <div className="row col-12 mt-4">
        <div className="col-3 d-none d-md-block">
          <div className={`${styles.DetailsOptions}`}>
            <div className="d-flex  flex-column justify-content-between">
              <div
                className="p-3"
                onClick={() => props.stepChange(props.step - 2)}
              >
                Basic Details
              </div>
              <div
                className="p-3"
                onClick={() => props.stepChange(props.step - 1)}
              >
                Questions
              </div>
              <div className="d-flex align-items-center">
                <div className={`${styles.Detailbox}`}>
                  <div className={`${styles.Detailboxtext}`}>Settings</div>
                </div>
                <div className={`${styles.VerticalLine}`}></div>
              </div>
              <div className="p-3" onClick={() => props.stepChange(props.step + 1)} >
                Result&nbsp;Table</div>
            </div>
          </div>
        </div>
        <div
          className={`col-9 d-flex flex-column bg-white ${styles.Detailsdata}`}
        >
          <div className="row mt-2">
            <div className="col-6 mt-2">
              <div className="d-flex align-items-center ">
                <div className={`${styles.DetailSidebar} d-lg-none d-md-none`}>
                  <>
                    <button
                      className={`${styles.btnnewDraftarrow} me-2`}
                      onClick={handleNewButtonClick}
                    >
                      <MdOutlineKeyboardDoubleArrowRight
                        className={`${styles.iconArrorw}`}
                      />
                    </button>
                  </>
                </div>
                <h5 className={styles["custom-heading"]}>Other Setting</h5>
              </div>
            </div>
          </div>
          <div className={`${styles.AllQstTitle}`}>
            <div className={`${styles.PassdataCreate}`}>
              <div className="row mt-2">
                <div className="col-12">
                  <div className={`${styles.Setting}`}>
                    <h5 className={`${styles.headingSetting}`}>
                      Select test duration measuring method
                    </h5>
                  </div>
                </div>
                {assessmentData && (
                  <div className="col-12">
                    <div className={`${styles.Radio}`}>
                      <div
                        className={`${styles.Inputone} row align-items-center`}
                      >
                        <div className="col-12 col-md-auto ">
                          <input
                            type="radio"
                            name="flexRadioDefault"
                            className={`${styles.Inputbox}`}
                            checked={
                              assessmentData.assessmentTime ? true : false
                            }
                            // checked={assessmentData.assessmentTime || (assessmentData.questionTime && !assessmentData.assessmentTime)}
                          />
                          <label
                            className={`${styles.Inputtext} ms-2`}
                            htmlFor="flexRadioDefault1"
                          >
                            Time to complete the assessment:
                          </label>
                        </div>
                        <div className="col-12 col-md d-flex align-items-center">
                          <input
                            type="text"
                            className={`form-control ${styles.TextInputone}    ${styles.SmallInput}`}
                            value={assessmentData.assessmentTime}
                          />
                          <p
                            className={`${styles.Inputparaone} align-self-center  ms-2`}
                          >
                            (hh:mm)
                          </p>
                        </div>
                      </div>
                      <div
                        className={`${styles.Inputtwo} row align-items-center`}
                      >
                        <div className="col-12 col-md-auto">
                          <input
                            type="radio"
                            name="flexRadioDefault"
                            className={`${styles.Inputboxone}`}
                            checked={assessmentData.questionTime ? true : false}
                            // checked={assessmentData.questionTime || (assessmentData.assessmentTime && !assessmentData.questionTime)}
                          />
                          <label
                            className={`${styles.Inputtext} ms-2`}
                            htmlFor="flexRadioDefault2"
                          >
                            Time limit for each question:
                          </label>
                        </div>
                        <div className="col-12 col-md d-flex align-items-center">
                          <input
                            type="text"
                            className={`form-control ${styles.TextInputone} flex-grow-auto ${styles.SmallInput}`}
                            value={assessmentData.questionTime}
                          />
                          <p
                            className={`${styles.Inputparaone} align-self-center  ms-2`}
                          >
                            (mm:ss)
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                <div className="row">
                  <div className="col-12">
                    <div className={`${styles.Accesstype}`}>
                      <div className="ml-4 mt-4">
                        <h5>Access Type</h5>
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-3 col-lg-2">
                    <div className="form-check form-check-inline">
                      <input
                        className="form-check-input form-check-lg"
                        type="radio"
                        name="inlineRadioOptions"
                        id="inlineRadio1"
                        value="option1"
                        checked={selectedOption === "option1"}
                        onChange={handleRadioChange}
                      />
                      <label className={`${styles.RedioTextLine}`}>
                        Public
                      </label>
                    </div>
                  </div>
                  <div className="col-12 col-md-3 col-lg-2">
                    <div className="form-check form-check-inline">
                      <input
                        className="form-check-input form-check-lg"
                        type="radio"
                        name="inlineRadioOptions"
                        id="inlineRadio2"
                        value="option2"
                        checked={selectedOption === "option2"}
                        onChange={handleRadioChange}
                      />
                      <label className={`${styles.RedioTextLine}`}>
                        Private
                      </label>
                    </div>
                  </div>
                  <div className="col-12 col-md-6 col-lg-8">
                    <div className="form-check form-check-inline">
                      <input
                        className="form-check-input form-check-lg"
                        type="radio"
                        name="inlineRadioOptions"
                        id="inlineRadio3"
                        value="option3"
                        checked={selectedOption === "option3"}
                        onChange={handleRadioChange}
                      />
                      <label className={`${styles.RedioTextLine}`}>
                        Specific Group
                      </label>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-12">
                    {selectedOption === "option1" && (
                      <div className={`${styles.PublicRadiobtn}`}>
                        <div
                          className={`alert alert-success ${styles["custom-alert"]}`}
                          role="alert"
                        >
                          <BsExclamationCircle /> Anyone in your team can take
                          the assessment
                        </div>
                      </div>
                    )}

                    {selectedOption === "option2" && (
                      <div className={`${styles.PraivateRadiobtn} mb-2`}>
                        <div
                          className={`alert alert-success ${styles["custom-alert"]}`}
                          role="alert"
                        >
                          <BsExclamationCircle /> Anyone in your team can take
                          the assessment
                        </div>
                        <div className="row">
                          <div className="col-12 col-md-9">
                            <div
                              className={`alert alert-light ${styles["custom-alert1"]}`}
                              role="alert"
                            >
                              https://www.assessit/test
                            </div>
                          </div>
                          <div className="col-12 col-md-3">
                            <div className={`${styles.copyRedio}`}>
                              <button className={`${styles.Copytext}`}>
                                <MdOutlineCopyAll /> Copy Link
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="row mt-2 mb-4">
                          <div className="col-12">
                            <div className={`${styles.emailContainer}`}>
                              <div className={`${styles.emailSelector}`}>
                                <textarea
                                  className={`${styles.emailTextarea} form-control`}
                                  style={{ width: "100%" }}
                                  placeholder="Enter email ID to add"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedOption === "option3" && (
                      <div className={`${styles.specificRediobtn} mb-2`}>
                        <select
                          id="language"
                          className={`${styles.redioSpecificbtn}`}
                        >
                          <option value="Select" disabled selected hidden>
                            Select
                          </option>
                          <option value="Development">
                            <input
                              type="checkbox"
                              className={styles.checkbox}
                            />{" "}
                            Development
                          </option>
                          <option value="Infra">
                            <input
                              type="checkbox"
                              className={styles.checkbox}
                            />{" "}
                            Infra
                          </option>
                          <option value="Hr">
                            <input
                              type="checkbox"
                              className={styles.checkbox}
                            />{" "}
                            HR
                          </option>
                        </select>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingDetails;
