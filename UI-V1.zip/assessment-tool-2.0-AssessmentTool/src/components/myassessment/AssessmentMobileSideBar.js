import React, { useEffect, useState } from "react";
import styles from "@/styles/assessments.module.css";
import Image from "next/image";


const AssessmentMobileSideBar = (props) => {
  return (
    <div className={`${styles.AssessmentDetailSidebar}`}>
      <div className="row">
        <div className={`${styles.AssessmentSidebarTitle}`}>
          <strong>Test</strong>
        </div>
        <div className={`${styles.AssessmentSidebarMenue}`}>
          <div
            className={`${styles.AssessmentSidebarelement}`}
          >
            <label onClick={() => props.stepChange(props.step + 1)}>
              Basic Details
            </label>
          </div>
          <div className={`${styles.AssessmentSidebarelement}`}>
            <label onClick={() => props.stepChange(props.step + 2)}>
              Questions
            </label>
          </div>
          <div className={`${styles.AssessmentSidebarelement}`}>
            <label onClick={() => props.stepChange(props.step + 3)}>
              Settings
            </label>
          </div>
          <div className={`${styles.AssessmentSidebarelement}`}>
            <label>Result Table</label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssessmentMobileSideBar;
