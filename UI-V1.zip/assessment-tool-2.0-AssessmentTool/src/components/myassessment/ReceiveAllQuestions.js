import React, { useState, useEffect } from "react";
import styles from "@/styles/assessments.module.css";
import Image from "next/image";
import uploadimgage from "@/assets/images/uploadimg.svg";
import { BsPlusSquare, BsPencil } from "react-icons/bs";
import { TbMathGreater } from "react-icons/tb";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import AssessmentMobileSideBar from "./AssessmentMobileSideBar";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { useSession } from "next-auth/react";

const ReceiveAllQuestions = (props) => {
  // const [isSidebarOpen, setSidebarOpen] = useState(false);
  const { data: session } = useSession();
  // const { assessmentId } = props;
  const { assessmentId } = props;

  // const [selectedOption, setSelectedOption] = useState("");
  const [optionsData, setOptionsData] = useState([]);
  const [receivedQuestions, setReceivedQuestions] = useState(
    props.receivedQuestions
  ); // Set initial value from props

  // console.log(props);

  console.log("Assessment || hold  ID:", assessmentId);
  // console.log("assessmentId:",assessmentId);

  // const handleNewButtonClick = () => {
  //   setSidebarOpen(!isSidebarOpen);
  // };
  // const handleOutsideClick = () => {
  //   setSidebarOpen(false);
  // };

  // const [selectedOption, setSelectedOption] = useState("");
  // const { optionsData, receivedQuestions } = props;

  // const handleRadioChange = (event) => {
  //   setSelectedOption(event.target.value);
  // };

  useEffect(() => {
    console.log("Fetching data for question ID:", assessmentId); // Add this line for debugging
    // console.log("Fetching data for assessmentId:", assessmentId); // Add this line for debugging

    function fetchData() {
      var myHeaders = new Headers();
      myHeaders.append("Authorization", "Bearer " + session.user.access_token);
      myHeaders.append("Content-Type", "application/json");

      var graphql = JSON.stringify({
        query: `
        query GetQuestions($assessmentId: ID!) {
          questions(assessmentId: $assessmentId) {
            id,
            value
            options {
              id,
              value,
              weightage
            }
          }
        }
      `,
        variables: {
          assessmentId: assessmentId,
        },
      });

      var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: graphql,
        redirect: "follow",
      };

      fetch("http://localhost:9001/assessment-tool/admin", requestOptions)
        .then((response) => response.json())
        .then((result) => {
          console.log("Received questions:", result);
          const questions = result.data.questions;
          if (questions) {
            setReceivedQuestions(questions);
            // Organize options by question ID
            const optionsByQuestionId = questions.reduce((acc, question) => {
              acc[question.id] = question.options;
              return acc;
            }, {});

            setOptionsData(optionsByQuestionId);
          }
        })
        .catch((error) => console.log("error", error));
    }

    fetchData();
  }, [assessmentId, session.user.access_token]);

  // useEffect(() => {
  //   console.log("Fetching data for question ID:", assessmentId);
  //   console.log("Fetching data for assessmentId:", assessmentId);

  //   function fetchData() {
  //     var myHeaders = new Headers();
  //     myHeaders.append("Authorization", "Bearer " + session.user.access_token);
  //     myHeaders.append("Content-Type", "application/json");

  //     // Create the variables object conditionally
  //     var variables = {};
  //     if (assessmentId) {
  //       variables = { assessmentId: assessmentId };
  //     } else if (assessmentId) {
  //       variables = { assessmentId: assessmentId };
  //     }
  //     else {
  //       console.log("any id is notg present");
  //     }
  //     var graphql = JSON.stringify({
  //       query: `
  //         query GetQuestions($assessmentId: ID!) {
  //           questions(assessmentId: $assessmentId) {
  //             id,
  //             value,
  //             options {
  //               id,
  //               value,
  //               weightage
  //             }
  //           }
  //         }
  //       `,
  //       variables: variables,
  //     });

  //     var requestOptions = {
  //       method: "POST",
  //       headers: myHeaders,
  //       body: graphql,
  //       redirect: "follow",
  //     };

  //     fetch("http://localhost:9000/assessment-tool/admin", requestOptions)
  //       .then((response) => response.json())
  //       .then((result) => {
  //         console.log("Received questions:", result);
  //         const questions = result.data.questions;
  //         if (questions) {
  //           setReceivedQuestions(questions);
  //           // Organize options by question ID
  //           const optionsByQuestionId = questions.reduce((acc, question) => {
  //             acc[question.id] = question.options;
  //             return acc;
  //           }, {});

  //           setOptionsData(optionsByQuestionId);
  //         }
  //       })
  //       .catch((error) => console.log("error", error));
  //   }

  //   fetchData();
  // }, [assessmentId, assessmentId, session.user.access_token]);

  return (
    <div>
      {/* <div className="row mt-2">
            <div className="col-6 mt-2">
              <div className="d-flex align-items-center ">
                <div className={`${styles.DetailSidebar} d-lg-none d-md-none`}>
                  <>
                    <button
                      className={`${styles.btnnewDraftarrow} me-2`}
                      onClick={handleNewButtonClick}
                    >
                      <MdOutlineKeyboardDoubleArrowRight
                        className={`${styles.iconArrorw}`}
                      />
                    </button>
                  </>
                </div>
                <h5 className={styles["custom-heading"]}>All Questions</h5>
              </div>
            </div>
            <div className="col-6">
              <div className={`mr-4 mt-2 ${styles.questionContainer}`}>
                <div className={`${styles.questionTextdiv}`}>
                  <button
                    className={`${styles.questionGroups}`}
                    onClick={() => props.stepChange(props.step - 5)}
                  >
                    <BsPlusSquare className="iconAdd" />
                    <span className="d-none d-md-inline">Add Question</span>
                  </button>
                </div>
              </div>
            </div>
          </div> */}

      <div className={`${styles.AllQstTitle}`}>
        <div className={`${styles.PassdataCreate}`}>
          <div className="row">
            <div className="col">
              {receivedQuestions.map((questionData, index) => (
                <div className={`${styles.AllQuestionBorder} mt-4`} key={index}>
                  <div className="row mt-4">
                    <div className={`col-6 ${styles.start}`}>
                      <div className={`${styles.questionscoreone}`}>
                        <label>Question {index + 1}</label>
                      </div>
                    </div>
                    <div className={`col-6 ${styles.end}`}>
                      <div className={`${styles.scoreContainer}`}>
                        <div className={`${styles.AllScore}`}>
                          Score: 5
                          <div className={`${styles.dots}`}>
                            <BiDotsVerticalRounded />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row mt-2">
                    <div className="col-12">
                      <label
                        htmlFor="assessmentName"
                        className={`${styles.boldLabel}`}
                      >
                        {questionData.value}
                      </label>
                    </div>
                  </div>
                  <div className="row mt-2">
                    {optionsData[questionData.id] &&
                      optionsData[questionData.id].map(
                        (option, optionIndex) => (
                          <div
                            className="col-12 col-md-4 col-lg-3 col-xl-3"
                            key={optionIndex}
                          >
                            <div
                              className={`form-check form-check-inline ${styles.StateChoice}`}
                            >
                              <input
                                className={`form-check-input form-check-lg ${styles.customCheckbox}`}
                                type="checkbox"
                                id={`checkbox${optionIndex}`}
                                defaultChecked={option.weightage > 0}
                              />
                              <label
                                className={`form-check-label ${styles.labelCustom}`}
                                htmlFor={`checkbox${optionIndex}`}
                              >
                                {option.value}
                              </label>
                            </div>
                          </div>
                        )
                      )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReceiveAllQuestions;
