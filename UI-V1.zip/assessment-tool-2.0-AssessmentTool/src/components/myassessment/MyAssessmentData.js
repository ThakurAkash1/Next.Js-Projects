import React from "react";

const MyAssessmentData = [
  // {
  //   name: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Java Assessment",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Draft",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Java Assessment",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Draft",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // }
  // ,
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // }
  // ,
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // }
  // ,
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // }
  // ,
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // },
  // {
  //   title: "Test",
  //   description:
  //     " Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
  //   Status: "Published",
  //   QuestionsAdd: "2",
  //   CreatedOn: "20 April, 12:00am",
  // }
];

export default MyAssessmentData;
