import React, { useEffect, useState } from "react";
import styles from "@/styles/assessments.module.css";
import Image from "next/image";
import document from "@/assets/images/FrameFile.svg";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { BsPlusSquare } from "react-icons/bs";
// import MyAssessmentData from "./MyAssessmentData";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import { BsEye } from "react-icons/bs";
import { RiDeleteBin6Line } from "react-icons/ri";
import { MdOutlineModeEditOutline } from "react-icons/md";
import AssessmentMobileSideBar from "./AssessmentMobileSideBar";
import { useSession } from "next-auth/react";

const NewAssessment = (props) => {
  const { data: session } = useSession();
  const [myData, setMyData] = useState([]);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [assessmentId, setAssessmentId] = useState(null); // Initialize a state variable to hold the assessmentId

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };

  const QuestionsAdd = "2";
  // const CreatedOn = "20 April, 12:00am"
  // const description = "Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna."

  const getStatusBulletColor = (status) => {
    switch (status) {
      case "PUBLISHED":
        return "rgba(67, 153, 81, 1)";
      case "DRAFT":
        return "rgba(173, 173, 173, 1)";
      case "DELETED":
        return "rgba(243, 86, 86, 1)";
      default:
        return "#808080";
    }
  };

  const handlePopupToggle = (index) => {
    if (selectedAssessment === index) {
      setSelectedAssessment(null);
    } else {
      setSelectedAssessment(index);
    }
  };

  function handleDelete(itemId) {
    var myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + session.user.access_token);
    myHeaders.append("Content-Type", "application/json");

    var graphql = JSON.stringify({
      query: `mutation {
        deleteAssessment(id: ${itemId})
      }`,
      variables: {},
    });
    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: graphql,
      redirect: "follow",
    };

    fetch("http://localhost:9001/assessment-tool/admin", requestOptions)
      .then((response) => response.json())
      .then((result) => console.log(result))
      .catch((error) => console.log("error", error));
  }

  const Popup = ({ itemId, onDelete }) => {
    return (
      <div className={`${styles.popup} `}>
        <ul className={`${styles.popupList}`}>
          <li>
            <button
              className={`${styles.threeboxbtn}`}
              onClick={() => handleIdPass(itemId)}
            >
              <BsEye />
              View
            </button>
          </li>
          <li>
            <button className={`${styles.threeboxbtn}`}>
              <MdOutlineModeEditOutline />
              Edit
            </button>
          </li>
          <li>
            <button
              className={`${styles.threeboxbtn}`}
              onClick={() => onDelete(itemId)}
            >
              <RiDeleteBin6Line />
              Delete
            </button>
          </li>
        </ul>
      </div>
    );
  };

  useEffect(() => {
    function ListApi() {
      var myHeaders = new Headers();
      myHeaders.append("Authorization", "Bearer " + session.user.access_token);
      myHeaders.append("Content-Type", "application/json");

      var graphql = JSON.stringify({
        query:
          "query{\r\n    assessments {\r\n        id,\r\n        name,\r\n        status,\r\n        description,\r\n        createdOn \r\n    }\r\n}",
        variables: {},
      });

      var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: graphql,
      };

      fetch("http://localhost:9001/assessment-tool/admin", requestOptions)
        .then((response) => response.json())
        .then((result) => {
          console.log("Response from server:", result);
          setMyData(result.data.assessments);
        })
        .catch((error) => console.log("error", error));
    }

    ListApi();
  }, []);

  const handleIdPass = (id) => {
    props.setAssessmentId(id); // Set the assessmentId in the state
    props.stepChange(props.step + 7, id);
    console.log(id);
  };

  return (
    <div
      className={`${styles.MyAssessmentcontainer} h-100 w-99 d-flex flex-column`}
      onBlur={handleOutsideClick}
    >
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => {}}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}
      {myData && myData.length === 0 ? (
        <div className={`${styles.Newcontainer}`}>
          <div className="row mt-4">
            <div className="col-6">
              <div className={`${styles.header} d-none d-md-block d-flex justify-content-between align-items-center`}>
                <div className={`${styles.text}`}>My Assessments</div>
              </div>
            </div>
            <div className="col-6">
              <button
                id="newbutton"
                className={`${styles.btnnew} d-none d-md-block`}
                onClick={() => props.stepChange(props.step + 1)}
              >
                <BsPlusSquare
                  className={`${styles.iconplus} ${styles.gapfirst}`}
                />{" "}
                New
              </button>
            </div>
          </div>
          <div className={`${styles.filecreate}`}>
            <span className={`${styles.filecreate}`}>
              <Image
                className={`${styles.customImageassessment}`}
                alt="#"
                src={document}
              />
            </span>
          </div>
          <div className="col-12 text-center">
            <button
              id="newbuttonone"
              className={`${styles.smButton} d-lg-none d-md-none  mx-auto`}
              onClick={() => props.stepChange(props.step + 1)}
            >
              <BsPlusSquare className={`${styles.btnass} ${styles.gapone}`} />{" "}
              New
            </button>
          </div>
        </div>
      ) : myData && myData.length > 0 ? (
        <div className="row">
          <div className={`col-12 mt-4 ${styles.Newcontainer}`}>
            <div
              className={`${styles.NewcontainerDraftTitle} d-none d-md-block`}
            >
              <div className="row align-items-center">
                <div className="col-md-6 mt-2">
                  <div
                    className={`${styles.headerDraft} d-flex align-items-start`}
                  >
                    <div className={`${styles.textDraft}`}>My Assessments</div>
                  </div>
                </div>
                <div className="col-md-6 mb-4">
                  <div
                    className={`${styles.NewDraftbtn} d-flex justify-content-end`}
                  >
                    <button
                      id="newbutton"
                      className={`${styles.btnnew} border-0 pt-1 pb-1 px-3`}
                      onClick={() => props.stepChange(props.step + 1)}
                    >
                      <BsPlusSquare
                        className={`${styles.iconplus} ${styles.gapfirst}`}
                      />{" "}
                      New
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className={`${styles.DraftNew} d-lg-none d-md-none mx-auto`}>
              <div className="row mb-4 mt-2">
                <div className="col-12">
                  <div
                    className={`${styles.customrowDraft} align-items-center`}
                  >
                    <div className="col-md-6">
                      <div className="d-flex align-items-center">
                        <>
                          <button
                            className={`${styles.btnnewDraftarrow} me-2`}
                            onClick={handleNewButtonClick}
                          >
                            <MdOutlineKeyboardDoubleArrowRight
                              className={`${styles.iconArrorw}`}
                            />
                          </button>
                        </>
                        <div className={`${styles.Drafttext}`}>
                          All Assessment
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="d-flex justify-content-end">
                        <button
                          className={`${styles.btnnewDraftPlus}`}
                          onClick={() => props.stepChange(props.step + 1)}
                        >
                          <BsPlusSquare className={`${styles.iconDraft}`} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className={`${styles.filecreateDrft}`}>
              <div className={`${styles.boxContainer} row col-12`}>
                {myData.map((item, index) => (
                  <div
                    className={`col-xl-4 col-lg-4 col-md-4 col-sm-12 mx-1 ${
                      styles.box
                    } ${index === 0 ? styles.firstBox : styles.secondBox}`}
                    style={{
                      borderLeftColor:
                        item.status === "PUBLISHED" ? "green" : "grey",
                    }}
                    key={index}
                  >
                    <div className="d-flex flex-column mt-2">
                      <div className={`${styles.questionscoreone}`}>
                        <strong onClick={() => handleIdPass(item.id)}>
                          {item.name}
                        </strong>
                        <label>
                          <BiDotsVerticalRounded
                            onClick={() => handlePopupToggle(index, item.id)}
                          />
                        </label>
                      </div>
                      <div
                        className={`${styles.Para} mt-2`}
                        // onClick={() => handleIdPass(item.id)}
                      >
                        {/* onClick={() => props.stepChange(props.step + 7)}> */}
                        <p>{item.description}</p>
                      </div>
                      <div className={`${styles.Status} d-flex`}>
                        <label>Status:</label>
                        <span
                          className={styles.statusBullet}
                          style={{
                            backgroundColor: getStatusBulletColor(item.status),
                            display: "inline-block",
                            width: "10px",
                            height: "10px",
                            borderRadius: "50%",
                            marginRight: "5px",
                            marginTop: "3px",
                          }}
                        ></span>
                        <div className={`${styles.StatusTitle}`}>
                          {item.status}
                        </div>
                      </div>
                      <div className={`${styles.Status} d-flex mt-2`}>
                        <label>Questions Added:</label>
                        <span>{item.QuestionsAdd || QuestionsAdd}</span>
                      </div>
                      <div className={`${styles.Status} d-flex mt-2`}>
                        <label>Created On:</label>
                        <span>{item.createdOn || CreatedOn}</span>
                      </div>
                    </div>
                    {selectedAssessment !== null &&
                      selectedAssessment === index && (
                        <Popup itemId={item.id} onDelete={handleDelete} />
                      )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default NewAssessment;
