import React, { useState, useEffect } from "react";
import styles from "@/styles/assessments.module.css";
import Image from "next/image";
import uploadimgage from "@/assets/images/uploadimg.svg";
import { BsPlusSquare, BsPencil } from "react-icons/bs";
import { TbMathGreater } from "react-icons/tb";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import AssessmentMobileSideBar from "./AssessmentMobileSideBar";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { useSession } from "next-auth/react";
import ReceiveAllQuestions from "./ReceiveAllQuestions";

const AllQuestionDetails = (props) => {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  // const { data: session } = useSession();
  // const { assessmentId } = props;
  // const [selectedOption, setSelectedOption] = useState("");
  // const [optionsData, setOptionsData] = useState([]);
  // const [receivedQuestions, setReceivedQuestions] = useState(
  //   props.receivedQuestions
  // ); // Set initial value from props

  // console.log("AssessmentId:", assessmentId);

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };
  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };
  // const [selectedOption, setSelectedOption] = useState("");
  // const { optionsData, receivedQuestions } = props;

  // const handleRadioChange = (event) => {
  //   setSelectedOption(event.target.value);
  // };

  // useEffect(() => {
  //   console.log("Fetching data for question ID:", assessmentId); // Add this line for debugging

  //   function fetchData() {
  //     var myHeaders = new Headers();
  //     myHeaders.append("Authorization", "Bearer " + session.user.access_token);
  //     myHeaders.append("Content-Type", "application/json");

  //     var graphql = JSON.stringify({
  //       query: `
  //       query GetQuestions($assessmentId: ID!) {
  //         questions(assessmentId: $assessmentId) {
  //           id,
  //           value
  //           options {
  //             id,
  //             value,
  //             weightage
  //           }
  //         }
  //       }
  //     `,
  //       variables: {
  //         assessmentId: assessmentId,
  //       },
  //     });

  //     var requestOptions = {
  //       method: "POST",
  //       headers: myHeaders,
  //       body: graphql,
  //       redirect: "follow",
  //     };

  //     fetch("http://localhost:9000/assessment-tool/admin", requestOptions)
  //       .then((response) => response.json())
  //       .then((result) => {
  //         console.log("Received questions:", result);
  //         const questions = result.data.questions;
  //         if (questions) {
  //           setReceivedQuestions(questions);
  //           // Organize options by question ID
  //           const optionsByQuestionId = questions.reduce((acc, question) => {
  //             acc[question.id] = question.options;
  //             return acc;
  //           }, {});

  //           setOptionsData(optionsByQuestionId);
  //         }
  //       })
  //       .catch((error) => console.log("error", error));
  //   }

  //   fetchData();
  // }, [assessmentId, session.user.access_token]);

  return (
    <div
      className={`${styles.MyAssessmentcontainerDetail}`}
      onBlur={handleOutsideClick}
    >
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => {}}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}
      <div className="row mt-4">
        <div className="col-12">
          <div className={`d-flex align-items-center ${styles.Detailheader}`}>
            <strong>Test</strong>
            <div className={`d-flex align-items-center ${styles.Dtitle1}`}>
              <span onClick={() => props.stepChange(props.step - 8)}>
                My Assessment
              </span>
              <span className={styles.DtlgreaterSyb}>
                <TbMathGreater />
              </span>
              <strong>Assessment Details</strong>
            </div>
          </div>
        </div>
      </div>
      <div className="row col-12 mt-4">
        <div className="col-3 d-none d-md-block">
          <div className={`${styles.DetailsOptions}`}>
            <div className="d-flex  flex-column justify-content-between">
              <div
                className="p-3"
                onClick={() => props.stepChange(props.step - 1)}
              >
                Basic Details
              </div>
              <div className="d-flex align-items-center">
                <div className={`${styles.Detailbox}`}>
                  <div className={`${styles.Detailboxtext}`}>Questions</div>
                </div>
                <div className={`${styles.VerticalLine}`}></div>
              </div>
              <div
                className="p-3"
                onClick={() => props.stepChange(props.step + 1)}
              >
                Settings
              </div>
              <div className="p-3" onClick={() => props.stepChange(props.step + 2)}>Result&nbsp;Table</div>
            </div>
          </div>
        </div>
        <div
          className={`col-9 d-flex flex-column bg-white ${styles.Detailsdata}`}
        >
          <div className="row mt-2">
            <div className="col-6 mt-2">
              <div className="d-flex align-items-center ">
                <div className={`${styles.DetailSidebar} d-lg-none d-md-none`}>
                  <>
                    <button
                      className={`${styles.btnnewDraftarrow} me-2`}
                      onClick={handleNewButtonClick}
                    >
                      <MdOutlineKeyboardDoubleArrowRight
                        className={`${styles.iconArrorw}`}
                      />
                    </button>
                  </>
                </div>
                <h5 className={styles["custom-heading"]}>All Questions</h5>
              </div>
            </div>
            <div className="col-6">
              <div className={`mr-4 mt-2 ${styles.questionContainer}`}>
                <div className={`${styles.questionTextdiv}`}>
                  <button
                    className={`${styles.questionGroups}`}
                    onClick={() => props.stepChange(props.step - 5)}
                  >
                    <BsPlusSquare className="iconAdd" />
                    <span className="d-none d-md-inline">Add Question</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <ReceiveAllQuestions
            step={props.step}
            stepChange={props.setStep}
            // receivedQuestionId={props.assessmentId}
            receivedQuestion={props.question}
            receivedQuestions={props.receivedQuestions}
            assessmentId={props.assessmentId}
          />
          {/* <div className={`${styles.AllQstTitle}`}>
            <div className={`${styles.PassdataCreate}`}>
              <div className="row">
                <div className="col">
                  {receivedQuestions.map((questionData, index) => (
                    <div
                      className={`${styles.AllQuestionBorder} mt-4`}
                      key={index}
                    >
                      <div className="row mt-4">
                        <div className={`col-6 ${styles.start}`}>
                          <div className={`${styles.questionscoreone}`}>
                            <label>Question {index + 1}</label>
                          </div>
                        </div>
                        <div className={`col-6 ${styles.end}`}>
                          <div className={`${styles.scoreContainer}`}>
                            <div className={`${styles.AllScore}`}>
                              Score: 5
                              <div className={`${styles.dots}`}>
                                <BiDotsVerticalRounded />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-2">
                        <div className="col-12">
                          <label
                            htmlFor="assessmentName"
                            className={`${styles.boldLabel}`}
                          >
                            {questionData.value}
                          </label>
                        </div>
                      </div>
                      <div className="row mt-2">
                        {optionsData[questionData.id] &&
                          optionsData[questionData.id].map(
                            (option, optionIndex) => (
                              <div
                                className="col-12 col-md-4 col-lg-3 col-xl-3"
                                key={optionIndex}
                              >
                                <div
                                  className={`form-check form-check-inline ${styles.StateChoice}`}
                                >
                                  <input
                                    className={`form-check-input form-check-lg ${styles.customCheckbox}`}
                                    type="checkbox"
                                    id={`checkbox${optionIndex}`}
                                    defaultChecked={option.weightage > 0}
                                  />
                                  <label
                                    className={`form-check-label ${styles.labelCustom}`}
                                    htmlFor={`checkbox${optionIndex}`}
                                  >
                                    {option.value}
                                  </label>
                                </div>
                              </div>
                            )
                          )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div> */}
        </div>
      </div>
    </div>
  );
};

export default AllQuestionDetails;

{
  /* <div className={`${styles.AllQstTitle}`}>
            <div className={`${styles.PassdataCreate}`}>
              <div className="row">
                <div className="col">
                  {receivedQuestions.map((questionData, index) => (
                    <div
                      className={`${styles.AllQuestionBorder} mt-4`}
                      key={index}
                    >
                      <div className="row mt-4">
                        <div className={`col-6 ${styles.start}`}>
                          <div className={`${styles.questionscoreone}`}>
                            <label>Question {index + 1}</label>
                          </div>
                        </div>
                        <div className={`col-6 ${styles.end}`}>
                          <div className={`${styles.scoreContainer}`}>
                            <div className={`${styles.AllScore}`}>
                              Score: 5
                              <div className={`${styles.dots}`}>
                                <BiDotsVerticalRounded />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-2">
                        <div className="col-12">
                          <label
                            htmlFor="assessmentName"
                            className={`${styles.boldLabel}`}
                          >
                            {questionData.question || "Default Question"}
                          </label>
                        </div>
                      </div>
                      <div className="row mt-2">
                        {optionsData.map((option, optionIndex) => (
                          <div
                            className="col-12 col-md-4 col-lg-3 col-xl-2"
                            key={optionIndex}
                          >
                            <div
                              className={`form-check form-check-inline ${styles.StateChoice}`}
                            >
                              <input
                                className={`form-check-input form-check-lg ${styles.customCheckbox}`}
                                type="checkbox"
                                id={`checkbox${optionIndex}`}
                                defaultChecked={option.groupscore > 0}
                              />
                              <label
                                className={`form-check-label ${styles.labelCustom}`}
                                htmlFor={`checkbox${optionIndex}`}
                              >
                                {option.EnterOption}
                              </label>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div> */
}
