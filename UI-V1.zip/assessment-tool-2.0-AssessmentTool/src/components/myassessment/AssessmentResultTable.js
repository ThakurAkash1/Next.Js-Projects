import React, { useState, useEffect } from "react";
import styles from "@/styles/assessments.module.css";
// import styles from "@/styles/dashboard.module.css";
import Image from "next/image";
import { TbMathGreater } from "react-icons/tb";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import AssessmentMobileSideBar from "./AssessmentMobileSideBar";
import { useSession } from "next-auth/react";
import Sorting from "@/assets/images/sorting.svg";
import {
  Container,
  Table,
  Pagination,
  Button,
  Dropdown,
} from "react-bootstrap";

const AssessmentResultTable = (props) => {
  const { data: session } = useSession();
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const { assessmentId } = props;
  console.log("AssessmentId:", assessmentId);

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };

  const [submission, setSubmission] = useState([]);
  const [sortColumn, setSortColumn] = useState(null);
  const [sortOrder, setSortOrder] = useState("asc");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  const handlePaginationClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleSort = (column) => {
    if (column === sortColumn) {
      const newSortOrder = sortOrder === "asc" ? "desc" : "asc";
      setSortOrder(newSortOrder);
    } else {
      setSortOrder("asc");
      setSortColumn(column);
    }
  };

  // Function to compare values for sorting
  const compareValues = (key, order = "asc") => {
    return function (a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        return 0;
      }

      const varA = typeof a[key] === "string" ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === "string" ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }

      return order === "desc" ? comparison * -1 : comparison;
    };
  };

  // Sort the submission data based on the selected column and order
  const sortedSubmission = [...submission].sort(
    compareValues(sortColumn, sortOrder)
  );

  // Calculate pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = sortedSubmission.slice(
    indexOfFirstItem,
    indexOfLastItem
  );

  // Calculate total pages
  const totalPages = Math.ceil(sortedSubmission.length / itemsPerPage);

  useEffect(() => {
    callSubmissionApi();
  }, []);

  async function callSubmissionApi() {
    const myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + session?.user?.access_token);
    myHeaders.append("Content-Type", "application/json");

    const graphql = JSON.stringify({
      query:
        "query {\r\n    submissions {\r\n        userName\r\n        assessmentId\r\n        time\r\n        totalScore\r\n    }\r\n}\r\n",
      variables: {},
    });

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: graphql,
      redirect: "follow",
    };

    try {
      const response = await fetch(
        "http://localhost:9001/assessment-tool/admin",
        requestOptions
      );
      const result = await response.json();

      const submissionData = result.data.submissions;

      // Use Promise.all to fetch assessmentGroup and store totalScore and time for each submission
      const updatedSubmissionPromises = submissionData.map((submission) => {
        return callAssessmentApi(
          submission.userName,
          submission.assessmentId,
          submission.totalScore,
          submission.time
        );
      });

      const updatedSubmission = await Promise.all(updatedSubmissionPromises);

      setSubmission(updatedSubmission);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  async function callAssessmentApi(userName, id, totalScore, time) {
    const myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + session.user.access_token);
    myHeaders.append("Content-Type", "application/json");

    const graphql = JSON.stringify({
      query:
        "query{\r\n    assessments {\r\n        id\r\n        assessmentGroup\r\n    }\r\n}",
      variables: {},
    });

    try {
      const response = await fetch(
        "http://localhost:9001/assessment-tool/admin",
        {
          method: "POST",
          headers: myHeaders,
          body: graphql,
          redirect: "follow",
        }
      );

      const result = await response.json();

      // console.log("Assessment API result:", result);

      const assessmentData = result.data.assessments;
      var assessmentGroup = "";

      if (
        result &&
        result.data &&
        assessmentData &&
        assessmentData.length > 0
      ) {
        for (let i = 0; i < assessmentData.length; i++) {
          if (id === assessmentData[i]["id"]) {
            assessmentGroup = assessmentData[i]["assessmentGroup"];
            // console.log(assessmentData[i]["assessmentGroup"])
          }
        }

        return {
          userName,
          assessmentId: id,
          assessmentGroup,
          totalScore,
          submittedOn: time,
        };
      } else {
        console.error("No assessment data found in the response.");
      }
    } catch (error) {
      console.error("Error fetching assessment data:", error);
    }
  }

  return (
    <div
      className={`${styles.MyAssessmentcontainerDetail}`}
      onBlur={handleOutsideClick}
    >
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => {}}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}
      <div className="row mt-4">
        <div className="col-12">
          <div className={`d-flex align-items-center ${styles.Detailheader}`}>
            <strong>Test</strong>
            <div className={`d-flex align-items-center ${styles.Dtitle1}`}>
              <span onClick={() => props.stepChange(props.step - 10)}>
                My Assessment
              </span>
              <span className={styles.DtlgreaterSyb}>
                <TbMathGreater />
              </span>
              <strong>Assessment Details</strong>
            </div>
          </div>
        </div>
      </div>
      <div className="row col-12 mt-4">
        <div className="col-3 d-none d-md-block">
          <div className={`${styles.DetailsOptions}`}>
            <div className="d-flex  flex-column justify-content-between">
              <div
                className="p-3"
                onClick={() => props.stepChange(props.step - 3)}
              >
                Basic Details
              </div>
              <div
                className="p-3"
                onClick={() => props.stepChange(props.step - 2)}
              >
                Questions
              </div>
              <div
                className="p-3"
                onClick={() => props.stepChange(props.step - 1)}
              >
                Settings
              </div>
              <div className="d-flex align-items-center">
                <div className={`${styles.Detailbox}`}>
                  <div className={`${styles.Detailboxtext}`}>
                    Result&nbsp;Table
                  </div>
                </div>
                <div className={`${styles.VerticalLine}`}></div>
              </div>
            </div>
          </div>
        </div>
        <div
          className={`col-9 d-flex flex-column bg-white ${styles.Detailsdata}`}
        >
          <div className="row mt-2">
            <div className="col-6 mt-2">
              <div className="d-flex align-items-center ">
                <div className={`${styles.DetailSidebar} d-lg-none d-md-none`}>
                  <>
                    <button
                      className={`${styles.btnnewDraftarrow} me-2`}
                      onClick={handleNewButtonClick}
                    >
                      <MdOutlineKeyboardDoubleArrowRight
                        className={`${styles.iconArrorw}`}
                      />
                    </button>
                  </>
                </div>

                {/* Dropdown at the top right */}
                <div
                  className={`${styles.DroupdownCointainer} position-absolute end-0 mt-2 me-2`}
                >
                  <Dropdown>
                    {/* <Dropdown.Toggle variant="outline-secondary" id="dropdown-basic"> */}
                    <Dropdown.Toggle
                      className={`${styles.customToggle} d-flex justify-content-between align-items-center`}
                    >
                      Select Category
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1">
                        Development
                      </Dropdown.Item>
                      <Dropdown.Item href="#/action-2">Infrs</Dropdown.Item>
                      <Dropdown.Item href="#/action-3">HR</Dropdown.Item>
                      <Dropdown.Item href="#/action-4">Design</Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </div>

                {/* Other content in your component */}
                <div className="container">
                  <h5 className={`mb-1 ${styles["custom-heading"]}`}>
                    Result&nbsp;Table
                  </h5>
                  <h4
                    className={`my-2 small text-xs ${styles["custom-heading-small"]}`}
                  >
                    Total&nbsp;Respondents&nbsp;:&nbsp;{submission.length}
                  </h4>
                </div>
              </div>
            </div>
          </div>

          <div className="row mt-2">
            <div className="col-12">
              <div className={`${styles.containerDeatail}`}>
                <div className="table-responsive">
                  <table className={`${styles.information}`}>
                    <thead className={`${styles.info}`}>
                      <tr className={`${styles.head}`}>
                        <th>S.No</th>
                        <th
                          className="sortable"
                          onClick={() => handleSort("userName")}
                        >
                          Candidate Name&nbsp;&nbsp;
                          <Image alt="#" src={Sorting} />
                        </th>
                        <th>Group</th>
                        <th
                          className="sortable"
                          onClick={() => handleSort("submittedOn")}
                        >
                          Submitted On&nbsp;&nbsp;
                          <Image alt="#" src={Sorting} />
                        </th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody className={`${styles.Data}`}>
                      {currentItems.map((result, index) => (
                        <tr key={index}>
                          <td>{indexOfFirstItem + index + 1}</td>
                          <td>{result.userName}</td>
                          <td>{result.assessmentGroup}</td>
                          <td>{result.submittedOn}</td>
                          <td
                            className={`${
                              (indexOfFirstItem + index) % 2 === 0
                                ? styles.evenRow
                                : styles.oddRow
                            }`}
                          >
                            {result.totalScore + "%"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Pagination */}
              <div className="d-flex justify-content-center mt-3">
                <Pagination>
                  <Pagination.Prev
                    onClick={() => handlePaginationClick(currentPage - 1)}
                    disabled={currentPage === 1}
                  />
                  {Array.from({ length: totalPages }, (_, index) => (
                    <Pagination.Item
                      key={index + 1}
                      active={index + 1 === currentPage}
                      onClick={() => handlePaginationClick(index + 1)}
                    >
                      {index + 1}
                    </Pagination.Item>
                  ))}
                  <Pagination.Next
                    onClick={() => handlePaginationClick(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  />
                </Pagination>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssessmentResultTable;
