import styles from "@/styles/assessments.module.css";
import documenttwo from "@/assets/images/Steppertwo.svg";
import checkgreen from "@/assets/images/GreenStepper.svg";
import docone from "@/assets/images/StepperNumone.svg";
import line from "@/assets/images/Line3.svg";
import lineone from "@/assets/images/Line5.svg";
import linethree from "@/assets/images/LInethreeStraignt.svg";
import Image from "next/image";
import { BsPlusSquare } from "react-icons/bs";
import { BsFillPenFill, BsPaperclip, BsImageFill } from "react-icons/bs";
import { MdAddToDrive, MdLockClock, MdAttachment } from "react-icons/md";
import { CgSmileMouthOpen } from "react-icons/cg";
import { RiFontColor, RiDeleteBin6Line } from "react-icons/ri";
import { TbMathGreater } from "react-icons/tb";
import React, { useState } from "react";
import { useSession } from "next-auth/react";
import { v4 as uuidv4 } from 'uuid';


const AddQuestions = (props) => {
  const { data: session } = useSession();
  const [selectedOption, setSelectedOption] = useState("");
  const [options, setOptions] = useState([
    { id: 1, EnterOption: "", groupscore: "" },
  ]);
  const [receivedOptionsData, setReceivedOptionsData] = useState([]);
  const [optionsData, setOptionsData] = useState([]);
  const { assessmentId, receivedQuestionId } = props;
  console.log("FromDetailId:", assessmentId);
  console.log("assessmentId:", assessmentId);

  // const handleAddOption = () => {
  //   setOptions((prevOptions) => [
  //     ...prevOptions,
  //     { id: prevOptions.length + 1, EnterOption: "", groupscore: "" },
  //   ]);
  // };
  const handleAddOption = () => {
    setOptions((prevOptions) => [
      ...prevOptions,
      { id: uuidv4(), EnterOption: "", groupscore: "" },
    ]);
  };
  
  const handleDeleteOption = (id) => {
    setOptions((prevOptions) =>
      prevOptions.filter((option) => option.id !== id)
    );
  };
  const handleDropdownChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleInputChange = (arg1, arg2, arg3) => {
    if (typeof arg1 === "string") {
      const field = arg1;
      const value = arg2;

      setFormData((prevData) => ({
        ...prevData,
        [field]: value,
      }));
    } else if (arg1 && arg1.target) {
      const { id, value } = arg1.target;

      setFormData((prevData) => ({
        ...prevData,
        [id]: value,
      }));
    }
  };
  const handleOptionInputChange = (index, field, value) => {
    setOptions((prevOptions) => {
      return prevOptions.map((option, i) => {
        if (i === index) {
          return { ...option, [field]: value };
        }
        return option;
      });
    });
  };

  const handleAddNext = () => {
    handleNextClick();
  }
  const handleNextClick = () => {
    callApi(formData.EnterQuestion, formData.AnswerType, options);
    options.forEach((option) => {
      // Check if groupscore is empty, if so, set it to zero
      if (!option.groupscore) {
        option.groupscore = "0";
      }

      if (option.EnterOption && option.groupscore) {
        callOptionApi(
          receivedQuestionId,
          option.EnterOption,
          option.groupscore
        );

        // Push option data to receivedOptionsData
        receivedOptionsData.push({
          EnterOption: option.EnterOption,
          groupscore: option.groupscore,
        });
      }
    });

    // Set the receivedOptionsData state
    setReceivedOptionsData(receivedOptionsData);

    // props.stepChange(props.step + 1, props.assessmentId);

    // props.onGetId(receivedQuestionId, formData.EnterQuestion);
    props.onGetOptions(options, formData.EnterQuestion);


     // Clear the form data by resetting it to initial values or empty strings
    setFormData({
    EnterQuestion: '', // Reset EnterQuestion to empty string
    AnswerType: '',    // Reset AnswerType to empty string
    // Add other form fields and their initial values here
  });
  };

  const [formData, setFormData] = useState({
    // id: ''
    EnterQuestion: "",
    AnswerType: "",
    // group: ''
    EnterOption: "",
    groupscore: "",
  });

  function callApi(EnterQuestion, AnswerType, options) {
    var myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + session.user.access_token);
    myHeaders.append("Content-Type", "application/json");

    var group = "Developer";
    var receivedOptionsData = [];

    options.forEach((option) => {
      if (option.EnterOption && option.groupscore) {
        callOptionApi(
          receivedQuestionId,
          option.EnterOption,
          option.groupscore
        );
        receivedOptionsData.push({
          EnterOption: option.EnterOption,
          groupscore: option.groupscore,
        });
      }
    });

    setOptionsData(receivedOptionsData);
    props.stepChange(props.step + 1, props.assessmentId);
    // props.onGetId(receivedQuestionId, formData.EnterQuestion);

    var questionGraphql = JSON.stringify({
      query: `mutation {
        newQuestion(assessmentId:"${assessmentId}", value:"${EnterQuestion}", type:"${AnswerType}",group:"${group}"){
          id
        }
      }`,
      variables: {},
    });

    var questionRequestOptions = {
      method: "POST",
      headers: myHeaders,
      body: questionGraphql,
      redirect: "follow",
    };

    fetch("http://localhost:9001/assessment-tool/admin", questionRequestOptions)
      .then((response) => response.json())
      .then((result) => {
        if (
          result.data &&
          result.data.newQuestion &&
          result.data.newQuestion.id
        ) {
          var receivedQuestionId = result.data.newQuestion.id;
          console.log("Received ID (newQuestion):", receivedQuestionId);

          options.forEach((option) => {
            if (option.EnterOption && option.groupscore) {
              callOptionApi(
                receivedQuestionId,
                option.EnterOption,
                option.groupscore
              );
              receivedOptionsData.push({
                EnterOption: option.EnterOption,
                groupscore: option.groupscore,
              });
            }
          });

          console.log("Received Options Data:", receivedOptionsData);
          setOptionsData(receivedOptionsData);
        } else {
          // console.log("No ID received in the response for newQuestion.");
        }
      })
      .catch((error) => console.log("error", error));
  }

  function callOptionApi(questionId, EnterOption, groupscore) {
    var myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + session.user.access_token);
    myHeaders.append("Content-Type", "application/json");

    var optionGraphql = JSON.stringify({
      query: `mutation { 
        newOption(questionId:${questionId},value:"${EnterOption}",weightage:${groupscore}) {
          value
          weightage
        }
      }`,
      variables: {},
    });

    var optionRequestOptions = {
      method: "POST",
      headers: myHeaders,
      body: optionGraphql,
      redirect: "follow",
    };

    fetch("http://localhost:9001/assessment-tool/admin", optionRequestOptions)
      .then((response) => response.json())
      .then((result) => {
        if (result.data && result.data.newOption && result.data.newOption.id) {
          var receivedOptionId = result.data.newOption.id;
          console.log("Received ID (newOption):", receivedOptionId);
        } else {
          console.log("No ID received in the response for newOption.");
        }
      })
      .catch((error) => console.log("error", error));
  }

  return (
    <div className={`${styles.MyAssessmentcontainer} h-100 w-99 d-flex flex-column`}>
      <div className="row">
        <div className="col-sm-12 col-md-12 col-lg-12">
          <div className="containerhead">
            <div
              className={`d-flex align-items-center ${styles.headercontainer}`}
            >
              <h4 className={styles.title}>Create Assessment</h4>
              <h5
                className={`${styles.title1} ${styles.myAssessment}`}
                onClick={() => props.stepChange(props.step - 3)}
              >
                My Assessment
                <span className={styles.greaterThanSymbol}>
                  <TbMathGreater />
                </span>
              </h5>
              <h6 className={styles.title2}>Create New</h6>
            </div>
          </div>
        </div>
      </div>
      <div className="row mt-2">
        <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}>
          <div className="row">
            <div className={`${styles.cointenerstg} col-sm-8 `}>
              <div className="row  row-cols-5">
                {/* Stage 1 */}
                <div
                  className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex`}
                >
                  <span className={`${styles.numbercreate}`}>
                    <Image
                      className={`mt-3 mb-5 ${styles.customImage}`}
                      alt="#"
                      src={checkgreen}
                    />
                  </span>
                  <div className={`col ${styles.customDiv}`}>
                    <span className={`${styles.textcreatebasic}`}>
                      Basic&nbsp;Details
                    </span>
                  </div>
                </div>
                <div
                  className={`${styles.cointenerstageline} col-lg-12 col-md-12`}
                >
                  <Image
                    className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                    alt="#"
                    src={line}
                  />
                  <Image
                    className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                    alt="#"
                    src={linethree}
                  />
                </div>
                {/* Stage 2 */}
                <div
                  className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex`}
                >
                  <span className={`${styles.numbercreate}`}>
                    <Image
                      className={`mt-3 mb-5 ${styles.customImage}`}
                      alt="#"
                      src={docone}
                    />
                  </span>
                  <div className={`col ${styles.customDiv}`}>
                    <span className={`${styles.textcreatebasic}`}>
                      Add&nbsp;Questions
                    </span>
                  </div>
                </div>
                <div
                  className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}
                >
                  <Image
                    className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                    alt="#"
                    src={lineone}
                  />
                  <Image
                    className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                    alt="#"
                    src={linethree}
                  />
                </div>
                {/* Stage 3 */}
                <div
                  className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex`}
                >
                  <span className={`${styles.numbercreate}`}>
                    <Image
                      className={`mt-3 mb-5 ${styles.customImage}`}
                      alt="#"
                      src={documenttwo}
                    />
                  </span>
                  <div className={`col ${styles.customDiv}`}>
                    <span className={`${styles.textcreatebasic}`}>
                      Other&nbsp;Settings
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div
          className="col-xl-9 col-lg-9 col-md-9 col-sm-12"
          style={{
            display: "flex",
            flexDirection: "column",
            backgroundColor: "white",
          }}
        >
          <div className={`row mt-4 ${styles.scrollableRow}`}>
            <div className="col-12">
              <div className={`${styles.MessageboxAdd}`}>
                <div className={`${styles.AddQuestionTitle} ml-4 mt-2`}>
                  <h5>Add Questions</h5>
                </div>
                <h2 className={`${styles.headingQuestion}`}>Question 1</h2>
                <div className={`${styles.fomgrpquestion}`}>
                  <label htmlFor="EnterQuestion">Enter Question</label>
                  <input
                    type="text"
                    placeholder="Enter your question"
                    id="EnterQuestion"
                    className={`${styles.formcontrolquestion}`}
                    value={formData.EnterQuestion}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            </div>
            <div className="col-12">
              <div className={`${styles.fomgrpquestionone} col-12`}>
                <label htmlFor="AnswerType">Answer Type</label>
                <select
                  id="AnswerType"
                  className={`${styles.formcontrolquestionone}`}
                  value={formData.AnswerType}
                  onChange={(e) => {
                    handleDropdownChange(e);
                    handleInputChange(e);
                  }}
                >
                  <option value="select" defaultValue hidden>
                    Select
                  </option>
                  <option value="multiple-choice">Multiple Choice</option>
                  <option value="true-false">True/False</option>
                  <option value="textual">Textual</option>
                </select>
                {selectedOption === "multiple-choice" && (
                  <div id="multiple-choice" className={styles.contentdropdown}>
                    <div className="col ml-4 mt-3">
                      <h6>
                        Select the correct answer and mention score for each
                        correct answer
                      </h6>
                    </div>
                    <div className="row">
                      {options.map((option, index) => (
                        <div
                          className="col-lg-6 col-md-6 col-sm-12 mt-2"
                          key={index}
                        >
                          {index >= 2 && (
                            <div
                              className={`${styles.DeleteOne} `}
                              onClick={() => handleDeleteOption(index)}
                            >
                              <RiDeleteBin6Line />
                            </div>
                          )}
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="checkbox"
                              className={`${styles.CheckOne}`}
                            />
                          </div>
                          <div
                            className={`question-box ${styles["question-box"]}`}
                          >
                            <textarea
                              id={`EnterOption_${index}`}
                              className={`${styles.Textelement}`}
                              value={option.EnterOption}
                              onChange={(e) =>
                                handleOptionInputChange(
                                  index,
                                  "EnterOption",
                                  e.target.value
                                )
                              }
                            />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                          <div className={`col-sm ${styles.Scoreone}`}>
                            <label htmlFor="group">Score:</label>
                            <input
                              type="text"
                              id={`groupscore_${index}`}
                              className={`${styles.formsropeone}`}
                              value={option.groupscore}
                              onChange={(e) =>
                                handleOptionInputChange(
                                  index,
                                  "groupscore",
                                  e.target.value
                                )
                              }
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="col-12">
                      <div className={`${styles.Addoption} mt-4 mb-2`}>
                        <button
                          className={`${styles.Addoptionbutton}`}
                          onClick={handleAddOption}
                        >
                          <BsPlusSquare className={`${styles.iconoption}`} />{" "}
                          Add Option
                        </button>
                      </div>
                    </div>
                  </div>
                )}
                {selectedOption === "true-false" && (
                  <div className={`${styles.textualDropdown}`}>
                    <h6>Select the correct option</h6>
                    <div className="row ">
                      {/* Options */}
                      {options.map((option, index) => (
                        <div
                          className="col-lg-6 col-md-6 col-sm-12"
                          key={index}
                        >
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="radio"
                              className={`${styles.CheckOne}`}
                            />
                          </div>
                          <div
                            className={`question-boxarea ${styles["question-boxarea"]}`}
                          >
                            <textarea
                              id={`EnterOption_${index}`}
                              className={`${styles.Textelementarea}`}
                              value={option.EnterOption}
                              onChange={(e) =>
                                handleOptionInputChange(
                                  index,
                                  "EnterOption",
                                  e.target.value
                                )
                              }
                            />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                        </div>
                      ))}
                      {/* Options */}
                      <div className="col-lg-6 col-md-6 col-sm-12">
                        <div className={`${styles.checkBox}`}>
                          <input
                            type="radio"
                            className={`${styles.Checktwo}`}
                          />
                        </div>
                        <div
                          className={`question-boxareaone ${styles["question-boxareaone"]}`}
                        >
                          <textarea className={`${styles.Textelementarea}`} />
                          <div className={`${styles.groupIcons}`}>
                            <RiFontColor />
                            <BsPaperclip />
                            <MdAttachment />
                            <CgSmileMouthOpen />
                            <MdAddToDrive />
                            <BsImageFill />
                            <MdLockClock />
                            <BsFillPenFill />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                {selectedOption === "textual" && (
                  <div id="textual" className={styles.contentdropdown}>
                    <div className="col ml-4 mt-3">
                      <h6>Enter Answer below</h6>
                    </div>
                    <div className="row row-col-12">
                      {options.map((option, index) => (
                        <div className="col-12" key={index}>
                          <div className={`${styles.Textualbox}`}>
                            <textarea
                              placeholder="Add possible answer to the question"
                              id="textBox"
                              className="form-control"
                              value={option.EnterOption}
                              onChange={(e) =>
                                handleOptionInputChange(
                                  index,
                                  "EnterOption",
                                  e.target.value
                                )
                              }
                              style={{ height: "130px" }}
                            ></textarea>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className={`${styles.ContainerAddQ}`}>
            <div className="row">
              <div className="col-lg-3 col-md-3 col-sm-4 col-6 ">
                <div className={`${styles.PreviousButton}`}>
                  <button
                    className={`${styles.PreviousBtn}`}
                    onClick={() => props.stepChange(props.step - 2)}
                  >
                    Cancel
                  </button>
                </div>
              </div>
              <div className="col-lg-4 col-md-4 col-sm-4 col-6 ">
                <div className={`${styles.nextBtnn}`}>
                  <button
                    className={`${styles.nextbuttonn}`}
                    onClick={() => {
                      handleNextClick();
                      props.stepChange(props.step + 1);
                    }}
                  >
                    Save and exit
                  </button>
                </div>
              </div>
              <div className="col-lg-5 col-md-5 col-sm-4 col-8 ">
                <div className={`${styles.nextBtnnone}`}>
                  <button className={`${styles.nextbuttonnone}`} onClick={() => {
                      handleAddNext();
                    }}>
                    Save and add next
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddQuestions;
