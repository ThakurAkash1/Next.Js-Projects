import React, { useState, useEffect } from 'react';
import account from "@/assets/images/accout.svg"
import Image from "next/image"
import styles from "@/styles/dashboard.module.css"
import { useSession } from 'next-auth/react';

const TopScores = ({ topScoresData }) => {
  const scoreColors = [
    { text: '#0095FF', border: '#0095FF', background: '#F0F9FF' },
    { text: '#10B276', border: '#10B276', background: '#F0FDF4' },
    { text: '#884DFF', border: '#884DFF', background: '#FBF1FF' },
    { text: '#FF8900', border: '#FF8900', background: '#FEF6E6' },
  ];
  const { data: session } = useSession();
  const [submission, setSubmission] = useState([])

  useEffect(() => {
    callTopScoresApi();
  }, []);

  const getScoreColor = (index) => {
    const colorIndex = index % scoreColors.length;
    return scoreColors[colorIndex];
  };

  async function callTopScoresApi() {
    const myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + session?.user?.access_token);
    myHeaders.append("Content-Type", "application/json");

    const graphql = JSON.stringify({
      query: "query {\r\n    submissions {\r\n        userName\r\n        assessmentId\r\n        time\r\n        totalScore\r\n    }\r\n}\r\n",
      variables: {}
    });

    const requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: graphql,
      redirect: 'follow'
    };

    try {
      const response = await fetch("http://localhost:9001/assessment-tool/admin", requestOptions);
      const result = await response.json();

      const submissionData = result.data.submissions;

      const sortedScores = submissionData
        .map((item) => [item.userName, item.totalScore])
        .sort((a, b) => b[1] - a[1]);

      const top4Scores = sortedScores.slice(0, 4);

      setSubmission(top4Scores);


    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  return (
    <div>
      <h5 className={`${styles.topscoreheading}`}>Top Scores</h5>
      <table className={`col-md-6 ${styles.topScoreTable}`}>
        <tbody>
          {submission.map((result, index) => {
            // console.log(`Result: ${result}, ${index}`)
            const candidateName = result ? result[0] : 'N/A';
            const score = result ? result[1] : 'N/A';
            const { text: textColor, border: borderColor, background: backgroundColor } = getScoreColor(index);
            const scoreStyle = {
              color: textColor,
              border: `1px solid ${borderColor}`,
              backgroundColor: backgroundColor,
            };

            return (
              <tr key={index} className={`${styles.totalrowTopscores}`}>
                <td><Image className={`${styles.account}`} alt="#" src={account} /></td>
                <td className={`${styles.candidateName}`}>{candidateName}</td>
                <td></td>
                <td className={`${styles.score}`} style={scoreStyle}>{score + "%"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default TopScores;
