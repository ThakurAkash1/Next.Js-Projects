import React, { useState, useEffect } from 'react';
import Image from "next/image";
import styles from "@/styles/dashboard.module.css";
import totalAssessments from "@/assets/images/total-assessments.svg";
import publishedAssessments from "@/assets/images/published-assessments.svg";
import draftsAssessments from "@/assets/images/drafts-assessments.svg";
import intakeAssessments from "@/assets/images/intake-assessments.svg";
import { useSession } from "next-auth/react";

const Overview = () => {
  const [assessments, setAssessments] = useState([]);
  const [totalAssessmentsCount, setTotalAssessmentsCount] = useState(0);
  const [publishedCount, setPublishedCount] = useState(0);
  const [draftCount, setDraftCount] = useState(0);
  const [intakeCount, setIntakeCount] = useState(0);
  const { data: session } = useSession();

  useEffect(() => {
    callOverviewApi(); 
  }, []);

  const filterAssessmentsByStatus = (status) => {
    return assessments.filter((assessment) => assessment.status === status);
  };
  // var accessToken = session.access_token

  function callOverviewApi() {
    var myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + session?.user?.access_token);
    myHeaders.append("Content-Type", "application/json");

    var graphql = JSON.stringify({
      query: "query {\r\n    assessments {\r\n        id\r\n        status\r\n       \r\n    }\r\n}\r\n",
      variables: {}
    });

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: graphql
    };

    fetch("http://localhost:9001/assessment-tool/admin", requestOptions)
      .then(response => response.json())
      .then(result => {
        const assessmentsData = result.data.assessments;
        setAssessments(assessmentsData);

        const totalAssessmentsCount = assessmentsData.length;
        setTotalAssessmentsCount(totalAssessmentsCount);

        const publishedAssessmentsCount = assessmentsData.filter(assessment => assessment.status === 'PUBLISHED').length;
        setPublishedCount(publishedAssessmentsCount);

        const draftAssessmentsCount = assessmentsData.filter(assessment => assessment.status === 'DRAFT').length;
        setDraftCount(draftAssessmentsCount);

        const intakeAssessmentsCount = assessmentsData.filter(assessment => assessment.status === 'INTAKE').length;
        setIntakeCount(intakeAssessmentsCount);
      })
      .catch(error => console.log('error', error));
  }

  return (
    <div className={` ${styles.containeroverview}`}>
      <div className={`${styles.overview}`}>
        <h5 className={`${styles.topscoreheading}`}>Overview</h5>
      </div>
      <div className='row'>
        <div className='col-6 col-sm-3 col-md-6 col-lg-6 col-xl-3'>
          <div className={`${styles.TotalAssessment}`}>
            <div className={`${styles.Assessments}`}>
              <Image className="mt-3 mb-5" alt="#" src={totalAssessments} />
            </div>
            <h5 className={`${styles.heading5}`}>{totalAssessmentsCount}</h5><br />
            <span><h6 className={`${styles.heading}`}>Total Assessments</h6></span>
          </div>
        </div>
        <div className='col-6 col-sm-3 col-md-6 col-lg-6 col-xl-3'>
          <div className={`${styles.Published}`}>
            <div className={`${styles.publishedAssessments}`}>
              <Image className="mt-3 mb-5" alt="#" src={publishedAssessments} />
            </div>
            <h5 className={`${styles.heading5}`}>{publishedCount}</h5><br />
            <span><h6 className={`${styles.heading}`}>Published</h6></span>
            
          </div>
        </div>

        <div className='col-6 col-sm-3 col-md-6 col-lg-6 col-xl-3'>
          <div className={`${styles.Draft}`}>
            <div className={`${styles.DraftAssessments}`}>
              <Image className="mt-3 mb-5" alt="#" src={draftsAssessments} />
            </div>
            <h5 className={`${styles.heading5}`}>{draftCount}</h5><br />
            <h6 className={`${styles.heading}`}>Drafts</h6>
          </div>
        </div> 
        <div className='col-6 col-sm-3 col-md-6 col-lg-6 col-xl-3'>
          <div className={`${styles.Intake}`}>
            <div className={`${styles.intakeAssessments}`}>
              <Image className="mt-3 mb-5" alt="#" src={intakeAssessments} />
            </div>
            <h5 className={`${styles.heading5}`}>{intakeCount}</h5><br />
            <h6 className={`${styles.heading}`}>Assignment Intake</h6>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Overview;