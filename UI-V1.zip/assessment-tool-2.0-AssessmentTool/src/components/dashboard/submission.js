import React, { useState, useEffect } from 'react';
import styles from '@/styles/dashboard.module.css';
import { Line } from 'react-chartjs-2';
import { Button } from 'react-bootstrap';
import { useSession } from 'next-auth/react';
import ChartJS from 'chart.js/auto';

const SubmissionChart = () => {
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [selectedTimeline, setSelectedTimeline] = useState('interval1'); // Default to weekly
  const [chartData, setChartData] = useState(null); // State to hold chart data

  const [startDate, setStartDate] = useState(new Date()); // Default to current date
  const [endDate, setEndDate] = useState(new Date()); // Default to current date
  const { data: session } = useSession();



  useEffect(() => {
    fetchChartData();
  }, [selectedTimeline, startDate, endDate]);

  const fetchChartData = () => {
    if (selectedTimeline === 'interval1') {
      // Weekly data
      const today = new Date();
      const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const todayIndex = today.getDay();
      console.log("current date:",today)

      // Calculate the starting day of the week based on the current day
      const startOfWeekIndex = todayIndex - 6 < 0 ? todayIndex - 6 + 7 : todayIndex - 6;
      const labels = [];

      for (let i = 0; i < 7; i++) {
        const index = startOfWeekIndex + i >= 7 ? startOfWeekIndex + i - 7 : startOfWeekIndex + i;
        labels.push(days[index]);
      }

      setChartData({
        labels: labels,
        datasets: [
          {
            label: 'Dataset 2',
            type: 'line',
            data: [65, 85, 90, 65, 45, 80, 50], 
            // fill: true,
            backgroundColor: 'rgba(255, 113, 139, 0.3)',
            borderColor: '#FF718B',
          },
          {
            label: 'Dataset 1',
            type: 'bar',
            data: [60, 80, 90, 70, 40, 75, 45], 
            backgroundColor: 'rgba(37, 118, 239, 0.7)',
          },
        ],
      });
    } else if (selectedTimeline === 'interval2') {
      // Monthly data
      const today = new Date();
      const oneMonthAgo = new Date(today);
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
    
      const labels = [];
      const monthlyData = [];
      const monthlyData1 = []; // New array for Monthly Data 1
    
      let currentDate = new Date(oneMonthAgo);
    
      while (currentDate <= today) {
        const month = currentDate.toLocaleString('default', { month: 'short' });
        const dayOfMonth = currentDate.getDate();
        labels.push(`${month} ${dayOfMonth}`);
    
        // Generate random data for both Monthly Data and Monthly Data 1
        // const dataPoint = Math.floor(Math.random() * 100);

        // Fetch data for the current date using the fetchDataForDate function
        const dataPoint = fetchDataForDate(currentDate);

        monthlyData.push(dataPoint);
        monthlyData1.push(dataPoint); // Use the same data point for both datasets
    
        currentDate.setDate(currentDate.getDate() + 1); // Move to the next day
      }
    
      setChartData({
        labels: labels,
        datasets: [
          {
            label: 'Monthly Data',
            type: 'line',
            data: monthlyData, 
            // fill: true,
            backgroundColor: 'rgba(255, 113, 139, 0.3)',
            borderColor: '#FF718B',
          },
          {
            label: 'Monthly Data 1',
            type: 'bar',
            data: monthlyData1, 
            backgroundColor: 'rgba(37, 118, 239, 0.7)',
          },
        ],
    
      });
    } else if (selectedTimeline === 'interval3') {
      // Custom range data
      const labels = [];
      const customData = [];

      let currentDate = new Date(startDate);

      while (currentDate <= endDate) {
        // Fetch data for the current date and push it to customData array
        const dataPoint = fetchDataForDate(currentDate);
        customData.push(dataPoint);

        // Add label for the current date
        labels.push(formatDate(currentDate));

        // Move to the next day
        currentDate.setDate(currentDate.getDate() + 1);
      }

      // Set chart data with the fetched custom data
      setChartData({
        labels: labels,
        datasets: [
          {
            label: 'Line',
            type: 'line',
            data: customData,
            // fill: true,
            backgroundColor: 'rgba(255, 113, 139, 0.3)',
            borderColor: '#FF718B',
          },
          {
            label: 'Bar',
            type: 'bar',
            data: customData,
            backgroundColor: 'rgba(37, 118, 239, 0.7)',
          },
        ],
      });
    }
  };


  const formatDate = (date) => {
    // Format the date as needed (e.g., 'MMM dd')
    return date.toLocaleString('default', { month: 'short', day: '2-digit' });
  };

  // Function to fetch data for a specific date
  const fetchDataForDate = (date) => {
    return Math.floor(Math.random() * 100);
  };


  const handleDepartmentChange = (event) => {
    setSelectedDepartment(event.target.value);  
  };

  const handleTimelineChange = (event) => {
    setSelectedTimeline(event.target.value);
  };

  const options = {
    responsive: true,
    tension: 0.5,
    plugins: {
      legend: {
        position: 'top',
      },
    },
  };

  return (
    <div>
      <div className={styles.topBar}>
        <h5 className={`${styles.topscoreheading}`}>Submission Returns</h5>
        <div className={styles.dropdowns}>
          <select id="categoryDropdown" value={selectedDepartment} onChange={handleDepartmentChange}>
            <option value="category1">Development</option>
            <option value="category2">HR</option>
            <option value="category3">Infra 2</option>
          </select>
          <select id="intervalDropdown" value={selectedTimeline} onChange={handleTimelineChange}>
            <option value="interval1">Weekly</option>
            <option value="interval2">Monthly</option>
            <option value="interval3">Custom Range</option>
          </select>
          {selectedTimeline === 'interval3' && (
          <>
            <input type="date" value={startDate.toISOString().split('T')[0]} onChange={(e) => setStartDate(new Date(e.target.value))} />
            <input type="date" value={endDate.toISOString().split('T')[0]}  onChange={(e) => setEndDate(new Date(e.target.value))} />
          </>
        )}
        </div>
      </div>
      {chartData && <Line options={options} data={chartData} />} {/* Render chart only if data is available */}
    </div>
  );
};

export default SubmissionChart;









    // else if (selectedTimeline === 'interval2') {
    //   // Monthly data
    //   const today = new Date();
    //   const oneMonthAgo = new Date(today);
    //   oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

    //   const labels = [];
    //   const monthlyData = [];

    //   let currentDate = new Date(oneMonthAgo);

    //   while (currentDate <= today) {
    //     const month = currentDate.toLocaleString('default', { month: 'short' });
    //     const dayOfMonth = currentDate.getDate();
    //     labels.push(`${month} ${dayOfMonth}`);

    //     monthlyData.push(Math.floor(Math.random() * 100));

    //     currentDate.setDate(currentDate.getDate() + 1); // Move to the next day
    //   }

    //   setChartData({
    //     labels: labels,
    //     datasets: [
    //       {
    //         label: 'Monthly Data',
    //         type: 'line',
    //         data: monthlyData, 
    //         fill: true,
    //         backgroundColor: 'rgba(255, 113, 139, 0.3)',
    //         borderColor: '#FF718B',
    //       },
    //       {
    //         label: 'Monthly Data 1',
    //         type: 'bar',
    //         data: [60, 80, 90, 70, 40, 75, 45], 
    //         backgroundColor: 'rgba(37, 118, 239, 0.7)',
    //       },
    //     ],


// import React, { useState } from 'react';
// import styles from '@/styles/dashboard.module.css';
// import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, PointElement, LineElement } from 'chart.js';
// import { Bar, Line } from 'react-chartjs-2';
// import { Button } from 'react-bootstrap';
// import { useSession } from 'next-auth/react';

// ChartJS.register(
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   Title,
//   Tooltip,
//   Legend,
//   PointElement,
//   LineElement
// );

// export const options = {
//   responsive: true,
//   tension: 0.5,
//   plugins: {
//     legend: {
//       position: 'top',
//     },
//   },
// };



// const labels = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
// const labelsMonthly = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31'];

// export const data = {
//   labels,
//   datasets: [
//     {
//       label: 'Dataset 2',
//       type: 'line',
//       data: [65, 85, 90, 65, 45, 80, 50],
//       fill: true,
//       backgroundColor: '#FF718B',
//       borderColor: '#FF718B',
//       fillColor: (context) => {
//         const ctx = context.chart.ctx;
//         const gradient = ctx.createLinearGradient(0, 0, 0, 200);
//         gradient.addColorStop(0, 'rgba(250,174,50,1)');
//         gradient.addColorStop(1, 'rgba(250,174,50,0)');
//         return gradient;
//       },
//     },
//     {
//       label: 'Dataset 1',
//       type: 'bar',
//       data: [60, 80, 90, 70, 40, 75, 45],
//       backgroundColor: '#2576EF',
//     },
//   ],
// };

// const SubmissionChart = () => {
//   const [selectedDepartment, setSelectedDepartment] = useState('');
//   const [selectedTimeline, setSelectedTimeline] = useState('');
//   const { data: session } = useSession();


//   const handleDepartmentChange = (event) => {
//     setSelectedDepartment(event.target.value);
//   };

//   const handleTimelineChange = (event) => {
//     setSelectedTimeline(event.target.value);
//   };

//   function callTimeApi() {
//     var myHeaders = new Headers();
//     myHeaders.append("Authorization", "Bearer " + session.user.access_token);
//     myHeaders.append("Content-Type", "application/json");

//     var graphql = JSON.stringify({
//       query: "query {\r\n    submissions {\r\n        time\r\n        totalScore\r\n    }\r\n}\r\n",
//       variables: {}
//     })
//     var requestOptions = {
//       method: 'POST', 
//       headers: myHeaders,
//       body: graphql
//     };

//     fetch("http://localhost:9000/assessment-tool/admin", requestOptions)
//       .then(response => response.json())
//       .then(result => console.log(result))
//       .catch(error => console.log('error', error));

//   }
 
//   const handleTestButtonClick = () => {
//     callTimeApi();
//   };
  
//   return (
//     <div>
//       <Button onClick={handleTestButtonClick}>Time</Button>
//       <div className={styles.topBar}>
//         <h5 className={`${styles.topscoreheading}`}>Submission</h5>
//         <div className={styles.dropdowns}>

//           <select id="categoryDropdown" value={selectedDepartment} onChange={handleDepartmentChange}>
//             <option value="category1">Development</option>
//             <option value="category2">HR</option>
//             <option value="category3">Infra 2</option>
//           </select>

//           <select id="intervalDropdown" value={selectedTimeline} onChange={handleTimelineChange}>
//             <option value="interval1">Weekly</option>
//             <option value="interval2">Monthly</option>
//             <option value="interval3">Custom Range</option>
//           </select>

//         </div>
//       </div>

//       <Line options={options} data={data} />
//     </div>
//   );
// };

// export default SubmissionChart;