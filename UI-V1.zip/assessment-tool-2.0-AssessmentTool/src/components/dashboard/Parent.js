import React from "react";

const Parent = () => {
    const [displayFocus, setDisplayFocus] = useState({
        dashboard: true,
        assessment: false,
        reports: false,
        user_management: false
    })

    return (
        <div>
            {displayFocus.dashboard ? null : null}
        </div>
    )
};

export default Parent;