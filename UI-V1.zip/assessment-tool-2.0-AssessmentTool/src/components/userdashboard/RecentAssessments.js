import React, { useState } from 'react';
import ResentAssessmentData from './RecentAssessmentData';
import styles from "@/styles/userdashboard.module.css";

const RecentAssessment = () => {
  const [showAll, setShowAll] = useState(false);
  const initialRowCount = 5;

  const toggleShowAll = () => {
    setShowAll(!showAll);
  };

  const dataToShow = showAll ? ResentAssessmentData : ResentAssessmentData.slice(0, initialRowCount);

  return (
    <div className={`${styles.container}`}>
      <div>
      <h5 className={`${styles.topscoreheading}`}>Recent Assessments</h5>
      <button className={`${styles.viewAllButton}`} onClick={toggleShowAll}>
        {showAll ? 'Show Less' : 'View All'}
      </button>
      </div>
      <br />
      <div className="table-responsive-sm">
        <table className={`${styles.information}`}>
          <thead className={`${styles.info}`}>
            <tr className={`${styles.head}`} >
              <th>S.No</th>
              <th>Assessment Name</th>
              <th>Group</th>
              <th>Status</th>
              <th>Submitted On</th>
              <th>Score</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody className={`${styles.Data}`} >
            {dataToShow.map((resentassessment, index) => (
              <tr key={index}  >
                <td>{resentassessment.sno}</td>
                <td>{resentassessment.assessmentName}</td>
                <td>{resentassessment.group}</td>
                <td>{resentassessment.status}</td>
                <td>{resentassessment.submittedOn}</td>
                <td>{resentassessment.score}</td>
                <td>{resentassessment.Action}</td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
    </div>
  );
};

export default RecentAssessment;
