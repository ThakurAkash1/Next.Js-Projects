import React, { useState, useEffect } from 'react';
import Image from "next/image";
import styles from "@/styles/userdashboard.module.css";
import totalAssessments from "@/assets/images/total-assessments.svg";
import publishedAssessments from "@/assets/images/published-assessments.svg";
import draftsAssessments from "@/assets/images/drafts-assessments.svg";
import intakeAssessments from "@/assets/images/intake-assessments.svg";

const UserOverview = () => {
  const [assessments, setAssessments] = useState([]);


  const filterAssessmentsByStatus = (status) => {
    return assessments.filter((assessment) => assessment.status === status);
  };

  return (
    
    <div className={` ${styles.containeroverview}`} style={{border: "none" }}>
      <div className={`${styles.overview}`} style={{border: "none" }} >
      <h5 className={`${styles.topscoreheading}`}>Overview</h5>
      </div>
      <div className='row'>
        <div className='col-6 col-sm-3 col-md-6 col-lg-6 col-xl-3'>
          <div className={`${styles.TotalAssessment}`}>
            <div className={`${styles.Assessments}`}>
              <Image className="mt-3 mb-5" alt="#" src={totalAssessments} />
            </div>
            <h5 className={`${styles.heading5}`}>{filterAssessmentsByStatus('assessments').length}</h5><br />
            <span><h6 className={`${styles.heading}`}>Assessment Intakes</h6></span>
            <ul>
              {filterAssessmentsByStatus('assessments').map((assessment) => (
                <li key={assessment.id}>{assessment.title}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className='col-6 col-sm-3 col-md-6 col-lg-6 col-xl-3'>
          <div className={`${styles.Published}`}>
            <div className={`${styles.publishedAssessments}`}>
              <Image className="mt-3 mb-5" alt="#" src={publishedAssessments} />
            </div>
            <h5 className={`${styles.heading5}`}>{filterAssessmentsByStatus('published').length}</h5><br />
            <span className={`${styles.title}`}><h6 className={`${styles.heading}`}>Passed Assessment</h6></span>
            <ul>
              {filterAssessmentsByStatus('published').map((assessment) => (
                <li key={assessment.id}>{assessment.title}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className='col-6 col-sm-3 col-md-6 col-lg-6 col-xl-3'>
          <div className={`${styles.Draft}`}>
            <div className={`${styles.DraftAssessments}`}>
              <Image className="mt-3 mb-5" alt="#" src={draftsAssessments} />
            </div>
            <h5 className={`${styles.heading5}`}>{filterAssessmentsByStatus('draft').length}</h5><br />
            <h6 className={`${styles.heading}`}>Failed Assessment</h6>
            <ul>
              {filterAssessmentsByStatus('draft').map((assessment) => (
                <li key={assessment.id}>{assessment.title}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className='col-6 col-sm-3 col-md-6 col-lg-6 col-xl-3'>
          <div className={`${styles.Intake}`}>
            <div className={`${styles.intakeAssessments}`}>
              <Image className="mt-3 mb-5" alt="#" src={intakeAssessments} />
            </div>
            <h5 className={`${styles.heading5}`}>{filterAssessmentsByStatus('intake').length}</h5><br />
            <h6 className={`${styles.heading}`}>Pending Assessment</h6>
            <ul>
              {filterAssessmentsByStatus('intake').map((assessment) => (
                <li key={assessment.id}>{assessment.title}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserOverview;
