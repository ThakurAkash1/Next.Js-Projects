import React from 'react';

const ResentAssessmentData = [
  {
    sno: 1,
    assessmentName: 'Core Principles',
    group: 'Development',
    status: <span style={{ color: 'red' }}>Pending</span>,
    submittedOn: '24-05-2023,11:00 AM',
    score: '-',
    Action: '-'
  },
  {
    sno: 2,
    assessmentName: 'Java Basics',
    group: 'Development',
    status: <span style={{ color: 'green' }}>Completed</span>,
    submittedOn: '24-05-2023,11:00 AM',
    score: <span style={{ backgroundColor: '#A0DCA6', color: 'black' }}>80%</span>,
    Action: <span style={{ color: 'blue' }}>View Certificate</span>
  },
  {
    sno: 3,
    assessmentName: 'Test Assignment',
    group: 'Development',
    status: <span style={{ color: 'green' }}>Completed</span>,
    submittedOn: '24-05-2023,11:00 AM',
    score: <span style={{ backgroundColor: '#A0DCA6', color: 'black' }}>60%</span>,
    Action: <span style={{ color: 'blue' }}>View Certificate</span>
  },
  {
    sno: 4,
    assessmentName: 'Test Assignment-2',
    group: 'Development',
    status: <span style={{ color: 'green' }}>Completed</span>,
    submittedOn: '24-05-2023,11:00 AM',
    score: <span style={{ backgroundColor: '#A0DCA6', color: 'black' }}>75%</span>,
    Action: <span style={{ color: 'blue' }}>View Certificate</span>
  },
  {
    sno: 5,
    assessmentName: 'Data Variables',
    group: 'Development',
    status: <span style={{ color: 'green' }}>Completed</span>,
    submittedOn: '24-05-2023,11:00 AM',
    score: <span style={{ backgroundColor: '#A0DCA6', color: 'black' }}>80%</span>,
    Action: <span style={{ color: 'blue' }}>View Certificate</span>
  },
  {
    sno: 6,
    assessmentName: 'Java Script',
    group: 'Development',
    status: <span style={{ color: 'green' }}>Completed</span>,
    submittedOn: '24-05-2023,11:00 AM',
    score: <span style={{ backgroundColor: '#A0DCA6', color: 'black' }}>70%</span>,
    Action: <span style={{ color: 'blue' }}>View Certificate</span>
  },
  {
    sno: 7,
    assessmentName: 'Python',
    group: 'Development',
    status: <span style={{ color: 'green' }}>Completed</span>,
    submittedOn: '24-05-2023,11:00 AM',
    score: <span style={{ backgroundColor: '#A0DCA6', color: 'black' }}>80%</span>,
    Action: <span style={{ color: 'blue' }}>View Certificate</span>
  },
];

export default ResentAssessmentData;