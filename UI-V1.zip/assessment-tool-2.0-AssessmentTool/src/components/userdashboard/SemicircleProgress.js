import React from 'react';
import styles from '@/styles/userdashboard.module.css';


const SemicircleProgress = ({ progress }) => {
    const strokeWidth = 17;
    const radius = 90 - strokeWidth / 6;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference * (1 - progress);

    // Define gradient colors and their positions
    const gradientColors = [
        { color: '#A855F7', offset: 0 },
        { color: '#3B82F6', offset: 50 },
        { color: '#14B8A6', offset: 100 },
    ];

    // Create a gradient element with the defined colors
    const gradient = (
        <defs>
            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                {gradientColors.map((color, index) => (
                    <stop
                    key={index}
                    offset={`${color.offset}%`}
                    stopColor={color.color}
                />
                ))}
            </linearGradient>
        </defs>
    );

    return (
        <svg className={styles.progress} width="250px" height="80px">
            {gradient}
            <circle
                className={styles.circle}
                cx="48%"
                // cy="50"
                cy={radius + strokeWidth / 2}
                r={radius}
                fill="transparent"
                stroke="lightgray"
                strokeWidth={strokeWidth}
            />
            <circle
                className={styles.circle}
                cx="48%"
                // cy="50"
                cy={radius + strokeWidth / 2} 
                r={radius}
                fill="transparent"
                stroke="url(#progressGradient)"
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={offset}
            />

            <text
                x="50%"
                y="70%"
                textAnchor="middle"
                dominantBaseline="middle"
                fill="#0A0A0A"
                fontSize="18"
                fontWeight="bold"
            >
                {`${Math.round(progress * 100)}`}
            </text>
            <text
                x="50%"
                y="90%"
                textAnchor="middle"
                dominantBaseline="middle"
                fill="#737373"  
                fontSize="14"
                fontWeight="normal"
            >
                Points
            </text>
        </svg>
    );
};

export default SemicircleProgress;