//  ----------------the bar should be stable at a particular value-----------

import React from 'react';
import SemicircleProgress from './SemicircleProgress';
import styles from '@/styles/userdashboard.module.css';

const Performance = () => {
    // Set a fixed value for progress
    const fixedProgress = 0.85;

    return (
        <div className={`col-md-4 col-sm-6 mb-4 ${styles.userAvgPerformace}`}>
            <div className={`${styles.Average}`}>
                <div style={{ height: "200px" }}>
                    <div className={`card-body d-flex align-items-center ${styles.AverageCard}`}>
                        <div className="d-flex flex-column">
                            <div className={`${styles.Average1}`}>
                                <h4 style={{ marginBottom: "2" }}>Average&nbsp;Performance</h4>
                            </div>
                            <div className={`${styles.SemicircleProgress}`}>
                                <SemicircleProgress progress={fixedProgress} />
                            </div>
                            <div className={`${styles.Average2}`}>
                                <span>
                                    Your&nbsp;Assessment&nbsp;Score&nbsp;is&nbsp;
                                    <span style={{ color: "green" }}>Excellent</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Performance;


