
const MyAssessmentData = [
  // {
  //   title: 'JAVA Basics',
  //   description: 'Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.',
  //   Status: 'Development',
  //   TimetoComplete: '30 mins',
  //   Questions: '14',
  //   CreatedOn: '20 April, 12:00 am'
  // },
  // {
  //   title: 'UI/UX Fundamentals',
  //   description: 'Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.',
  //   Status: 'Design',
  //   TimetoComplete: '30 mins',
  //   Questions: '14',
  //   CreatedOn: '20 April, 12:00 am'
  // },
  // {
  //   title: 'Python',
  //   description: 'Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.',
  //   Status: 'Development',
  //   TimetoComplete: '30 mins',
  //   Questions: '14',
  //   CreatedOn: '20 April, 12:00 am'
  // },
  // {
  //   title: 'Python',
  //   description: 'Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.',
  //   Status: 'Development',
  //   TimetoComplete: '30 mins',
  //   Questions: '14',
  //   CreatedOn: '20 April, 12:00 am'
  // },
  // {
  //   title: 'Python',
  //   description: 'Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.',
  //   Status: 'Development',
  //   TimetoComplete: '30 mins',
  //   Questions: '14',
  //   CreatedOn: '20 April, 12:00 am'
  // },
  // {
  //   title: 'Python',
  //   description: 'Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.',
  //   Status: 'Development',
  //   TimetoComplete: '30 mins',
  //   Questions: '14',
  //   CreatedOn: '20 April, 12:00 am'
  // },

];

export default MyAssessmentData;
