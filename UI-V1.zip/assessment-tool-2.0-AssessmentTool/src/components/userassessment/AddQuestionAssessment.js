import React, { useState } from 'react';
import styles from "@/styles/userassessment.module.css"
import Image from "next/image";
import document from "@/assets/images/StepperNum.svg";
import documentone from "@/assets/images/Stepperone.svg";
import documenttwo from "@/assets/images/Steppertwo.svg";
import documentimg from "@/assets/images/file-upload.svg";
import line from "@/assets/images/Line3.svg";
import linethree from "@/assets/images/LInethreeStraignt.svg";
import lineone from "@/assets/images/Line5.svg";
import checkgreen from "@/assets/images/GreenStepper.svg"
import docone from "@/assets/images/StepperNumone.svg"
import { BsPlusSquare } from "react-icons/bs";
import { TbMathGreater } from "react-icons/tb";
import messageframe from "@/assets/images/Frame.svg";
import AssessmentResultTable from "./AssessmentResultTable";
import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
import AssessmentMobileSideBar from './AssessmentMobileSideBar';
import Link from 'next/link';


const AddQuestionAssessment = (props) => {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };
  return (
    <div className={`${styles.MyAssessmentcontainer} vh-100`} onBlur={handleOutsideClick}>
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => { }}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}
      <div
        className={`${styles.MyAssessmentcontainer}`}>
        <div className="row ">
          <div className="col-sm-12 col-md-12 col-lg-12">
            <div className="containerhead">
              <div className={`d-flex align-items-center ${styles.headercontainer}`}>
                {/* <h4 className={styles.title3}>Create Assessment</h4> */}
                <div className={`${styles.hidejava} d-none d-md-block`}>
                  <h4 className={styles.title}>Java&nbsp;Basics</h4>
                </div>
                <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 2)}>
                  All&nbsp;Assessment
                  <span className={styles.greaterThanSymbol}>
                    <TbMathGreater />
                  </span>
                </h5>
                <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
              </div>
              <span className={`${styles.textcreatebasic} d-lg-none d-md-none mx-auto`}>0%&nbsp;Completed</span>
              {/* <hr className={`${styles.horizontalLine}`} /> */}
            </div>
          </div>
        </div>
        <div className="row mt-2">
          <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage} d-none d-md-block`} >
            <div className="row">
              <div className={`${styles.cointenerstg} col-sm-8 `}>
                <div className="row  row-cols-5">
                  <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>0%&nbsp;Completed</span>
                      <hr className={`${styles.horizontalLine}`} />
                    </div>
                  </div>

                  <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
                    <div className={`col ${styles.customDiv}`} style={{ display: 'flex', alignItems: 'center' }}>
                      {/* <div className={`${styles.verticalLine}`}></div> */}
                      <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 1)} style={{cursor: 'pointer' }}>Questions</span>
                    </div>
                  </div>

                  <div className={`${styles.cointenerstageline} col-lg-12 col-md-12`}>
                  </div>

                  <div className={`${styles.cointenerstageone} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
                    <div className={`col ${styles.customDiv}`} style={{ display: 'flex', alignItems: 'center' }}>
                      {/* <div className={`${styles.verticalLine}`}></div> */}
                      <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 2)} style={{cursor: 'pointer' }}>Result Table</span>
                    </div>
                  </div>

                  <div className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}>
                  </div>
                  <div className={`${styles.cointenerstagetwo} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
                    <div className={`col ${styles.customDiv}`} style={{ display: 'flex', alignItems: 'center' }}>
                      {/* <div className={`${styles.verticalLine}`}></div> */}
                      <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 5)} style={{cursor: 'pointer' }}>Certification</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12"
            style={{ display: "flex", flexDirection: "column", backgroundColor: "white", height: "200%" }} >
            <div className="row mt-2">

              <div className={`${styles.onclickside} d-lg-none d-md-none mx-auto`}>
                <>
                  <button className={`${styles.btnnewDraftarrow} me-2`} onClick={handleNewButtonClick}>
                    <MdOutlineKeyboardDoubleArrowRight className={`${styles.iconArrorw}`} />
                  </button>
                  <span style={{ fontWeight: "bold" }}>Questions</span>
                </>
                <div className={`${styles.Drafttext}`}></div>
              </div>

              <div class="col-12 h-15 " >
                <div className={`${styles.time} d-none d-md-block mx-auto`}>
                  <p style={{ fontSize: "14px", color: "#000", display: "flex", alignItems: "center", justifyContent: "flex-end" }}>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      style={{ marginRight: "8px" }}
                    >
                      <path d="M11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z" fill="#707070" />
                    </svg>
                    Time to complete: <strong style={{ fontWeight: "bold", marginLeft: "8px" }}>30 mins</strong>
                  </p>
                </div>
                <div className={`${styles.Messagebox}`}>
                  <div className={`${styles.messageicon} align-items-center`}>
                    <Image className={`${styles.custommessageframe}`} alt="#" src={messageframe} />
                  </div>
                </div>
                <h4 className={`${styles.addcontent}`} style={{ color: "#000" }}>
                  Click below to start the assessment
                </h4>
              </div>

              <div className={`${styles.time}d-lg-none d-md-none mx-auto d-flex justify-content-center`}>
                <p style={{ fontSize: "14px", color: "#000", display: "flex", alignItems: "center", justifyContent: "flex-end" }}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    style={{ marginRight: "8px" }}
                  >
                    <path d="M11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z" fill="#707070" />
                  </svg>
                  Time to complete: <strong style={{ fontWeight: "bold", marginLeft: "center" }}>30 mins</strong>
                </p>
              </div>

              <div className="row row-col-12">
                <div className="col-12 d-flex justify-content-center">
                  <button className={`${styles.QuestionGroup1}`} onClick={() => props.stepChange(props.step + 1)}>
                    Start Now
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddQuestionAssessment;
