import React, { useEffect, useState } from 'react';
import styles from "@/styles/userassessment.module.css"


const AssessmentMobileSideBar = (props) => {

  return (
    <div className={`${styles.AssessmentDetailSidebar}`}>
      <div className="row">
        <div className={`${styles.AssessmentSidebarTitle}`}>
          <strong>Java&nbsp;Basics</strong>
        </div>
        <div className={`${styles.AssessmentSidebarMenue}`}>
          <div className={`${styles.AssessmentSidebarelement}`}onClick={() => props.stepChange(props.step - 1)}>
            <label>Questions</label>
          </div>
          <div className={`${styles.AssessmentSidebarelement}`}onClick={() => props.stepChange(props.step  + 6)}>
            <label>Result&nbsp;Table</label>
          </div>
          <div className={`${styles.AssessmentSidebarelement}`}onClick={() => props.stepChange(props.step - 1)}>
            <label>Certification</label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssessmentMobileSideBar;



