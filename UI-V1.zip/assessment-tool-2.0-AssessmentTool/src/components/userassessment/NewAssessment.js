import React, { useEffect, useState } from 'react';
import styles from "@/styles/userassessment.module.css";
import Image from "next/image";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { BsPlusSquare } from 'react-icons/bs';
import MyAssessmentData from "./MyAssessmentData";
import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
import { BsEye } from 'react-icons/bs';
import { RiDeleteBin6Line } from 'react-icons/ri';
import { MdOutlineModeEditOutline } from 'react-icons/md';
import AssessmentMobileSideBar from './AssessmentMobileSideBar';
import { useSession } from "next-auth/react";

const NewAssessment = (props) => {
  const { data: session } = useSession();

  const [myData, setMyData] = useState(null);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [selectedView, setSelectedView] = useState('all');
  const [selectedGroup, setSelectedGroup] = useState("All");
  const [assessmentholdId, setAssessmentholdId] = useState(null); 

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };

  const handlePopupToggle = (index) => {
    if (selectedAssessment === index) {
      setSelectedAssessment(null);
    } else {
      setSelectedAssessment(index);
    }
  };

  const Popup = () => {
    return (
      <div className={`${styles.popup} `}>
      </div>
    );
  };

  useEffect(() => {
    function ListApiUser() {
      if (session && session.user && session.user.access_token) {
        var myHeaders = new Headers();
        myHeaders.append("Authorization", "Bearer " + session.user.access_token);
        myHeaders.append("Content-Type", "application/json");

        var graphql = JSON.stringify({
          // query: "query {\r\n    assessments {\r\n        id\r\n        name\r\n        assessmentGroup\r\n        description\r\n        CreatedOn\r\n    }\r\n}\r\n",
          query: "query{\r\n    assessments {\r\n        id,\r\n        name,\r\n        description,\r\n        assessmentGroup,\r\n        createdOn\r\n    }\r\n}",
          variables: {}
        });
        var requestOptions = {
          method: "POST",
          headers: myHeaders,
          body: graphql,
        };

        fetch("http://localhost:9001/assessment-tool/admin", requestOptions)
          .then(response => response.json())
          .then(result => {
            console.log("Response from server:", result);
            setMyData(result.data.assessments);
          })
          .catch(error => console.log('error', error));
      }
    }

    ListApiUser();
  }, [session]);

  // Defined the data for the "Java Basics" card Completed Assessment
  const javaBasicsData = {
    title: "JAVA Basics",
    description: "Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna.",
    category: "Development",
    score: "60/100",
    submittedOn: "20 April, 12:00am",
  };

  // const description = "Lorem ipsum dolor sit amet consectetur. Platea id ultric nullam cursus. Dictum nisi donec urna"
  const TimetoComplete = "30 mins"
  const Questions = "14"
  // const CreatedOn = "20 April, 12:00 am"


  const handleIdPass = (id) => {
    props.setAssessmentholdId(id); // Set the assessmentId in the state
    props.stepChange(props.step + 2, id);
    console.log(id);
  };

  return (
    <div className={`container ${styles.MyAssessmentcontainer} `} onBlur={handleOutsideClick}>
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => { }}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}
      {myData && myData.length === 0 ? (
        <div className={`container ${styles.Newcontainer}`}>

        </div>
      ) : myData && myData.length > 0 ? (
        <div className="row">
          <div className={`col-12 mt-4 ${styles.Newcontainer}`}>
            <div className={`${styles.NewcontainerDraftTitle}`}>
              <div className="row align-items-center">
                <div className="col-md-4 mt-2">
                  <div className={`d-flex flex-row justify-content-start`}>
                    <div>
                      <button
                        className={`${styles.QuestionGroup}`}
                        onClick={() => setSelectedView('all')}
                      >
                        All&nbsp;Assessment
                      </button>
                    </div>
                    <div>
                      <button
                        className={`${styles.QuestionGroup}`}
                        onClick={() => setSelectedView('completed')}
                      >
                        Completed&nbsp;Assessment
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-lg-6 col-md-12 col-sm-12">
                  <div className={`${styles.grouptitile} row justify-content-end`}>
                    <div className="col-md-12" style={{ display: "flex", alignItems: "center" }}>
                      <label htmlFor="group" style={{ fontWeight: "bold", color: "black", marginRight: "10px" }}>
                        Group:
                      </label>
                      <select
                        id="group"
                        className={`${styles.groupOption}`}
                        value={selectedGroup}
                        onChange={(e) => setSelectedGroup(e.target.value)}
                      >
                        <option value="All">All</option>
                        <option value="Design">Design</option>
                        <option value="Development">Development</option>
                        <option value="Finance">Finance</option>
                        <option value="Backend">Backend</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className={`${styles.filecreateDrft}`}>
              <div className={`${styles.boxContainer} row`}>
                {/* Render the "Java Basics" card only when "Completed Assessment" is selected */}
                {selectedView === 'completed' && (
                  <div className={`col-lg-3 col-md-3 col-sm-12 ${styles.box}`}>
                    <div className="d-flex flex-column mt-2">
                      <div
                        className={`${styles.questionscoreone}`}
                        onClick={() => props.stepChange(props.step + 6)}
                        style={{ cursor: 'pointer' }}
                      >
                        <strong>{javaBasicsData.title}</strong>
                        {/* <BiDotsVerticalRounded onClick={() => handlePopupToggle('java-basics')} /> */}
                      </div>

                      <div className={`${styles.Para} mt-2`}>
                        <p>{javaBasicsData.description}</p>
                      </div>
                      <div className={`${styles.Status} d-flex`}>
                        <label>Category:</label>
                        {javaBasicsData.category}
                      </div>
                      <div className={`${styles.Status} d-flex mt-2`}>
                        <label>Score:</label>
                        {javaBasicsData.score}
                      </div>
                      <div className={`${styles.Status} d-flex mt-2`}>
                        <label>Submitted On:</label>
                        {javaBasicsData.submittedOn}
                      </div>
                    </div>

                    {selectedAssessment === 'java-basics' && <Popup />}
                  </div>
                )}

                {/* Render other assessment cards based on the selected view and group */}
                {myData
                  .filter((item, index) => {
                    if (selectedView === 'all') {
                      return true;
                    } else if (selectedView === 'completed') {

                    }
                  })
                  .filter((item) => {
                    if (selectedGroup === "All") {
                      return true;
                    } else {
                      return item.assessmentGroup === selectedGroup;
                    }
                  })
                  .map((item, index) => (
                    <div
                      className={`col-lg-3 col-md-3 col-sm-12 mx-1 ${styles.box} ${index === 0 ? styles.firstBox : index === 1 ? styles.secondBox : styles.thirdBox
                        } ${index !== 0 ? ' ' : ''}`}
                      key={index}
                    >
                      <div className="d-flex flex-column mt-2">
                        <div
                          className={`${styles.questionscoreone}`}
                          onClick={() => handleIdPass(item.id)}
                          style={{ cursor: 'pointer' }}
                        >
                          <strong>{item.name}</strong>
                          {/* <BiDotsVerticalRounded onClick={() => handlePopupToggle(index)} /> */}
                        </div>

                        <div className={`${styles.Para} mt-2`}>
                          <p>{item.description}</p>
                        </div>
                        <div className={`${styles.Status} d-flex`}>
                          <label>Category:</label>
                          {item.assessmentGroup}
                        </div>
                        <div className={`${styles.Status} d-flex mt-2`}>
                          <label>Time to Complete:</label>
                          <span>{item.TimetoComplete || TimetoComplete}</span>
                        </div>
                        <div className={`${styles.Status} d-flex mt-2`}>
                          <label>Questions:</label>
                          <span>{item.Questions || Questions}</span>
                        </div>
                        <div className={`${styles.Status} d-flex mt-2`}>
                          <label>Created On :</label>
                          <span>{item.createdOn }</span>
                        </div>
                      </div>

                      {selectedAssessment !== null && selectedAssessment === index && <Popup />}
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default NewAssessment;



