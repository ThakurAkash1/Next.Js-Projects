import React, { useState } from 'react';
import styles from "@/styles/assessments.module.css";
// import styles from "@/styles/userassessment.module.css"
import Image from "next/image";
import { TbMathGreater } from "react-icons/tb";
import Frame1 from "@/assets/images/Frame1.svg";


const CertificateTable = (props) => {
  const [selectedOption, setSelectedOption] = useState('');

  const handleRadioChange = (event) => {
    setSelectedOption(event.target.value);
  };
  return (
    <div className={`${styles.MyAssessmentcontainer}`}>
      <div className="row">
        <div className="col-sm-12 col-md-12 col-lg-12">
          <div className="containerhead">
            <div className={`d-flex align-items-center ${styles.headercontainer}`}>
              <h4 className={styles.title}>Java Basics</h4>
              <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 4)}>
                My Assessment
                <span className={styles.greaterThanSymbol}>
                  <TbMathGreater />
                </span>
              </h5>
              <h6 className={styles.title2}>Create New</h6>

            </div>
            <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
              <div className={`col ${styles.customDiv}`}>
                <span className={`${styles.textcreatebasic}`}>80% Completed</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row mt-2">
        <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}>
          <div className="row">
            <div className={`${styles.cointenerstg} col-sm-8 `}>
              <div className="row  row-cols-5">
                {/* Stage 1 */}
                <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
                  <div className={`col ${styles.customDiv}`}>
                    <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step - 4)} style={{cursor: 'pointer', color: '#3340B1' }}>Questions</span>
                  </div>
                </div>
                <div className={`${styles.cointenerstageline} col-lg-12 col-md-12`}></div>
                {/* Stage 2 */}
                <div className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex mb-5`}>
                  <div className={`col ${styles.customDiv}`} onClick={() => props.stepChange(props.step + 2)}>
                    <span className={`${styles.textcreatebasic}`} style={{cursor: 'pointer', color: '#3340B1' }}>Result Table</span>
                  </div>
                </div>
                <div className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}></div>
                {/* Stage 3 */}
                <div className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex mb-5`}>
                  <div className={`col ${styles.customDiv}`}>
                    <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 5)} style={{cursor: 'pointer', color: '#3340B1' }}>Certification</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-3 col-lg-2 col-xl-2 d-flex align-items-center justify-content-center" style={{ marginLeft: "20%", marginTop: "20%" }}>
          <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
            <Image alt="Frame1" src={Frame1} style={{ width: "60px", height: "60px" }} />
            <span style={{ marginTop: "4px" }}>Nothing&nbsp;to&nbsp;show</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CertificateTable;
