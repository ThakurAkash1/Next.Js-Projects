
import styles from "@/styles/userassessment.module.css";
import { TbMathGreater } from "react-icons/tb";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import AssessmentMobileSideBar from "./AssessmentMobileSideBar";
import React, { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { green } from "@mui/material/colors";

const AddQuestions = (props) => {
  const [selectedOption, setSelectedOption] = useState("");
  const [myData, setMyData] = useState(null);
  const { data: session } = useSession();
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [selectedView, setSelectedView] = useState("all");
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [isCompleted, setIsCompleted] = useState(false); // New state for completion flag
  const { assessmentholdId } = props;
  console.log("AssessmentId:", assessmentholdId);

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };

  const handleDropdownChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleSubmission = () => {
    setIsCompleted(true);
    // Use your logic for handling submission
  };

  useEffect(() => {
    async function fetchData() {
      if (session && session.user && session.user.access_token) {
        const myHeaders = new Headers();
        myHeaders.append("Authorization", "Bearer " + session.user.access_token);
        myHeaders.append("Content-Type", "application/json");

        var graphql = JSON.stringify({
          query: `
          query GetQuestions($assessmentId: ID!) {
            questions(assessmentId: $assessmentId) {
              id,
              value,
              options {
                id,
                value,
                weightage
              }
            }
          }
        `,
          variables: {
            assessmentId: assessmentholdId,
          },
        });

        const requestOptions = {
          method: 'POST',
          headers: myHeaders,
          body: graphql,
          redirect: 'follow'
        };

        try {
          const response = await fetch("http://localhost:9000/assessment-tool/admin", requestOptions);
          const data = await response.json();
          setQuestions(data.data.questions);
          setSelectedAssessment(data.data.questions[1]); // Assuming the first question here
        } catch (error) {
          console.error('Error fetching data:', error);
        }
      }
    }

    fetchData();
  }, [session]);


  return (
    <div
      className={`${styles.MyAssessmentcontainer} vh-100`}
      onBlur={handleOutsideClick}
    >
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => {}}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}

      <div className={`${styles.MyAssessmentcontainer}`}>
        <div className="row ">
          <div className="col-sm-12 col-md-12 col-lg-12">
            <div className="containerhead">
              <div
                className={`d-flex align-items-center ${styles.headercontainer}`}
              >
                <div className={`${styles.hidejava} d-none d-md-block`}>
                  <h4 className={styles.title}>Java&nbsp;Basics</h4>
                </div>
                <h5
                  className={`${styles.title1} ${styles.myAssessment}`}
                  onClick={() => props.stepChange(props.step - 3)}
                >
                  All&nbsp;Assessment
                  <span className={styles.greaterThanSymbol}>
                    <TbMathGreater />
                  </span>
                </h5>
                <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
              </div>
            </div>
          </div>
        </div>

        <div className="row mt-2">
          <div
            className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}
          >
            <div className="row">
              <div
                className={`${styles.cointenerstg} col-sm-8 d-none d-md-block`}
              >
                <div className="row  row-cols-5">
                  <div
                    className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}
                  >
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        0%&nbsp;Completed
                      </span>
                      <hr className={`${styles.horizontalLine}`} />
                    </div>
                  </div>

                  <div
                    className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}
                  >
                    {/* <div className={`col ${styles.customDiv}`}>
                      <span
                        className={`${styles.textcreatebasic}`}
                        style={{ cursor: "pointer", color: "#3340B1" }}
                      >
                        Questions
                      </span>
                    </div> */}
                    <div className="d-flex align-items-center">
                <div className={`${styles.Detailbox}`}>
                  <div className={`${styles.Detailboxtext}`}>Questions</div>
                </div>
                <div className={`${styles.VerticalLine}`}></div>
              </div>
                  </div>
                  <div
                    className={`${styles.cointenerstageline} col-lg-12 col-md-12`}
                  ></div>
                  <div
                    className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex mb-5`}
                  >
                    <div className={`col ${styles.customDiv}`}>
                      <span
                        className={`${styles.textcreatebasic}`}
                        onClick={() => props.stepChange(props.step + 4)}
                        style={{ cursor: "pointer" }}
                      >
                        Result Table
                      </span>
                    </div>
                  </div>
                  <div
                    className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}
                  ></div>
                  <div
                    className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex mb-5`}
                  >
                    <div className={`col ${styles.customDiv}`}>
                      <span
                        className={`${styles.textcreatebasic}`}
                        onClick={() => props.stepChange(props.step + 4)}
                        style={{ cursor: "pointer" }}
                      >
                        Certification
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="col-xl-9 col-lg-9 col-md-9 col-sm-12"
            style={{
              display: "flex",
              flexDirection: "column",
              backgroundColor: "white",
            }}
          >
            <div className="col-12">
              <div className="d-lg-none d-md-none mx-auto  d-flex align-items-center">
                <>
                  <button
                    className={`${styles.btnnewDraftarrow} me-2`}
                    onClick={handleNewButtonClick}
                  >
                    <MdOutlineKeyboardDoubleArrowRight
                      className={`${styles.iconArrorw}`}
                    />
                  </button>
                </>
                <div
                  className={`${styles.Drafttext}`}
                  style={{ fontWeight: "bold" }}
                >
                  Questions
                </div>
              </div>
              <div className={`${styles.MessageboxAdd}`}>
                <div
                  className={`${styles.AddQuestionTitle} ml-4 mt-2 `}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <div className="d-none d-md-block">
                    <h5>Total&nbsp;Questions : 10 | Questions Attempted : 0</h5>
                  </div>
                  <div className={`${styles.TQuestion}`}>
                    <div className="d-lg-none d-md-none mx-auto">
                      Total Questions&nbsp;:&nbsp;10
                    </div>
                  </div>

                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                    }}
                  >
                    {/* Green flag for successful completion */}
                    {isCompleted && (
                      <div
                        className="alert alert-success mt-0 custom-alert"
                        role="alert"
                        style={{
                          color: "#fff",
                          backgroundColor: "#60AC6C",
                          width: "max-content",
                          height: "fit-content",
                        }}
                      >
                        <span style={{ marginRight: "8px" }}>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                          >
                            <path
                              d="M12 1.5C14.7848 1.5 17.4555 2.60625 19.4246 4.57538C21.3938 6.54451 22.5 9.21523 22.5 12C22.5 14.7848 21.3938 17.4555 19.4246 19.4246C17.4555 21.3938 14.7848 22.5 12 22.5C9.21523 22.5 6.54451 21.3938 4.57538 19.4246C2.60625 17.4555 1.5 14.7848 1.5 12C1.5 9.21523 2.60625 6.54451 4.57538 4.57538C6.54451 2.60625 9.21523 1.5 12 1.5ZM10.692 14.0715L8.3595 11.7375C8.27588 11.6539 8.17661 11.5876 8.06736 11.5423C7.9581 11.497 7.84101 11.4737 7.72275 11.4737C7.60449 11.4737 7.4874 11.497 7.37814 11.5423C7.26889 11.5876 7.16962 11.6539 7.086 11.7375C6.91712 11.9064 6.82225 12.1354 6.82225 12.3743C6.82225 12.6131 6.91712 12.8421 7.086 13.011L10.056 15.981C10.1394 16.065 10.2386 16.1317 10.3479 16.1773C10.4571 16.2228 10.5744 16.2462 10.6927 16.2462C10.8111 16.2462 10.9284 16.2228 11.0376 16.1773C11.1469 16.1317 11.2461 16.065 11.3295 15.981L17.4795 9.8295C17.5642 9.74623 17.6316 9.647 17.6778 9.53755C17.724 9.42809 17.7481 9.31057 17.7487 9.19177C17.7492 9.07297 17.7262 8.95523 17.6811 8.84535C17.6359 8.73547 17.5694 8.63562 17.4854 8.55156C17.4015 8.46751 17.3017 8.4009 17.1919 8.3556C17.0821 8.31029 16.9644 8.28718 16.8455 8.28759C16.7267 8.288 16.6092 8.31193 16.4997 8.358C16.3902 8.40407 16.2909 8.47136 16.2075 8.556L10.692 14.0715Z"
                              fill="white"
                            />
                          </svg>
                        </span>{" "}
                        Test submitted successfully
                      </div>
                    )}

                    <div className={`${styles.QuetionsMD}`}>
                      <p
                        style={{
                          fontSize: "14px",
                          color: "#000",
                          display: "flex",
                          alignItems: "center",
                        }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          style={{ marginRight: "8px" }}
                        >
                          <path
                            d="M11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z"
                            fill="#707070"
                          />
                        </svg>
                        Time&nbsp;to&nbsp;complete:&nbsp;
                        <strong
                          style={{ fontWeight: "bold", marginLeft: "8px" }}
                        >
                          30&nbsp;mins
                        </strong>
                      </p>
                    </div>
                    <div className="d-lg-none d-md-none mx-auto">
                      <p style={{ fontSize: "14px", color: "#000" }}>
                        Questions Attempted : 0
                      </p>
                    </div>
                  </div>
                </div>
                <div className={`row mt-2 ${styles.scrollableRow}`}>
                  {questions.map((question, index) => (
                    <div className="card mt-3" key={question.id}>
                      <div className="card-body">
                        <div>
                          <div className="row mt-2">
                            <div className="col-12" key={question.id}>
                              <div className={`${styles.questionh6}`}>
                                <h6>Question {index + 1}</h6>
                                <label
                                  htmlFor="assessmentName"
                                  className={`${styles.boldLabel}`}
                                >
                                  {question.value} {question.text}
                                  {selectedAssessment &&
                                    selectedAssessment.text}{" "}
                                  {/* Display dynamic question value */}
                                </label>
                              </div>
                            </div>
                          </div>
                          <div className="row mt-2">
                            {question.options.map((option) => (
                              <div
                                className="col-12 col-md-2 col-lg-2 col-xl-2"
                                key={option.id}
                              >
                                <div
                                  className={`form-check form-check-inline ${styles.StateChoice}`}
                                >
                                  <input
                                    className={`form-check-input form-check-lg ${styles.customCheckbox}`}
                                    type="checkbox"
                                    id={`checkbox_${question.id}_${option.id}`}
                                    style={{
                                      cursor: "pointer",
                                      border: "3px solid #8F8F8F",
                                    }}
                                  />
                                  <label
                                    className={`form-check-label ${styles.labelCustom}`}
                                    htmlFor={`checkbox_${question.id}_${option.id}`}
                                  >
                                    {option.value}
                                  </label>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div className="row" style={{ backgroundColor: "white" }}>
                    <div className="col-lg-4 col-md-4 col-sm-6 col-6 ">
                      <div className={`${styles.nextBtnn}`}>
                        <button
                          className={`${styles.nextbuttonn}`}
                          onClick={handleSubmission}
                        >
                          Submit
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* <div className="row" style={{ backgroundColor: "white" }}>
                <div className="col-lg-4 col-md-4 col-sm-6 col-6 ">
                  <div className={`${styles.nextBtnn}`}>
                    <button
                      className={`${styles.nextbuttonn}`} onClick={handleSubmission}>
                      Submit
                    </button>
                  </div>
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddQuestions;





// import styles from "@/styles/userassessment.module.css";
// import Image from "next/image";
// import { TbMathGreater } from "react-icons/tb";
// import irishimg from "@/assets/images/irish.svg";
// import BlackCoffee from "@/assets/images/BlackCoffee.svg";
// import Cappuccino from "@/assets/images/Cappuccino.svg";
// import Latte from "@/assets/images/Latte.svg";
// import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
// import AssessmentMobileSideBar from './AssessmentMobileSideBar';
// import React, { useState, useEffect } from "react";
// import { useSession } from "next-auth/react";

// const AddQuestions = (props) => {
//   const [selectedOption, setSelectedOption] = useState("");
//   const [myData, setMyData] = useState(null);
//   const { data: session } = useSession();
//   const [selectedAssessment, setSelectedAssessment] = useState(null);
//   const [selectedView, setSelectedView] = useState('all');
//   const [isSidebarOpen, setSidebarOpen] = useState(false);

//   const [questions, setQuestions] = useState([]);

//   const handleNewButtonClick = () => {
//     setSidebarOpen(!isSidebarOpen);
//   };

//   const handleOutsideClick = () => {
//     setSidebarOpen(false);
//   };

//   const handleDropdownChange = (event) => {
//     setSelectedOption(event.target.value);
//   };

//   const handleSubmission = () => {
//     window.alert('Test is successfully completed!');
//   };

//   useEffect(() => {
//     async function fetchData() {
//       if (session && session.user && session.user.access_token) {
//         const myHeaders = new Headers();
//         myHeaders.append("Authorization", "Bearer " + session.user.access_token);
//         myHeaders.append("Content-Type", "application/json");

//         const graphql = JSON.stringify({
//           query: "query{\r\nquestions(assessmentId:1) {\r\n    id,\r\n    options{\r\n   id,\r\n    value,\r\n    weightage\r\n}\r\n}\r\n}",
//           // query: "mutation {\r\n    newQuestion(assessmentId:\"1\",value:\"who are you\",type:\"How the day\",group:\"Backend\"){\r\n        id\r\n        assessmentId\r\n        value \r\n        type\r\n        group\r\n        options{\r\n            id\r\n            questionId\r\n            value\r\n            weightage\r\n        }\r\n    }\r\n}\r\n",
//           variables: {}
//         });

//         const requestOptions = {
//           method: 'POST',
//           headers: myHeaders,
//           body: graphql,
//           redirect: 'follow'
//         };

//         try {
//           const response = await fetch("http://localhost:9000/assessment-tool/admin", requestOptions);
//           const data = await response.json();
//           setQuestions(data.data.questions);
//         } catch (error) {
//           console.error('Error fetching data:', error);
//         }
//       }
//     }

//     fetchData();
//   }, [session]);

//   return (
//     <div className={`${styles.MyAssessmentcontainer} vh-100`} onBlur={handleOutsideClick}>
//       {isSidebarOpen && <div className={styles.overlay} />}
//       {isSidebarOpen && (
//         <AssessmentMobileSideBar
//           setMobileSidebarSelect={() => { }}
//           isOpen={isSidebarOpen}
//           setSidebarOpen={setSidebarOpen}
//         />
//       )}

//       <div className={`${styles.MyAssessmentcontainer}`}>

//         <div className="row ">
//           <div className="col-sm-12 col-md-12 col-lg-12">
//             <div className="containerhead">
//               <div className={`d-flex align-items-center ${styles.headercontainer}`}>
//                 <div className={`${styles.hidejava} d-none d-md-block`}>
//                   <h4 className={styles.title}>Java&nbsp;Basics</h4>
//                 </div>
//                 <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 3)}>
//                   All&nbsp;Assessment
//                   <span className={styles.greaterThanSymbol}>
//                     <TbMathGreater />
//                   </span>
//                 </h5>
//                 <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className="row mt-2">
//           <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}>
//             <div className="row">
//               <div className={`${styles.cointenerstg} col-sm-8 d-none d-md-block`}>
//                 <div className="row  row-cols-5">
//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`}>0%&nbsp;Completed</span>
//                       <hr className={`${styles.horizontalLine}`} />
//                     </div>
//                   </div>

//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`} >
//                       <span className={`${styles.textcreatebasic}`} style={{ cursor: 'pointer', color: '#3340B1' }}>Questions</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstageline} col-lg-12 col-md-12`}></div>
//                   <div className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Result Table</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}></div>
//                   <div className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Certification</span>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12" style={{ display: "flex", flexDirection: "column", backgroundColor: "white" }}>

//             <div className="col-12">

//               <div className="d-lg-none d-md-none mx-auto  d-flex align-items-center">
//                 <>
//                   <button className={`${styles.btnnewDraftarrow} me-2`} onClick={handleNewButtonClick}>
//                     <MdOutlineKeyboardDoubleArrowRight className={`${styles.iconArrorw}`} />
//                   </button>
//                 </>
//                 <div className={`${styles.Drafttext}`} style={{ fontWeight: "bold" }}>
//                   Questions
//                 </div>
//               </div>
//               <div className={`${styles.MessageboxAdd}`}>

//                 <div className={`${styles.AddQuestionTitle} ml-4 mt-2 `}
//                   style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//                   <div className="d-none d-md-block">
//                     <h5>Total&nbsp;Questions : 10 | Questions Attempted : 0</h5>
//                   </div>
//                   <div className={`${styles.TQuestion}`}>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       Total Questions&nbsp;:&nbsp;10
//                     </div>
//                   </div>

//                   <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
//                     <div className={`${styles.QuetionsMD}`}>
//                       <p style={{ fontSize: "14px", color: "#000", display: "flex", alignItems: "center" }}>
//                         <svg
//                           xmlns="http://www.w3.org/2000/svg"
//                           width="24"
//                           height="24"
//                           viewBox="0 0 24 24"
//                           fill="none"
//                           style={{ marginRight: "8px" }}
//                         >
//                           <path d="M11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z" fill="#707070" />
//                         </svg>
//                         Time&nbsp;to&nbsp;complete:&nbsp;<strong style={{ fontWeight: "bold", marginLeft: "8px" }}>30&nbsp;mins</strong>
//                       </p>
//                     </div>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       <p style={{ fontSize: "14px", color: "#000" }}>
//                         Questions Attempted : 0
//                       </p>
//                     </div>
//                    </div>
//                 </div>
//                 <div className={`row mt-2 ${styles.scrollableRow}`}>
//                   {questions.map((question, index) => (
//                     <div className="card mt-3" key={question.id}>
//                       <div className="card-body">
//                         <div>
//                           <div className="row mt-2">
//                             <div className="col-12" key={question.id}>
//                               <div className={`${styles.questionh6}`}>
//                                 <h6>Question {index + 1}</h6>
//                                 <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                                   {question.value} {question.text}
//                                   Which color is Good ?
//                                 </label>
//                               </div>
//                             </div>
//                           </div>
//                           <div className="row mt-2">
//                             {question.options.map((option) => (
//                               <div className="col-12 col-md-2 col-lg-2 col-xl-2" key={option.id}>
//                                 <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                                   <input
//                                     className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                     type="checkbox"
//                                     id={`checkbox_${question.id}_${option.id}`}
//                                     style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                                   />
//                                   {/* <label className={`form-check-label ${styles.labelCustom}`} htmlFor={`checkbox_${question.id}_${option.id}`}>
//                                     Option {option.id}: {option.value}
//                                     (Weightage: {option.weightage})
//                                   </label> */}

//                                   <label className={`form-check-label ${styles.labelCustom}`} htmlFor={`checkbox_${question.id}_${option.id}`}>
//                                     {option.value}
//                                     {/* (Weightage: {option.weightage}) */}
//                                   </label>
//                                 </div>
//                               </div>
//                             ))}
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   ))}
//                 </div>

//               </div>

//               <div className="row" style={{ backgroundColor: "white" }}>
//                 <div className="col-lg-4 col-md-4 col-sm-6 col-6 ">
//                   <div className={`${styles.nextBtnn}`}>
//                     <button
//                       className={`${styles.nextbuttonn}`} onClick={() => props.stepChange(props.step + 3)}>
//                       Submit
//                     </button>
//                   </div>
//                 </div>
//               </div>

//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AddQuestions;

// import styles from "@/styles/userassessment.module.css";
// import { TbMathGreater } from "react-icons/tb";
// import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
// import AssessmentMobileSideBar from './AssessmentMobileSideBar';
// import React, { useState, useEffect } from "react";
// import { useSession } from "next-auth/react";

// const AddQuestions = (props) => {
//   const [selectedOption, setSelectedOption] = useState("");
//   const [myData, setMyData] = useState(null);
//   const { data: session } = useSession();
//   const [selectedAssessment, setSelectedAssessment] = useState(null);
//   const [selectedView, setSelectedView] = useState('all');
//   const [isSidebarOpen, setSidebarOpen] = useState(false);

//   const [questions, setQuestions] = useState([]);

//   const handleNewButtonClick = () => {
//     setSidebarOpen(!isSidebarOpen);
//   };

//   const handleOutsideClick = () => {
//     setSidebarOpen(false);
//   };

//   const handleDropdownChange = (event) => {
//     setSelectedOption(event.target.value);
//   };

//   const handleSubmission = () => {
//     window.alert('Test is successfully completed!');
//   };

//   useEffect(() => {
//     async function fetchData() {
//       if (session && session.user && session.user.access_token) {
//         const myHeaders = new Headers();
//         myHeaders.append("Authorization", "Bearer " + session.user.access_token);
//         myHeaders.append("Content-Type", "application/json");

//         const graphql = JSON.stringify({
//           query: "query{\r\nquestions(assessmentId:1) {\r\n    id,\r\n    value,\r\n    options{\r\n   id,\r\n    value,\r\n    weightage\r\n}\r\n}\r\n}",
//           variables: {}
//         });

//         const requestOptions = {
//           method: 'POST',
//           headers: myHeaders,
//           body: graphql,
//           redirect: 'follow'
//         };

//         try {
//           const response = await fetch("http://localhost:9000/assessment-tool/admin", requestOptions);
//           const data = await response.json();
//           setQuestions(data.data.questions);
//           setSelectedAssessment(data.data.questions[1]); // Assuming the first question here
//         } catch (error) {
//           console.error('Error fetching data:', error);
//         }
//       }
//     }

//     fetchData();
//   }, [session]);

//   return (
//     <div className={`${styles.MyAssessmentcontainer} vh-100`} onBlur={handleOutsideClick}>
//       {isSidebarOpen && <div className={styles.overlay} />}
//       {isSidebarOpen && (
//         <AssessmentMobileSideBar
//           setMobileSidebarSelect={() => { }}
//           isOpen={isSidebarOpen}
//           setSidebarOpen={setSidebarOpen}
//         />
//       )}

//       <div className={`${styles.MyAssessmentcontainer}`}>

//         <div className="row ">
//           <div className="col-sm-12 col-md-12 col-lg-12">
//             <div className="containerhead">
//               <div className={`d-flex align-items-center ${styles.headercontainer}`}>
//                 <div className={`${styles.hidejava} d-none d-md-block`}>
//                   <h4 className={styles.title}>Java&nbsp;Basics</h4>
//                 </div>
//                 <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 3)}>
//                   All&nbsp;Assessment
//                   <span className={styles.greaterThanSymbol}>
//                     <TbMathGreater />
//                   </span>
//                 </h5>
//                 <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className="row mt-2">
//           <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}>
//             <div className="row">
//               <div className={`${styles.cointenerstg} col-sm-8 d-none d-md-block`}>
//                 <div className="row  row-cols-5">
//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`}>0%&nbsp;Completed</span>
//                       <hr className={`${styles.horizontalLine}`} />
//                     </div>
//                   </div>

//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`} >
//                       <span className={`${styles.textcreatebasic}`} style={{ cursor: 'pointer', color: '#3340B1' }}>Questions</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstageline} col-lg-12 col-md-12`}></div>
//                   <div className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Result Table</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}></div>
//                   <div className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Certification</span>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12" style={{ display: "flex", flexDirection: "column", backgroundColor: "white" }}>

//             <div className="col-12">

//               <div className="d-lg-none d-md-none mx-auto  d-flex align-items-center">
//                 <>
//                   <button className={`${styles.btnnewDraftarrow} me-2`} onClick={handleNewButtonClick}>
//                     <MdOutlineKeyboardDoubleArrowRight className={`${styles.iconArrorw}`} />
//                   </button>
//                 </>
//                 <div className={`${styles.Drafttext}`} style={{ fontWeight: "bold" }}>
//                   Questions
//                 </div>
//               </div>
//               <div className={`${styles.MessageboxAdd}`}>

//                 <div className={`${styles.AddQuestionTitle} ml-4 mt-2 `}
//                   style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//                   <div className="d-none d-md-block">
//                     <h5>Total&nbsp;Questions : 10 | Questions Attempted : 0</h5>
//                   </div>
//                   <div className={`${styles.TQuestion}`}>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       Total Questions&nbsp;:&nbsp;10
//                     </div>
//                   </div>

//                   <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
//                     <div className={`${styles.QuetionsMD}`}>
//                       <p style={{ fontSize: "14px", color: "#000", display: "flex", alignItems: "center" }}>
//                         <svg
//                           xmlns="http://www.w3.org/2000/svg"
//                           width="24"
//                           height="24"
//                           viewBox="0 0 24 24"
//                           fill="none"
//                           style={{ marginRight: "8px" }}
//                         >
//                           <path d="M11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z" fill="#707070" />
//                         </svg>
//                         Time&nbsp;to&nbsp;complete:&nbsp;<strong style={{ fontWeight: "bold", marginLeft: "8px" }}>30&nbsp;mins</strong>
//                       </p>
//                     </div>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       <p style={{ fontSize: "14px", color: "#000" }}>
//                         Questions Attempted : 0
//                       </p>
//                     </div>
//                    </div>
//                 </div>
//                 <div className={`row mt-2 ${styles.scrollableRow}`}>
//                   {questions.map((question, index) => (
//                     <div className="card mt-3" key={question.id}>
//                       <div className="card-body">
//                         <div>
//                           <div className="row mt-2">
//                             <div className="col-12" key={question.id}>
//                               <div className={`${styles.questionh6}`}>
//                                 <h6>Question {index + 1}</h6>
//                                 <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                                   {question.value} {question.text}
//                                   {selectedAssessment && selectedAssessment.text} {/* Display dynamic question value */}
//                                 </label>
//                               </div>
//                             </div>
//                           </div>
//                           <div className="row mt-2">
//                             {question.options.map((option) => (
//                               <div className="col-12 col-md-2 col-lg-2 col-xl-2" key={option.id}>
//                                 <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                                   <input
//                                     className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                     type="checkbox"
//                                     id={`checkbox_${question.id}_${option.id}`}
//                                     style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                                   />
//                                   <label className={`form-check-label ${styles.labelCustom}`} htmlFor={`checkbox_${question.id}_${option.id}`}>
//                                     {option.value}
//                                   </label>
//                                 </div>
//                               </div>
//                             ))}
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//               </div>

//               <div className="row" style={{ backgroundColor: "white" }}>
//                 <div className="col-lg-4 col-md-4 col-sm-6 col-6 ">
//                   <div className={`${styles.nextBtnn}`}>
//                     <button
//                       className={`${styles.nextbuttonn}`} onClick={() => props.stepChange(props.step + 3)}>
//                       Submit
//                     </button>
//                   </div>
//                 </div>
//               </div>

//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AddQuestions;

// ==================================================

// import styles from "@/styles/userassessment.module.css";
// import Image from "next/image";
// import { TbMathGreater } from "react-icons/tb";
// import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
// import AssessmentMobileSideBar from './AssessmentMobileSideBar';
// import React, { useState, useEffect } from "react";
// import { useSession } from "next-auth/react";

// const AddQuestions = (props) => {
//   const [questions, setQuestions] = useState([]);
//   const { data: session } = useSession();
//   const [isSidebarOpen, setSidebarOpen] = useState(false);

//   const handleNewButtonClick = () => {
//     setSidebarOpen(!isSidebarOpen);
//   };

//   const handleOutsideClick = () => {
//     setSidebarOpen(false);
//   };

//   useEffect(() => {
//     async function fetchData() {
//       if (session && session.user && session.user.access_token) {
//         const myHeaders = new Headers();
//         myHeaders.append("Authorization", "Bearer " + session.user.access_token);
//         myHeaders.append("Content-Type", "application/json");

//         const graphql = JSON.stringify({
//           query: "query{\r\nquestions(assessmentId:1) {\r\n    id,\r\n    text,\r\n    options{\r\n        id,\r\n        value,\r\n        weightage\r\n    }\r\n}\r\n}",
//           variables: {}
//         });

//         const requestOptions = {
//           method: 'POST',
//           headers: myHeaders,
//           body: graphql,
//           redirect: 'follow'
//         };

//         try {
//           const response = await fetch("http://localhost:9000/assessment-tool/admin", requestOptions);
//           const data = await response.json();
//           if (data.data && data.data.questions) {
//             setQuestions(data.data.questions);
//           }
//         } catch (error) {
//           console.error('Error fetching data:', error);
//         }
//       }
//     }

//     fetchData();
//   }, [session]);

//   return (
//     <div className={`${styles.MyAssessmentcontainer} vh-100`} onBlur={handleOutsideClick}>
//       {isSidebarOpen && <div className={styles.overlay} />}
//       {isSidebarOpen && (
//         <AssessmentMobileSideBar
//           setMobileSidebarSelect={() => { }}
//           isOpen={isSidebarOpen}
//           setSidebarOpen={setSidebarOpen}
//         />
//       )}

//       <div className={`${styles.MyAssessmentcontainer}`}>

//         <div className="row ">
//           <div className="col-sm-12 col-md-12 col-lg-12">
//             <div className="containerhead">
//               <div className={`d-flex align-items-center ${styles.headercontainer}`}>
//                 <div className={`${styles.hidejava} d-none d-md-block`}>
//                   <h4 className={styles.title}>Java&nbsp;Basics</h4>
//                 </div>
//                 <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 3)}>
//                   All&nbsp;Assessment
//                   <span className={styles.greaterThanSymbol}>
//                     <TbMathGreater />
//                   </span>
//                 </h5>
//                 <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className="row mt-2">
//           <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}>
//             <div className="row">
//               <div className={`${styles.cointenerstg} col-sm-8 d-none d-md-block`}>
//                 <div className="row  row-cols-5">
//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`}>0%&nbsp;Completed</span>
//                       <hr className={`${styles.horizontalLine}`} />
//                     </div>
//                   </div>

//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`} >
//                       <span className={`${styles.textcreatebasic}`} style={{ cursor: 'pointer', color: '#3340B1' }}>Questions</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstageline} col-lg-12 col-md-12`}></div>
//                   <div className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Result Table</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}></div>
//                   <div className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Certification</span>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12" style={{ display: "flex", flexDirection: "column", backgroundColor: "white" }}>

//             <div className="col-12">

//               <div className="d-lg-none d-md-none mx-auto  d-flex align-items-center">
//                 <>
//                   <button className={`${styles.btnnewDraftarrow} me-2`} onClick={handleNewButtonClick}>
//                     <MdOutlineKeyboardDoubleArrowRight className={`${styles.iconArrorw}`} />
//                   </button>
//                 </>
//                 <div className={`${styles.Drafttext}`} style={{ fontWeight: "bold" }}>
//                   Questions
//                 </div>
//               </div>
//               <div className={`${styles.MessageboxAdd}`}>

//                 <div className={`${styles.AddQuestionTitle} ml-4 mt-2 `}
//                   style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//                   <div className="d-none d-md-block">
//                     <h5>Total&nbsp;Questions: {questions.length} | Questions Attempted: 0</h5>
//                   </div>
//                   <div className={`${styles.TQuestion}`}>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       Total Questions:&nbsp;{questions.length}
//                     </div>
//                   </div>

//                   <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
//                     <div className={`${styles.QuetionsMD}`}>
//                       <p style={{ fontSize: "14px", color: "#000", display: "flex", alignItems: "center" }}>
//                         <svg
//                           xmlns="http://www.w3.org/2000/svg"
//                           width="24"
//                           height="24"
//                           viewBox="0 0 24 24"
//                           fill="none"
//                           style={{ marginRight: "8px" }}
//                         >
//                           <path d="M11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z" fill="#707070" />
//                         </svg>
//                         Time to complete: <strong style={{ fontWeight: "bold", marginLeft: "8px" }}>30 mins</strong>
//                       </p>
//                     </div>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       <p style={{ fontSize: "14px", color: "#000" }}>
//                         Questions Attempted: 0
//                       </p>
//                     </div>
//                   </div>
//                 </div>
//                 <div className={`row mt-2 ${styles.scrollableRow}`}>
//                   {questions.map((question, index) => (
//                     <div className="card mt-3" key={question.id}>
//                       <div className="card-body">
//                         <div>
//                           <div className="row mt-2">
//                             <div className="col-12" key={question.id}>
//                               <div className={`${styles.questionh6}`}>
//                                 <h6>Question {index + 1}</h6>
//                                 <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                                   {question.value} {question.text}
//                                 </label>
//                               </div>
//                             </div>
//                           </div>
//                           <div className="row mt-2">
//                             {question.options.map((option) => (
//                               <div className="col-12 col-md-2 col-lg-2 col-xl-2" key={option.id}>
//                                 <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                                   <input
//                                     className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                     type="checkbox"
//                                     id={`checkbox_${question.id}_${option.id}`}
//                                     style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                                   />
//                                   <label className={`form-check-label ${styles.labelCustom}`} htmlFor={`checkbox_${question.id}_${option.id}`}>
//                                     {option.value}
//                                   </label>
//                                 </div>
//                               </div>
//                             ))}
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//               </div>
//               <div className="row" style={{ backgroundColor: "white" }}>
//                 <div className="col-lg-4 col-md-4 col-sm-6 col-6 ">
//                   <div className={`${styles.nextBtnn}`}>
//                     <button
//                       className={`${styles.nextbuttonn}`} onClick={() => props.stepChange(props.step + 3)}>
//                       Submit
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AddQuestions;

// import styles from "@/styles/userassessment.module.css";
// import Image from "next/image";
// import { TbMathGreater } from "react-icons/tb";
// import irishimg from "@/assets/images/irish.svg";
// import BlackCoffee from "@/assets/images/BlackCoffee.svg";
// import Cappuccino from "@/assets/images/Cappuccino.svg";
// import Latte from "@/assets/images/Latte.svg";
// import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
// import AssessmentMobileSideBar from './AssessmentMobileSideBar';
// import React, { useState, useEffect, useRef } from "react";
// import { useSession } from "next-auth/react";

// const AddQuestions = (props) => {
//   const [selectedOption, setSelectedOption] = useState("");
//   const [myData, setMyData] = useState(null);
//   const { data: session } = useSession();
//   const [selectedAssessment, setSelectedAssessment] = useState(null);
//   const [selectedView, setSelectedView] = useState('all');
//   const [isSidebarOpen, setSidebarOpen] = useState(false);
//   const [questions, setQuestions] = useState([]);
//   const containerRef = useRef(null);

//   const handleNewButtonClick = () => {
//     setSidebarOpen(!isSidebarOpen);
//   };

//   useEffect(() => {
//     async function fetchData() {
//       if (session && session.user && session.user.access_token) {
//         const myHeaders = new Headers();
//         myHeaders.append("Authorization", "Bearer " + session.user.access_token);
//         myHeaders.append("Content-Type", "application/json");

//         const graphql = JSON.stringify({
//           query: "query{\r\nquestions(assessmentId:1) {\r\n    id,\r\n    options{\r\n   id,\r\n    value,\r\n    weightage\r\n}\r\n}\r\n}",
//           variables: {}
//         });

//         const requestOptions = {
//           method: 'POST',
//           headers: myHeaders,
//           body: graphql,
//           redirect: 'follow'
//         };

//         try {
//           const response = await fetch("http://localhost:9000/assessment-tool/admin", requestOptions);
//           const data = await response.json();
//           setQuestions(data.data.questions);
//         } catch (error) {
//           console.error('Error fetching data:', error);
//         }
//       }
//     }

//     fetchData();
//   }, [session]);

//   useEffect(() => {
//     // Add a click event listener to the document to handle clicks outside the container.
//     const handleClickOutside = (event) => {
//       if (containerRef.current && !containerRef.current.contains(event.target)) {
//         setSidebarOpen(false);
//       }
//     };

//     document.addEventListener("click", handleClickOutside);

//     return () => {
//       // Clean up the event listener when the component unmounts.
//       document.removeEventListener("click", handleClickOutside);
//     };
//   }, []);

//   return (
//     <div className={`${styles.MyAssessmentcontainer}`}>
//       {isSidebarOpen && <div className={styles.overlay} />}
//       {isSidebarOpen && (
//         <AssessmentMobileSideBar
//           setMobileSidebarSelect={() => {}}
//           isOpen={isSidebarOpen}
//           setSidebarOpen={setSidebarOpen}
//         />
//       )}
//       <div ref={containerRef}>
//         <div className="row ">
//           <div className="col-sm-12 col-md-12 col-lg-12">
//             <div className="containerhead">
//               <div className={`d-flex align-items-center ${styles.headercontainer}`}>
//                 <div className={`${styles.hidejava} d-none d-md-block`}>
//                   <h4 className={styles.title}>Java&nbsp;Basics</h4>
//                 </div>
//                 <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 3)}>
//                   All&nbsp;Assessment
//                   <span className={styles.greaterThanSymbol}>
//                     <TbMathGreater />
//                   </span>
//                 </h5>
//                 <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className={`row mt-2 ${styles.scrollableRow}`}>
//           {questions.map((question, index) => (
//             <div className="card mt-3" key={question.id}>
//               <div className="card-body">
//                 <div>
//                   <div className="row mt-2">
//                     <div className="col-12" key={question.id}>
//                       <div className={`${styles.questionh6}`}>
//                         <h6>Question {index + 1}</h6>
//                         <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                           {question.value} {question.text} {props.questionText}
//                         </label>
//                       </div>
//                     </div>
//                   </div>
//                   <div className="row mt-2">
//                     {question.options.map((option) => (
//                       <div className="col-12 col-md-2 col-lg-2 col-xl-2" key={option.id}>
//                         <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                           <input
//                             className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                             type="checkbox"
//                             id={`checkbox_${question.id}_${option.id}`}
//                             style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                           />

//                           <label className={`form-check-label ${styles.labelCustom}`} htmlFor={`checkbox_${question.id}_${option.id}`}>
//                             {option.value}
//                           </label>
//                         </div>
//                       </div>
//                     ))}
//                   </div>
//                 </div>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     </div>

//   );
// };

// export default AddQuestions;

// import styles from "@/styles/userassessment.module.css";
// import Image from "next/image";
// import { TbMathGreater } from "react-icons/tb";
// // import React, { useState } from "react";
// import irishimg from "@/assets/images/irish.svg";
// import BlackCoffee from "@/assets/images/BlackCoffee.svg";
// import Cappuccino from "@/assets/images/Cappuccino.svg";
// import Latte from "@/assets/images/Latte.svg";
// import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
// import AssessmentMobileSideBar from './AssessmentMobileSideBar';

// import React, { useState, useEffect } from "react";
// import { useSession } from "next-auth/react";

// const AddQuestions = (props) => {
//   const [selectedOption, setSelectedOption] = useState("");

//   const [myData, setMyData] = useState(null);
//   const { data: session } = useSession();
//   const [selectedAssessment, setSelectedAssessment] = useState(null);
//   // const [isSidebarOpen, setSidebarOpen] = useState(false);
//   const [selectedView, setSelectedView] = useState('all');

//   const [isSidebarOpen, setSidebarOpen] = useState(false);
//   const handleNewButtonClick = () => {
//     setSidebarOpen(!isSidebarOpen);
//   };

//   const handleOutsideClick = () => {
//     setSidebarOpen(false);
//   };
//   const handleDropdownChange = (event) => {

//     setSelectedOption(event.target.value);
//   };

//   const handleSubmission = () => {
//     window.alert('Test is successfully completed!');
//   };

//   useEffect(() => {
//     function ListApiUser() {
//       if (session && session.user && session.user.access_token) {
//         var myHeaders = new Headers();
//         myHeaders.append("Authorization", "Bearer " + session.user.access_token);
//         myHeaders.append("Content-Type", "application/json");

//         var graphql = JSON.stringify({
//           query: "query{\r\n        questions(assessmentId:1) {\r\n            id,\r\n            options{\r\n                id,\r\n                value,\r\n                weightage\r\n            }\r\n        }\r\n    }",
//           variables: {}
//         })

//         var requestOptions = {
//           method: 'POST',
//           headers: myHeaders,
//           body: graphql,
//           redirect: 'follow'
//         };

//         fetch("http://localhost:9000/assessment-tool/admin", requestOptions)
//           .then(response => response.text())
//           .then(result => console.log(result))
//           .catch(error => console.log('error', error));
//       }
//     }

//     ListApiUser();
//   }, [session]);

//   return (

//     <div className={`${styles.MyAssessmentcontainer} vh-100`} onBlur={handleOutsideClick}>
//       {isSidebarOpen && <div className={styles.overlay} />}
//       {isSidebarOpen && (
//         <AssessmentMobileSideBar
//           setMobileSidebarSelect={() => { }}
//           isOpen={isSidebarOpen}
//           setSidebarOpen={setSidebarOpen}
//         />
//       )}

//       <div className={`${styles.MyAssessmentcontainer}`}>

//         <div className="row ">
//           <div className="col-sm-12 col-md-12 col-lg-12">
//             <div className="containerhead">
//               <div className={`d-flex align-items-center ${styles.headercontainer}`}>
//                 <div className={`${styles.hidejava} d-none d-md-block`}>
//                   <h4 className={styles.title}>Java&nbsp;Basics</h4>
//                 </div>
//                 <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 3)}>
//                   All&nbsp;Assessment
//                   <span className={styles.greaterThanSymbol}>
//                     <TbMathGreater />
//                   </span>
//                 </h5>
//                 <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className="row mt-2">
//           <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}>
//             <div className="row">
//               <div className={`${styles.cointenerstg} col-sm-8 d-none d-md-block`}>
//                 <div className="row  row-cols-5">
//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`}>0%&nbsp;Completed</span>
//                       <hr className={`${styles.horizontalLine}`} />
//                     </div>
//                   </div>

//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`} >
//                       <span className={`${styles.textcreatebasic}`} style={{ cursor: 'pointer', color: '#3340B1' }}>Questions</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstageline} col-lg-12 col-md-12`}></div>
//                   <div className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Result Table</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}></div>
//                   <div className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Certification</span>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12" style={{ display: "flex", flexDirection: "column", backgroundColor: "white" }}>

//             <div className="col-12">

//               <div className="d-lg-none d-md-none mx-auto  d-flex align-items-center">
//                 <>
//                   <button className={`${styles.btnnewDraftarrow} me-2`} onClick={handleNewButtonClick}>
//                     <MdOutlineKeyboardDoubleArrowRight className={`${styles.iconArrorw}`} />
//                   </button>
//                 </>
//                 <div className={`${styles.Drafttext}`} style={{ fontWeight: "bold" }}>
//                   Questions
//                 </div>
//               </div>
//               <div className={`${styles.MessageboxAdd}`}>

//                 <div className={`${styles.AddQuestionTitle} ml-4 mt-2 `}
//                   style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//                   <div className="d-none d-md-block">
//                     <h5>Total&nbsp;Questions : 10 | Questions Attempted : 0</h5>
//                   </div>
//                   <div className={`${styles.TQuestion}`}>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       Total Questions&nbsp;:&nbsp;10
//                     </div>
//                   </div>

//                   <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
//                     <div className={`${styles.QuetionsMD}`}>
//                       <p style={{ fontSize: "14px", color: "#000", display: "flex", alignItems: "center" }}>
//                         <svg
//                           xmlns="http://www.w3.org/2000/svg"
//                           width="24"
//                           height="24"
//                           viewBox="0 0 24 24"
//                           fill="none"
//                           style={{ marginRight: "8px" }}
//                         >
//                           <path d="M11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z" fill="#707070" />
//                         </svg>
//                         Time&nbsp;to&nbsp;complete:&nbsp;<strong style={{ fontWeight: "bold", marginLeft: "8px" }}>30&nbsp;mins</strong>
//                       </p>
//                     </div>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       <p style={{ fontSize: "14px", color: "#000" }}>
//                         Questions Attempted : 0
//                       </p>
//                     </div>
//                   </div>
//                 </div>

//                 <div className={`row mt-2 ${styles.scrollableRow}`} >

//                   <div className="card mt-3" >
//                     <div className="card-body" >
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <div className={`${styles.questionh6}`}>
//                               <h6>Question 1</h6>
//                               <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                                 Lorem ipsum dolor sit amet ?
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12 col-md-2 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 Option&nbsp;1
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-2 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 Option&nbsp;2
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-2 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_3"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
//                                 Option&nbsp;3
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-2 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_4"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                                 Option&nbsp;4
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-4 col-lg-4 col-xl-4">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_5"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox5">
//                                 Option&nbsp;5
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="card mt-3">
//                     <div className="card-body ">
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <h6>Question 2</h6>
//                             <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                               Lorem ipsum dolor sit amet ?
//                             </label>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12 col-md-3 col-lg-3 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox2_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 True
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox2_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 False
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="card mt-3">
//                     <div className="card-body">
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <h6>Question 3</h6>
//                             <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                               Lorem ipsum dolor sit amet ?
//                             </label>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <div className={`form-check ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox3_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <div className={`form-check ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox3_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <div className={`form-check ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox3_3"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
//                                 Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <div className={`form-check ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox3_4"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                                 Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="card mt-3">
//                     <div className="card-body">
//                       <div>
//                         <div className="row mt-2">
//                           <h6 className={`${styles.headingQuestion}`}>Question 4</h6>
//                           <div className={`${styles.fomgrpquestion}`}>
//                             <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                               Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
//                             </label>
//                             <input
//                               type="text"
//                               className={`${styles.formcontrolquestion}`}
//                               placeholder="Answer here"
//                               style={{ height: "140px", }}
//                             />
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="card mt-3">
//                     <div className="card-body">
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <h6>Question 5</h6>
//                             <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                               Lorem ipsum dolor sit amet ?
//                             </label>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12 col-md-3 col-lg-3 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox5_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 Option&nbsp;1
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox5_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 Option&nbsp;2
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox5_3"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
//                                 Option&nbsp;3
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-5 col-xl-6">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox5_4"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                                 Option&nbsp;4
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                   <div className="card mt-3">
//                     <div className="card-body">
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <h6>Question 6</h6>
//                             <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                               Lorem ipsum dolor sit amet ?
//                             </label>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12 col-md-3 col-lg-3 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox6_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 Option&nbsp;1
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox6_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 Option&nbsp;2
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox6_3"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
//                                 Option&nbsp;3
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-5 col-xl-6">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox6_4"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                                 Option&nbsp;4
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="card mt-3">
//                     <div className="card-body">
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <h6>Question 7</h6>
//                             <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                               Lorem ipsum dolor sit amet ?
//                             </label>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12 col-md-3 col-lg-3 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox7_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 True
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox7_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 False
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="card mt-3">
//                     <div className="card-body">
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <h6>Question 8</h6>
//                             <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                               Lorem ipsum dolor sit amet ?
//                             </label>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12 col-md-3 col-lg-3 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox8_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 Option&nbsp;1
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox8_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 Option&nbsp;2
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox8_3"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
//                                 Option&nbsp;3
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-3 col-lg-5 col-xl-6">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox8_4"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                                 Option&nbsp;4
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="card mt-3">
//                     <div className="card-body">
//                       <div>
//                         <div className="row mt-2">
//                           <h6 className={`${styles.headingQuestion}`}>Question 9</h6>
//                           <div className={`${styles.fomgrpquestion}`}>
//                             <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                               Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
//                             </label>
//                             <input
//                               type="text"
//                               className={`${styles.formcontrolquestion}`}
//                               placeholder="Answer here"
//                               style={{ height: "140px", }}
//                             />
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="card mt-3">
//                     <div className="card-body">
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <h6>Question 10</h6>
//                             <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                               How do you like your coffee?
//                             </label>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-6 col-md-3 col-lg-3 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox10_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
//                                   <Image alt="Irish Coffee" src={irishimg} style={{ width: "60px", height: "60px" }} />
//                                   <span style={{ marginTop: "4px" }}>Irish Coffee</span>
//                                 </div>
//                               </label>
//                             </div>
//                           </div>

//                           <div className="col-6 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox10_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
//                                   <Image alt="Cappuccino" src={Cappuccino} style={{ width: "60px", height: "60px" }} />
//                                   <span style={{ marginTop: "4px" }}>Cappuccino</span>
//                                 </div>
//                               </label>
//                             </div>
//                           </div>

//                           <div className="col-6 col-md-3 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox10_3"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
//                                 <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
//                                   <Image alt="BlackCoffee" src={BlackCoffee} style={{ width: "60px", height: "60px" }} />
//                                   <span style={{ marginTop: "4px" }}>Black&nbsp;Coffee</span>
//                                 </div>
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-6 col-md-3 col-lg-5 col-xl-6">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox10_4"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                                 <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
//                                   <Image alt="Latte" src={Latte} style={{ width: "60px", height: "60px" }} />
//                                   <span style={{ marginTop: "4px" }}>Latte</span>
//                                 </div>
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>

//             </div>

//             <div className="row" style={{ backgroundColor: "white" }}>
//               <div className="col-lg-4 col-md-4 col-sm-6 col-6 ">
//                 <div className={`${styles.nextBtnn}`}>
//                   <button
//                     className={`${styles.nextbuttonn}`} onClick={() => props.stepChange(props.step + 3)}>
//                     Submit
//                   </button>
//                 </div>
//               </div>
//             </div>

//             {/* <div className="row" style={{ backgroundColor: "white" }}>
//               <div className="col-lg-4 col-md-4 col-sm-6 col-6">
//                 <div className={`${styles.nextBtnn}`}>
//                   <button
//                     className={`${styles.nextbuttonn}`}
//                     // onClick={() => props.stepChange(props.step + 3)}
//                     onClick={handleSubmission}
//                   >
//                     Submit
//                   </button>
//                 </div>
//               </div>
//             </div> */}

//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AddQuestions;

// import styles from "@/styles/userassessment.module.css";
// import Image from "next/image";
// import { TbMathGreater } from "react-icons/tb";
// // import React, { useState } from "react";
// import irishimg from "@/assets/images/irish.svg";
// import BlackCoffee from "@/assets/images/BlackCoffee.svg";
// import Cappuccino from "@/assets/images/Cappuccino.svg";
// import Latte from "@/assets/images/Latte.svg";
// import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
// import AssessmentMobileSideBar from './AssessmentMobileSideBar';

// import React, { useState, useEffect } from "react";
// import { useSession } from "next-auth/react";

// const AddQuestions = (props) => {
//   const [selectedOption, setSelectedOption] = useState("");

//   const [myData, setMyData] = useState(null);
//   const { data: session } = useSession();
//   const [selectedAssessment, setSelectedAssessment] = useState(null);
//   // const [isSidebarOpen, setSidebarOpen] = useState(false);
//   const [selectedView, setSelectedView] = useState('all');

//   const [isSidebarOpen, setSidebarOpen] = useState(false);
//   const handleNewButtonClick = () => {
//     setSidebarOpen(!isSidebarOpen);
//   };

//   const handleOutsideClick = () => {
//     setSidebarOpen(false);
//   };
//   const handleDropdownChange = (event) => {

//     setSelectedOption(event.target.value);
//   };

//   const handleSubmission = () => {
//     window.alert('Test is successfully completed!');
//   };

//   useEffect(() => {
//     function ListApiUser() {
//       if (session && session.user && session.user.access_token) {
//         var myHeaders = new Headers();
//         myHeaders.append("Authorization", "Bearer " + session.user.access_token);
//         myHeaders.append("Content-Type", "application/json");

//         var graphql = JSON.stringify({
//           query: "query{\r\n        questions(assessmentId:1) {\r\n            id,\r\n            options{\r\n                id,\r\n                value,\r\n                weightage\r\n            }\r\n        }\r\n    }",
//           variables: {}
//         })

//         var requestOptions = {
//           method: 'POST',
//           headers: myHeaders,
//           body: graphql,
//           redirect: 'follow'
//         };

//         fetch("http://localhost:9000/assessment-tool/admin", requestOptions)
//           .then(response => response.text())
//           .then(result => console.log(result))
//           .catch(error => console.log('error', error));
//       }
//     }

//     ListApiUser();
//   }, [session]);

//   return (

//     <div className={`${styles.MyAssessmentcontainer} vh-100`} onBlur={handleOutsideClick}>
//       {isSidebarOpen && <div className={styles.overlay} />}
//       {isSidebarOpen && (
//         <AssessmentMobileSideBar
//           setMobileSidebarSelect={() => { }}
//           isOpen={isSidebarOpen}
//           setSidebarOpen={setSidebarOpen}
//         />
//       )}

//       <div className={`${styles.MyAssessmentcontainer}`}>

//         <div className="row ">
//           <div className="col-sm-12 col-md-12 col-lg-12">
//             <div className="containerhead">
//               <div className={`d-flex align-items-center ${styles.headercontainer}`}>
//                 <div className={`${styles.hidejava} d-none d-md-block`}>
//                   <h4 className={styles.title}>Java&nbsp;Basics</h4>
//                 </div>
//                 <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 3)}>
//                   All&nbsp;Assessment
//                   <span className={styles.greaterThanSymbol}>
//                     <TbMathGreater />
//                   </span>
//                 </h5>
//                 <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className="row mt-2">
//           <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}>
//             <div className="row">
//               <div className={`${styles.cointenerstg} col-sm-8 d-none d-md-block`}>
//                 <div className="row  row-cols-5">
//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`}>0%&nbsp;Completed</span>
//                       <hr className={`${styles.horizontalLine}`} />
//                     </div>
//                   </div>

//                   <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`} >
//                       <span className={`${styles.textcreatebasic}`} style={{ cursor: 'pointer', color: '#3340B1' }}>Questions</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstageline} col-lg-12 col-md-12`}></div>
//                   <div className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Result Table</span>
//                     </div>
//                   </div>
//                   <div className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}></div>
//                   <div className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex mb-5`}>
//                     <div className={`col ${styles.customDiv}`}>
//                       <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step + 4)} style={{ cursor: 'pointer', color: '#3340B1' }}>Certification</span>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12" style={{ display: "flex", flexDirection: "column", backgroundColor: "white" }}>

//             <div className="col-12">

//               <div className="d-lg-none d-md-none mx-auto  d-flex align-items-center">
//                 <>
//                   <button className={`${styles.btnnewDraftarrow} me-2`} onClick={handleNewButtonClick}>
//                     <MdOutlineKeyboardDoubleArrowRight className={`${styles.iconArrorw}`} />
//                   </button>
//                 </>
//                 <div className={`${styles.Drafttext}`} style={{ fontWeight: "bold" }}>
//                   Questions
//                 </div>
//               </div>
//               <div className={`${styles.MessageboxAdd}`}>

//                 <div className={`${styles.AddQuestionTitle} ml-4 mt-2 `}
//                   style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//                   <div className="d-none d-md-block">
//                     <h5>Total&nbsp;Questions : 10 | Questions Attempted : 0</h5>
//                   </div>
//                   <div className={`${styles.TQuestion}`}>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       Total Questions&nbsp;:&nbsp;10
//                     </div>
//                   </div>

//                   <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
//                     <div className={`${styles.QuetionsMD}`}>
//                       <p style={{ fontSize: "14px", color: "#000", display: "flex", alignItems: "center" }}>
//                         <svg
//                           xmlns="http://www.w3.org/2000/svg"
//                           width="24"
//                           height="24"
//                           viewBox="0 0 24 24"
//                           fill="none"
//                           style={{ marginRight: "8px" }}
//                         >
//                           <path d="M11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20ZM12.5 7H11V13L16.25 16.15L17 14.92L12.5 12.25V7Z" fill="#707070" />
//                         </svg>
//                         Time&nbsp;to&nbsp;complete:&nbsp;<strong style={{ fontWeight: "bold", marginLeft: "8px" }}>30&nbsp;mins</strong>
//                       </p>
//                     </div>
//                     <div className="d-lg-none d-md-none mx-auto">
//                       <p style={{ fontSize: "14px", color: "#000" }}>
//                         Questions Attempted : 0
//                       </p>
//                     </div>
//                   </div>
//                 </div>

//                 <div className={`row mt-2 ${styles.scrollableRow}`} >

//                   <div className="card mt-3" >
//                     <div className="card-body" >
//                       <div>
//                         <div className="row mt-2">
//                           <div className="col-12">
//                             <div className={`${styles.questionh6}`}>
//                               <h6>Question 1</h6>
//                               <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
//                                 Lorem ipsum dolor sit amet ?
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="row mt-2">
//                           <div className="col-12 col-md-2 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_1"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
//                                 Option&nbsp;1
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-2 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_2"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
//                                 Option&nbsp;2
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-2 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_3"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
//                                 Option&nbsp;3
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-2 col-lg-2 col-xl-2">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_4"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
//                                 Option&nbsp;4
//                               </label>
//                             </div>
//                           </div>
//                           <div className="col-12 col-md-4 col-lg-4 col-xl-4">
//                             <div className={`form-check form-check-inline ${styles.StateChoice}`}>
//                               <input
//                                 className={`form-check-input form-check-lg ${styles.customCheckbox}`}
//                                 type="checkbox"
//                                 id="checkbox1_5"
//                                 style={{ cursor: 'pointer', border: '3px solid #8F8F8F' }}
//                               />
//                               <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox5">
//                                 Option&nbsp;5
//                               </label>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>

//                 </div>

//               </div>

//             </div>

//             <div className="row" style={{ backgroundColor: "white" }}>
//               <div className="col-lg-4 col-md-4 col-sm-6 col-6 ">
//                 <div className={`${styles.nextBtnn}`}>
//                   <button
//                     className={`${styles.nextbuttonn}`} onClick={() => props.stepChange(props.step + 3)}>
//                     Submit
//                   </button>
//                 </div>
//               </div>
//             </div>

//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AddQuestions;
