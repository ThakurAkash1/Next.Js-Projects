import React, { useEffect, useState } from 'react';
import styles from "@/styles/userassessment.module.css";
import Image from "next/image";
import document from "@/assets/images/FrameFile.svg";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { BsPlusSquare } from 'react-icons/bs';
import MyAssessmentData from "./MyAssessmentData";
import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
import { BsEye } from 'react-icons/bs';
import { RiDeleteBin6Line } from 'react-icons/ri';
import { MdOutlineModeEditOutline } from 'react-icons/md';
import AssessmentMobileSideBar from './AssessmentMobileSideBar';

const NewAssessment = (props) => {
  const [myData, setMyData] = useState(null);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [selectedView, setSelectedView] = useState('all');

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };

  useEffect(() => {
    setMyData(MyAssessmentData);
  }, []);

  const handlePopupToggle = (index) => {
    if (selectedAssessment === index) {
      setSelectedAssessment(null);
    } else {
      setSelectedAssessment(index);
    }
  };

  const Popup = () => {
    return (
      <div className={`${styles.popup} `}>
        
      </div>
    );
  };

  return (
    <div className={`container ${styles.MyAssessmentcontainer} vh-100`} onBlur={handleOutsideClick}>
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => { }}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}
      {myData && myData.length === 0 ? (
        <div className={`container ${styles.Newcontainer}`}>
          <div className="row mt-4">
            <div className="col-md-6">
              <div className={`${styles.header} d-none d-md-block`}>
                <div className={`${styles.text}`}>My&nbsp;Assessments</div>
              </div>
            </div>
            <div className="col-md-6 text-end">
              <button
                id="newbutton"
                className={`${styles.btnnew} d-none d-md-block`}
                onClick={() => props.stepChange(props.step + 1)}
              >
                <BsPlusSquare className={`${styles.iconplus} ${styles.gapfirst}`} /> New
              </button>
            </div>
          </div>
          <div className={`${styles.filecreate}`}>
            <span className={`${styles.filecreate}`}>
              <Image className={`${styles.customImageassessment}`} alt="#" src={document} />
            </span>
          </div>
          <div className="col-12 text-center">
            <button
              id="newbuttonone"
              className={`${styles.smButton} d-lg-none d-md-none  mx-auto`}
              onClick={() => props.stepChange(props.step + 1)}
            >
              <BsPlusSquare className={`${styles.btnass} ${styles.gapone}`} /> New
            </button>
          </div>
        </div>
      ) : myData && myData.length > 0 ? (
        <div className="row">
          <div className={`col-12 mt-4 ${styles.Newcontainer}`}>
            <div className={`${styles.NewcontainerDraftTitle}`}>
              <div className="row align-items-center">
                <div className="col-md-4 mt-2">
                  <div className="d-flex flex-row justify-content-start">
                    <div>
                      <button
                        className={`${styles.QuestionGroup}`}
                        onClick={() => setSelectedView('all')}
                      >
                        All&nbsp;Assessment
                      </button>
                    </div>
                    <div>
                      <button
                        className={`${styles.QuestionGroup}`}
                        onClick={() => setSelectedView('completed')}
                      >
                        Completed&nbsp;Assessment
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-lg-6 col-md-12 col-sm-12">
                  <div className={`${styles.grouptitile} row justify-content-end`}>
                    <div className="col-md-12" style={{ display: "flex", alignItems: "center" }}>
                      <label htmlFor="group" style={{ fontWeight: "bold", color: "black", marginRight: "10px" }}>
                        Group:
                      </label>
                      <select id="group" className={`${styles.groupOption}`}>
                        <option value="multiple-choice">All</option>
                        <option value="multiple-choice">Design</option>
                        <option value="multiple-choice">Development</option>
                        <option value="multiple-choice">Finance</option>
                        <option value="multiple-choice">Backend</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div className={`${styles.filecreateDrft}`}>
              <div className={`${styles.boxContainer} row`}>
                {myData
                  .filter((item, index) => {
                    if (selectedView === 'all') {
                      return true;
                    } else if (selectedView === 'completed') {
                      return index === 0;
                    }
                  })
                  .map((item, index) => (
                    <div
                      className={`col-lg-3 col-md-3 col-sm-12  ${styles.box} ${index === 0 ? styles.firstBox : index === 1 ? styles.secondBox : styles.thirdBox
                        } ${index !== 0 ? ' ' : ''}`}
                      key={index}
                    >
                      <div className="d-flex flex-column mt-2">
                        <div
                          className={`${styles.questionscoreone}`}
                          onClick={() => props.stepChange(props.step + 2)}
                          style={{ cursor: 'pointer' }}
                        >
                          <strong>{item.title}</strong>
                          <BiDotsVerticalRounded onClick={() => handlePopupToggle(index)} />
                        </div>

                        <div className={`${styles.Para} mt-2`}>
                          <p>{item.description}</p>
                        </div>
                        <div className={`${styles.Status} d-flex`}>
                          <label>Category:</label>
                          {item.Status}
                        </div>
                        <div className={`${styles.Status} d-flex mt-2`}>
                          <label>Time to Complete:</label>
                          <span>{item.TimetoComplete}</span>
                        </div>
                        <div className={`${styles.Status} d-flex mt-2`}>
                          <label>Questions:</label>
                          <span>{item.Questions}</span>
                        </div>
                        <div className={`${styles.Status} d-flex mt-2`}>
                          <label>Created On :</label>
                          <span>{item.CreatedOn}</span>
                        </div>
                      </div>

                      {selectedAssessment !== null && selectedAssessment === index && <Popup />}
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default NewAssessment;
