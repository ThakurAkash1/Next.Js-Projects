import styles from "@/styles/userassessment.module.css";
import Image from "next/image";
import { BsPlusSquare } from "react-icons/bs";
import { BsFillPenFill, BsPaperclip, BsImageFill } from "react-icons/bs";
import { MdAddToDrive, MdLockClock, MdAttachment } from "react-icons/md";
import { CgSmileMouthOpen } from "react-icons/cg";
import { RiFontColor, RiDeleteBin6Line } from "react-icons/ri";
import { TbMathGreater } from "react-icons/tb";
import React, { useState } from "react";
import irishimg from "@/assets/images/irish.svg";
import BlackCoffee from "@/assets/images/BlackCoffee.svg";
import Cappuccino from "@/assets/images/Cappuccino.svg";
import Latte from "@/assets/images/Latte.svg";
import { MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';
import AssessmentMobileSideBar from './AssessmentMobileSideBar';




const AddQuestions = (props) => {
  const [selectedOption, setSelectedOption] = useState("");

  const handleDropdownChange = (event) => {

    setSelectedOption(event.target.value);
  };
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };

  const handleSubmission = () => {
    window.alert('Test is successfully completed!');
  };


  return (

    <div className={`${styles.MyAssessmentcontainer} vh-100`} onBlur={handleOutsideClick}>
      {isSidebarOpen && <div className={styles.overlay} />}
      {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => { }}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )}
      <div className={`${styles.MyAssessmentcontainer}`}>
        <div className="row ">
          <div className="col-sm-12 col-md-12 col-lg-12">
            <div className="containerhead">
              <div className={`d-flex align-items-center ${styles.headercontainer}`}>
                {/* <h4 className={styles.title3}>Create Assessment</h4> */}
                <div className={`${styles.hidejava} d-none d-md-block`}>
                  <h4 className={styles.title}>Java&nbsp;Basics</h4>
                </div>
                <h5 className={`${styles.title1} ${styles.myAssessment}`} onClick={() => props.stepChange(props.step - 6)}>
                  All&nbsp;Assessment
                  <span className={styles.greaterThanSymbol}>
                    <TbMathGreater />
                  </span>
                </h5>
                <h6 className={styles.title2}>Assessment&nbsp;Details</h6>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-2">
          <div className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}>
            <div className="row">
              <div className={`${styles.cointenerstg} col-sm-8 d-none d-md-block `}>
                <div className="row  row-cols-5">
                  <div className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex mb-5`}>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>80% Completed</span>
                      <hr className={`${styles.horizontalLine}`} />
                    </div>
                  </div>

                  <div className={`${styles.cointenerstageline} col-lg-12 col-md-12`}></div>
                  {/* Stage 1 */}
                  <div className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex mb-5`}>

                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step - 2)} style={{cursor: 'pointer', color: '#3340B1' }}>
                        Result Table
                      </span>
                    </div>
                  </div>
                  <div className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}></div>
                  {/* Stage 2 */}
                  <div className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex mb-5`}>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`} onClick={() => props.stepChange(props.step - 2)} style={{cursor: 'pointer' }}>
                        Certification
                      </span>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>


          <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12" style={{ display: "flex", flexDirection: "column", backgroundColor: "white" }}>
            <div className="col-12">
              <div className="d-lg-none d-md-none mx-auto  d-flex align-items-center">
                <>
                  <button className={`${styles.btnnewDraftarrow} me-2`} onClick={handleNewButtonClick}>
                    <MdOutlineKeyboardDoubleArrowRight className={`${styles.iconArrorw}`} />
                  </button>
                </>
                {/* <div className={`${styles.Drafttext}`}>Result&nbsp;Table</div> */}
                <div className={`${styles.Drafttext}`} style={{ fontWeight: "bold" }}>
                  Result Table
                </div>
              </div>
              <div className={`${styles.MessageboxAdd}`}>
                <div className={`row mt-2 ${styles.scrollableRowOne}`}>
                  <div className="card mt-3" >
                    <div className="card-body" >
                      <div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <div className={`${styles.questionh6}`}>
                              <h6>Question 1</h6>
                              <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
                                Lorem ipsum dolor sit amet ?
                              </label>
                            </div>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12 col-md-2 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1" style={{ color: "green" }}>
                              Option&nbsp;1
                            </label>
                          </div>
                          <div className="col-12 col-md-2 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
                              Option&nbsp;2
                            </label>
                          </div>
                          <div className="col-12 col-md-2 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
                              Option&nbsp;3
                            </label>
                          </div>
                          <div className="col-12 col-md-2 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
                              Option&nbsp;4
                            </label>
                          </div>
                          <div className="col-12 col-md-4 col-lg-4 col-xl-4">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox5">
                              Option&nbsp;5
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card mt-3">
                    <div className="card-body ">
                      <div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <h6>Question 2</h6>
                            <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
                              Lorem ipsum dolor sit amet ?
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12 col-md-3 col-lg-3 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1" style={{ color: "green" }}>
                              True
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2" style={{ color: "red" }}>
                              False
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card mt-3">
                    <div className="card-body">
                      <div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <h6>Question 3</h6>
                            <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
                              Lorem ipsum dolor sit amet ?
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
                              Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2" style={{ color: "green" }}>
                              Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
                              Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
                              Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card mt-3">
                    <div className="card-body">
                      <div>
                        <div className="row mt-2">
                          <h6 className={`${styles.headingQuestion}`}>Question 4</h6>
                          <div className={`${styles.fomgrpquestion}`}>
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
                              Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                            </label>
                            <textarea
                              className={`${styles.formcontrolquestion}`}
                              placeholder="Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                            Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                            Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc"
                              style={{ height: "140px" }}
                            >
                            </textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>


                  <div className="card mt-3">
                    <div className="card-body">
                      <div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <h6>Question 5</h6>
                            <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
                              Lorem ipsum dolor sit amet ?
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12 col-md-3 col-lg-3 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1" style={{ color: "green" }}>
                              Option 1
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
                              Option 2
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
                              Option 3
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-5 col-xl-6">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
                              Option 4
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="card mt-3">
                    <div className="card-body">
                      <div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <h6>Question 6</h6>
                            <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
                              Lorem ipsum dolor sit amet ?
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12 col-md-3 col-lg-3 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1" style={{ color: "red" }}>
                              Option 1
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2" style={{ color: "green" }}>
                              Option 2
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
                              Option 3
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-5 col-xl-6">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
                              Option 4
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card mt-3">
                    <div className="card-body">
                      <div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <h6>Question 7</h6>
                            <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
                              Lorem ipsum dolor sit amet ?
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12 col-md-3 col-lg-3 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1" style={{ color: "green" }}>
                              True
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2" style={{ color: "red" }}>
                              False
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card mt-3">
                    <div className="card-body">
                      <div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <h6>Question 8</h6>
                            <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
                              Lorem ipsum dolor sit amet ?
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-12 col-md-3 col-lg-3 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1" style={{ color: "green" }}>
                              Option 1
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
                              Option 2
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
                              Option 3
                            </label>
                          </div>
                          <div className="col-12 col-md-3 col-lg-5 col-xl-6">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
                              Option 4
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card mt-3">
                    <div className="card-body">
                      <div>
                        <div className="row mt-2">
                          <h6 className={`${styles.headingQuestion}`}>Question 9</h6>
                          <div className={`${styles.fomgrpquestion}`}>
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
                              Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                            </label>
                            <textarea
                              className={`${styles.formcontrolquestion}`}
                              placeholder="Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                             Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc
                             Lorem ipsum dolor sit amet consectetur. A dolor lectus aliquam imperdiet faucibus. Ullamcorper facilisi faucibus nunc"
                              style={{ height: "140px" }}>
                            </textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>


                  <div className="card mt-3">
                    <div className="card-body">
                      <div>
                        <div className="row mt-2">
                          <div className="col-12">
                            <h6>Question 10</h6>
                            <label htmlFor="assessmentName" className={`${styles.boldLabel}`}>
                              How do you like your coffee?
                            </label>
                          </div>
                        </div>
                        <div className="row mt-2">
                          <div className="col-6 col-md-3 col-lg-3 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox1">
                              <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                                <Image alt="Irish Coffee" src={irishimg} style={{ width: "60px", height: "60px", border: "2px solid green" }} />
                                <span style={{ marginTop: "4px", color: "green" }}>Irish Coffee</span>
                              </div>
                            </label>
                          </div>

                          <div className="col-6 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox2">
                              <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                                <Image alt="Cappuccino" src={Cappuccino} style={{ width: "60px", height: "60px" }} />
                                <span style={{ marginTop: "4px" }}>Cappuccino</span>
                              </div>
                            </label>
                          </div>

                          <div className="col-6 col-md-3 col-lg-2 col-xl-2">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox3">
                              <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                                <Image alt="BlackCoffee" src={BlackCoffee} style={{ width: "60px", height: "60px" }} />
                                <span style={{ marginTop: "4px" }}>Black&nbsp;Coffee</span>
                              </div>
                            </label>
                          </div>
                          <div className="col-6 col-md-3 col-lg-5 col-xl-6">
                            <label className={`form-check-label ${styles.labelCustom}`} htmlFor="checkbox4">
                              <div className="mb-4" style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                                <Image alt="Latte" src={Latte} style={{ width: "60px", height: "60px" }} />
                                <span style={{ marginTop: "4px" }}>Latte</span>
                              </div>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>



              <div className="col-12">
                <div className={`${styles.fomgrpquestionone} col-12`}>
                  {selectedOption === "multiple-choice" && (
                    <div id="multiple-choice" className={styles.contentdropdown}>
                      <div className="col ml-4 mt-3">
                        <h6>
                          Select the correct answer and mention score for each
                          correct answer
                        </h6>
                      </div>
                      <div className="row">
                        {/* Options */}
                        <div className="col-lg-6 col-md-6 col-sm-12 mt-2">
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="checkbox"
                              className={`${styles.CheckOne}`}
                            />
                          </div>
                          <div className={`question-box ${styles["question-box"]}`}>
                            <textarea className={`${styles.Textelement}`} />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                          <div className={`col-sm ${styles.Scoreone}`}>
                            <label htmlFor="group">Score:</label>
                            <input
                              type="text"
                              id="groupscore"
                              className={`${styles.formsropeone}`}
                            />
                          </div>
                        </div>
                        {/* Options */}
                        <div className="col-lg-6 col-md-6 col-sm-12 mt-2">
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="checkbox"
                              className={`${styles.Checktwo}`}
                            />
                          </div>
                          <div className={`question-box ${styles["question-box"]}`}>
                            <textarea className={`${styles.Textelement}`} />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                          <div className={`col-sm ${styles.Scoretwo}`}>
                            <label htmlFor="group">Score:</label>
                            <input
                              type="text"
                              id="groupscoreone"
                              className={`${styles.formsropetwo}`}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        {/* Options */}
                        <div className="col-lg-6 col-md-6 col-sm-12 mt-2">
                          <div className={`${styles.DeleteOne}`}>
                            <RiDeleteBin6Line />
                          </div>
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="checkbox"
                              className={`${styles.Checkthree}`}
                            />
                          </div>
                          <div className={`question-boxone ${styles["question-boxone"]}`}>
                            <textarea className={`${styles.Textelement}`} />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                          <div className={`col-sm ${styles.Scorethree}`}>
                            <label htmlFor="group">Score:</label>
                            <input
                              type="text"
                              id="groupscore"
                              className={`${styles.formsropethree}`}
                            />
                          </div>
                        </div>
                        {/* Options */}
                        <div className="col-lg-6 col-md-6 col-sm-12 mt-2">
                          <div className={`${styles.DeleteTwo}`}>
                            <RiDeleteBin6Line />
                          </div>
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="checkbox"
                              className={`${styles.Checkfour}`}
                            />
                          </div>
                          <div className={`question-boxone ${styles["question-boxone"]}`}>
                            <textarea className={`${styles.Textelement}`} />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                          <div className={`col-sm ${styles.Scorefour}`}>
                            <label htmlFor="group">Score:</label>
                            <input
                              type="text"
                              id="groupscoreone"
                              className={`${styles.formsropefour}`}
                            />
                          </div>
                        </div>
                      </div>
                      <div col-12>
                        <div className={`${styles.Addoption} mt-4 mb-2`}>
                          <button className={`${styles.Addoptionbutton}`}>
                            <BsPlusSquare className={`${styles.iconoption}`} />
                            Add Option
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                  {selectedOption === "true-false" && (
                    <div className={`${styles.textualDropdown}`}>
                      <h6>Select the correct option</h6>
                      <div className="row ">
                        {/* Options */}
                        <div className="col-lg-6 col-md-6 col-sm-12">
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="radio"
                              className={`${styles.CheckOne}`}
                            />
                          </div>
                          <div className={`question-boxarea ${styles["question-boxarea"]}`}>
                            <textarea className={`${styles.Textelementarea}`} />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                        </div>
                        {/* Options */}
                        <div className="col-lg-6 col-md-6 col-sm-12">
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="radio"
                              className={`${styles.Checktwo}`}
                            />
                          </div>
                          <div className={`question-boxareaone ${styles["question-boxareaone"]}`}>
                            <textarea className={`${styles.Textelementarea}`} />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  {/* {selectedOption === "textual" && (
                    <div id="textual" className={styles.contentdropdown}>
                      <div className="col ml-4 mt-3">
                        <h6>Enter Answer below</h6>
                      </div>
                      <div className="row row-col-12">
                        <div className="col-12">
                          <div className={`${styles.Textualbox}`}>
                            <textarea
                              placeholder="Add possible answer to the question"
                              id="textBox"
                              className="form-control"
                              style={{ height: "130px" }}
                            ></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  )} */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddQuestions;
