import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import assessItImg from "@/assets/images/assessIt_icon_full.svg";
import dashboardImgBlack from "@/assets/images/dashboard-black.svg";
import dashboardImgWhite from "@/assets/images/dashboard-white.svg";
import assessmentImgWhite from "@/assets/images/assessment-white.svg";
import assessmentImgBlack from "@/assets/images/assessment-black.svg";
import styles from "@/styles/sidebar.module.css";
import { Menu, MenuItem } from "@mui/material";
import { GoKebabVertical } from "react-icons/go";
import { CgProfile, CgPassword, CgFileDocument, CgLogOut } from "react-icons/cg";
import { usePathname } from "next/navigation";
import { signIn, signOut, useSession } from "next-auth/react";

const UserSideBar = () => {
    const pathname = usePathname().toString()
    const [optionFocus, setOptionFocus] = useState({
        dashboard: false,
        assessment: false
    })

    
    const { data: session } = useSession();

    const [anchorEl, setAnchorEl] = React.useState(null)
    const handleSidbarClick = (focusState) => {
        setOptionFocus(focusState)
    }
    const handleClose = () => { setAnchorEl(null); }
    const handleClick = (event) => { setAnchorEl(event.currentTarget); }

    // const expandUserManagement = () => {
    //     setOptionFocus({
    //         dashboard: false,
    //         assessment: false,
    //         reports: false,
    //         user_management: true
    //     });
    // }

    useEffect(()=>{   
        setOptionFocus({
            dashboard: (pathname === "/user/dashboard" ? true: false),
            assessment: (pathname === "/user/assessment" ? true: false)
        });
    }, [pathname])

    return (
        <div className="d-flex flex-column align-items-center align-items-sm-start text-white min-vh-100 ">

            <Image id={styles.sidebar_icon_image} className="mt-3 mb-5" alt="#" src={assessItImg} />

            <ul className={`nav row nav-pills flex-column mb-auto align-items-center align-items-sm-start ${styles.menu}`} id="menu">
                <li className="mt-3">
                    <Link href="/user/dashboard" className={`align-items-left px-3 align-middle text-decoration-none ${optionFocus.dashboard ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                        onClick={() => handleSidbarClick({
                            dashboard: true,
                            assessment: false
                        })}
                    >
                        {optionFocus.dashboard ?
                            <Image className={`${styles.sidebar_items_img}`} alt="#" src={dashboardImgBlack} /> :
                            <Image className={`${styles.sidebar_items_img}`} alt="#" src={dashboardImgWhite} />
                        }
                        {optionFocus.dashboard ?
                            <span className="text-dark ms-2 d-sm-inline">Dashboard</span> :
                            <span className="text-light ms-2 d-sm-inline">Dashboard</span>
                        }
                    </Link>
                </li>
                <li className="mt-3">
                    <Link href="/user/assessment" className={`td-flex align-items-left px-3 align-middle text-decoration-none ${optionFocus.assessment ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                        onClick={() => handleSidbarClick({
                            dashboard: false,
                            assessment: true
                        })}
                    >
                        {optionFocus.assessment ?
                            <Image className={`${styles.sidebar_items_img}`} alt="#" src={assessmentImgBlack} /> :
                            <Image className={`${styles.sidebar_items_img}`} alt="#" src={assessmentImgWhite} />
                        }
                        {optionFocus.assessment ?
                            <span className="text-dark ms-2 d-sm-inline">My Assessments</span> :
                            <span className="text-light ms-2 d-sm-inline">My Assessments</span>
                        }
                    </Link>
                    {/* {optionFocus.assessment ? null : null} */}
                </li>
                
            </ul>
            <hr />

            <div>
                <div>
                    <label className={`d-flex align-items-center text-white text-decoration-none ${styles.admin}`}>
                        <img src="https://github.com/mdo.png" alt="hugenerd" width="45" height="45" className="rounded-circle" />
                        <div className="d-flex flex-column" style={{ width: "109px" }}>
                        {session?.user && (
                                    <>
                                        <strong className={`d-sm-inline mx-3 ${styles.username}`}>{session.user.name}</strong>
                                        <span className={`d-sm-inline mx-3 ${styles.userRole}`}>{session.user.roles}</span>
                                    </>
                                )}
    
                        </div>
                        <GoKebabVertical style={{ fontSize: "20px", marginLeft: "-7px", }} onClick={handleClick} />
                    </label>

                </div>

                <Menu style={{ top: "-5px", left: "40px", fontSize: "20px" }} keepMounted anchorEl={anchorEl} onClose={handleClose} open={Boolean(anchorEl)}>
                    <MenuItem style={{ fontSize: "20px", marginBottom: "-18px", marginTop: "-8px" }} onClick={handleClose}>
                        <CgProfile style={{ fontSize: "20px" }} /> &nbsp;
                        Profile
                    </MenuItem><hr />
                    <MenuItem style={{ fontSize: "20px", marginBottom: "-18px", marginTop: "-18px" }} onClick={handleClose}>
                        <CgPassword style={{ fontSize: "20px" }} /> &nbsp;
                        Change Password
                    </MenuItem><hr />
                    <MenuItem style={{ fontSize: "20px", marginBottom: "-18px", marginTop: "-18px" }} onClick={handleClose}>
                        <CgFileDocument style={{ fontSize: "20px" }} /> &nbsp;
                        Privacy Policies
                    </MenuItem><hr />
                    {session ? ( 
                    <MenuItem style={{ color: "#3340B1", fontSize: "20px", marginBottom: "-8px", marginTop: "-18px" }} onClick={() => signOut()}>
                        <CgLogOut style={{ fontSize: "20px" }} /> &nbsp;
                        Log out
                    </MenuItem>
                    ) : null} 
                </Menu>
            </div>
        </div>
    )
}

export default UserSideBar;