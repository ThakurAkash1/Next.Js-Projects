import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import assessItImg from "@/assets/images/assessIt_icon_full.svg";
import dashboardImgBlack from "@/assets/images/dashboard-black.svg";
import assessmentImgBlack from "@/assets/images/assessment-black.svg";
import dashboardImgWhite from "@/assets/images/dashboard-white.svg";
import reportsImgBlack from "@/assets/images/reports-black.svg";
import assessmentImgWhite from "@/assets/images/assessment-white.svg";
import userImgBlack from "@/assets/images/user-management-black.svg";
import reportsImgWhite from "@/assets/images/reports-white.svg";
import userImgWhite from "@/assets/images/user-management-white.svg";
import styles from "@/styles/sidebar.module.css";
import { BiChevronRight, BiChevronLeft } from "react-icons/bi";
import { Menu, MenuItem } from "@mui/material";
import { CgProfile, CgPassword, CgFileDocument, CgLogOut } from "react-icons/cg";
import { usePathname } from "next/navigation";
import { signIn, signOut, useSession } from "next-auth/react";

const MobileSidebar = () => {
  const pathname = usePathname().toString()
  const [showButton, setShowButton] = useState(true);
  const [showMenu, setShowMenu] = useState(true);
  const [anchorEl, setAnchorEl] = useState(null);
  const [showUserManagementContent, setShowUserManagementContent] = useState(false);
  const [showAdminContent, setShowAdminContent] = useState(false);

  const [optionFocus, setOptionFocus] = useState({
    dashboard: false,
    assessment: false,
    reports: false,
    user_management: false
  });

  const { data: session } = useSession();

  useEffect(() => {

    setOptionFocus({
      dashboard: (pathname === "/admin/dashboard" ? true : false),
      assessment: (pathname === "/admin/myAssessment" ? true : false),
      reports: (pathname === "/admin/reports" ? true : false),
      user_management: (pathname === "/admin/userManagement/*" ? true : false)
    });
  }, [pathname])


  const handleSidbarClick = (focusState) => {
    setOptionFocus(focusState);
    // setShowUserManagementContent(false);
    // props.setMobileSidebarSelect(focusState);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const toggleButton = () => {
    setShowButton(!showButton);
  };

  const toggleMenu = () => {
    setShowMenu(!showMenu);
  };

  const expandUserManagement = () => {
    setOptionFocus({
      dashboard: false,
      assessment: false,
      reports: false,
      user_management: true
    });
    setShowUserManagementContent(true);
  };

  const collapseUserManagement = () => {
    setOptionFocus({
      dashboard: false,
      assessment: false,
      reports: false,
      user_management: false
    });
    setShowUserManagementContent(false);
  };

  const expandAdminManagement = () => {
    setOptionFocus({
      dashboard: false,
      assessment: false,
      reports: false,
      user_management: false,
      admin: true
    });
    setShowAdminContent(true);
  };

  const collapseAdminManagement = () => {
    setOptionFocus({
      dashboard: false,
      assessment: false,
      reports: false,
      user_management: false,
      admin: false
    });
    setShowAdminContent(false);
  };

  return (
    <div className="d-flex flex-column align-items-center text-white ">

      {showButton && showMenu &&
        <div style={{ display: "block" }} className={`${styles.navbar_top}`}>
          <Image id={styles.sidebar_icon_image} className="mt-3 mb-5" alt="#" src={assessItImg} />
          <ul className={`nav row nav-pills flex-column mb-auto  align-items-sm-start`} id="menu">
            <li className="mt-3">
              <Link href="/admin/dashboard"
                className={`td-flex align-items-left px-3 align-middle text-decoration-none ${optionFocus.dashboard ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                onClick={() =>
                  handleSidbarClick({
                    dashboard: true,
                    assessment: false,
                    reports: false,
                    user_management: false
                  })
                }
              >
                {optionFocus.dashboard ?
                  <Image className={`${styles.sidebar_items_img}`} alt="#" src={dashboardImgBlack} /> :
                  <Image className={`${styles.sidebar_items_img}`} alt="#" src={dashboardImgWhite} />
                }
                {optionFocus.dashboard ?
                  <span className="text-dark ms-2 d-sm-inline">Dashboard</span> :
                  <span className="text-light ms-2 d-sm-inline">Dashboard</span>
                }
              </Link>
            </li >
            <li className="mt-3">
              <Link href="/admin/myAssessment"
                className={`td-flex align-items-left px-3 align-middle text-decoration-none ${optionFocus.assessment ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                onClick={() =>
                  handleSidbarClick({
                    dashboard: false,
                    assessment: true,
                    reports: false,
                    user_management: false
                  })
                }
              >
                {optionFocus.assessment ?
                  <Image className={`${styles.sidebar_items_img}`} alt="#" src={assessmentImgBlack} /> :
                  <Image className={`${styles.sidebar_items_img}`} alt="#" src={assessmentImgWhite} />
                }
                {optionFocus.assessment ?
                  <span className="text-dark ms-2 d-sm-inline">My Assessments</span> :
                  <span className="text-light ms-2 d-sm-inline">My Assessments</span>
                }
              </Link>
              {optionFocus.assessment ? null : null}
            </li>
            <li className="mt-3">
              <Link href="/admin/reports"
                className={`td-flex align-items-left px-3 align-middle text-decoration-none ${optionFocus.reports ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                onClick={() =>
                  handleSidbarClick({
                    dashboard: false,
                    assessment: false,
                    reports: true,
                    user_management: false
                  })
                }
              >
                {optionFocus.reports ?
                  <Image id="img-reports" className={`${styles.img_reports}`} alt="#" src={reportsImgBlack} /> :
                  <Image id="img-reports" className={`${styles.img_reports}`} alt="#" src={reportsImgWhite} />
                }
                {optionFocus.reports ?
                  <span className="text-dark ms-2 d-sm-inline">Reports</span> :
                  <span className="text-light ms-2 d-sm-inline">Reports</span>
                }
              </Link>
              {optionFocus.reports ? null : null}
            </li>
            <li className="mt-3">
              <div onClick={toggleButton} className={`${styles.user_dropdown_div}`}>
                <a
                  className={`text-dark td-flex align-items-left px-3 align-middle text-decoration-none ${optionFocus.user_management ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                  type="button"
                  onClick={showUserManagementContent ? collapseUserManagement : expandUserManagement}
                >
                  {optionFocus.user_management ?
                    <Image className={`${styles.sidebar_items_img}`} alt="#" src={userImgBlack} /> :
                    <Image className={`${styles.sidebar_items_img}`} alt="#" src={userImgWhite} />
                  }
                  {optionFocus.user_management ?
                    <span className="text-dark ms-2 d-sm-inline">User Management<BiChevronRight style={{ fontSize: '17px' }} /></span> :
                    <span className="text-light ms-2 d-sm-inline">User Management<BiChevronRight style={{ fontSize: '17px' }} /></span>
                  }
                </a>
              </div>
            </li>
          </ul >

          {/* the admin profile picture */}
          <div onClick={toggleMenu} className={`ml-1 d-flex align-items-center text-white text-decoration-none ${styles.admin}`} style={{ minHeight: "45px" }}>
            <a
              className={`text-dark td-flex align-items-left px-3 align-middle text-decoration-none ${styles.sidebar_items}`}
              type="button"
              onClick={showAdminContent ? collapseAdminManagement : expandAdminManagement}
            />
            <img src="https://github.com/mdo.png" alt="hugenerd" width="45" height="45" className="rounded-circle" />
            <div className="d-flex flex-column" style={{ width: "109px" }}>
              {session?.user && (
                <>
                  <strong className={`d-sm-inline mx-3 ${styles.username}`}>{session.user.name}</strong>
                  <span className={`d-sm-inline mx-3 ${styles.userRole}`}>{session.user.roles}</span>
                </>
              )}
            </div>
            <BiChevronRight style={{ fontSize: "20px", marginLeft: "-7px" }} onClick={handleClick} />
          </div>
        </div>
      }

      {!showButton &&
        <div  >

          <div className={styles.overlay}>
            <ul className={`${styles.dropdown_menu}`}>
              <div className={`${styles.back_arrow}`} onClick={toggleButton}>
                <BiChevronLeft style={{ fontSize: '48px' }} />
              </div>
              <li className={`${styles.user_dropdown} `}><Link className="text-light" href="/admin/userManagement/roles">Roles</Link></li>
              <li className={`${styles.user_dropdown} `}><Link className="text-light" href="/admin/userManagement/users">Users</Link></li>
              <li className={`text-dark ${styles.user_dropdown} `}><Link className="text-light" href="/admin/userManagement/groups">Groups</Link></li>
            </ul>
          </div>

        </div>}

      {!showMenu &&
        <div  >

          <div className={styles.overlay}>
            <ul className={`${styles.admin_menu}`}>
              <div className={` ${styles.back_arrow}`} onClick={toggleMenu}>
                <BiChevronLeft style={{ fontSize: '48px' }} />
              </div>
              <li className={`${styles.admin_dropdown}`}><a className="text-dark">My Profile</a></li>
              <li className={`${styles.admin_dropdown}`}><a className="text-dark">Change Password</a></li>
              <li className={`${styles.admin_dropdown}`}><a className="text-dark">Privacy Policies</a></li>
              {session ? (
              <li className={`text-dark ${styles.admin_dropdown}`}><a onClick={() => signOut()}>Log Out</a>
              </li>
              ) : null}
            </ul>
          </div>

        </div>}

      {/* Menu for the page */}
      <div>
        <Menu style={{ top: "-5px", left: "auto", right: "10px" }} anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleClose}>
          <MenuItem onClick={handleClose}>
            <CgProfile style={{ marginRight: "10px" }} />
            My Profile
          </MenuItem>
          <MenuItem onClick={handleClose}>
            <CgPassword style={{ marginRight: "10px" }} />
            Change Password
          </MenuItem>
          <MenuItem onClick={handleClose}>
            <CgFileDocument style={{ marginRight: "10px" }} />
            Terms of Service
          </MenuItem>
          <MenuItem onClick={handleClose}>
            <CgLogOut style={{ marginRight: "10px" }} />
            Logout
          </MenuItem>
        </Menu>
      </div>
    </div >
  );
};
export default MobileSidebar;