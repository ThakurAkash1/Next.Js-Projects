import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import assessItImg from "@/assets/images/assessIt_icon_full.svg";
import dashboardImgBlack from "@/assets/images/dashboard-black.svg";
import dashboardImgWhite from "@/assets/images/dashboard-white.svg";
import assessmentImgWhite from "@/assets/images/assessment-white.svg";
import assessmentImgBlack from "@/assets/images/assessment-black.svg";
import reportsImgWhite from "@/assets/images/reports-white.svg";
import reportsImgBlack from "@/assets/images/reports-black.svg";
import userImgWhite from "@/assets/images/user-management-white.svg";
import userImgBlack from "@/assets/images/user-management-black.svg";
import styles from "@/styles/sidebar.module.css";
import { BiChevronDown } from "react-icons/bi";
import { Menu, MenuItem } from "@mui/material";
import { GoKebabVertical } from "react-icons/go";
import { CgProfile, CgPassword, CgFileDocument, CgLogOut } from "react-icons/cg";
import { usePathname } from "next/navigation";
import { signIn, signOut, useSession } from "next-auth/react";
import UserSideBar from "./UserSideBar";

const SideBar = () => {
    const pathname = usePathname().toString()
    const [optionFocus, setOptionFocus] = useState({
        dashboard: false,
        assessment: false,
        reports: false,
        user_management: false
    })

    const { data: session } = useSession();
    // if (session) console.log(session.user.roles);


    const [anchorEl, setAnchorEl] = React.useState(null)
    const handleSidbarClick = (focusState) => {
        setOptionFocus(focusState)
    }
    const handleClose = () => { setAnchorEl(null); }
    const handleClick = (event) => { setAnchorEl(event.currentTarget); }

    const expandUserManagement = () => {
        setOptionFocus({
            dashboard: false,
            assessment: false,
            reports: false,
            user_management: true
        });
    }
 // Ensure session is defined before accessing its properties
 const isAdmin = session?.user?.roles?.includes('Admin');
    useEffect(() => {
        setOptionFocus({
            dashboard: (pathname === "/admin/dashboard" ? true : false),
            assessment: (pathname === "/admin/myAssessment" ? true : false),
            reports: (pathname === "/admin/reports" ? true : false),
            user_management: (pathname === "/admin/userManagement/*" ? true : false)
        });
    }, [pathname])

    

    return (
        <>
            {session?.user?.roles.includes('Admin') ? (
                <div className="d-flex flex-column align-items-center align-items-sm-start text-white min-vh-100 ">

                    <Image id={styles.sidebar_icon_image} className="mt-3 mb-5" alt="#" src={assessItImg} />

                    <ul className={`nav row nav-pills flex-column mb-auto align-items-center align-items-sm-start ${styles.menu}`} id="menu">
                        <li className="mt-3">
                            <Link href="/admin/dashboard" className={`align-items-left px-3 align-middle text-decoration-none ${optionFocus.dashboard ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                                onClick={() => handleSidbarClick({
                                    dashboard: true,
                                    assessment: false,
                                    reports: false,
                                    user_management: false
                                })}
                            >
                                {optionFocus.dashboard ?
                                    <Image className={`${styles.sidebar_items_img}`} alt="#" src={dashboardImgBlack} /> :
                                    <Image className={`${styles.sidebar_items_img}`} alt="#" src={dashboardImgWhite} />
                                }
                                {optionFocus.dashboard ?
                                    <span className="text-dark ms-2 d-sm-inline">Dashboard</span> :
                                    <span className="text-light ms-2 d-sm-inline">Dashboard</span>
                                }
                            </Link>
                        </li>
                        <li className="mt-3">
                            <Link href="/admin/myAssessment" className={`td-flex align-items-left px-3 align-middle text-decoration-none ${optionFocus.assessment ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                                onClick={() => handleSidbarClick({
                                    dashboard: false,
                                    assessment: true,
                                    reports: false,
                                    user_management: false
                                })}
                            >
                                {optionFocus.assessment ?
                                    <Image className={`${styles.sidebar_items_img}`} alt="#" src={assessmentImgBlack} /> :
                                    <Image className={`${styles.sidebar_items_img}`} alt="#" src={assessmentImgWhite} />
                                }
                                {optionFocus.assessment ?
                                    <span className="text-dark ms-2 d-sm-inline">My Assessments</span> :
                                    <span className="text-light ms-2 d-sm-inline">My Assessments</span>
                                }
                            </Link>
                            {optionFocus.assessment ? null : null}
                        </li>
                        <li className="mt-3">
                            <Link href="/admin/reports" className={`td-flex align-items-left px-3 align-middle text-decoration-none ${optionFocus.reports ? `${styles.sidebar_items_selected}` : `${styles.sidebar_items}`}`}
                                onClick={() => handleSidbarClick({
                                    dashboard: false,
                                    assessment: false,
                                    reports: true,
                                    user_management: false
                                })}
                            >
                                {optionFocus.reports ?
                                    <Image id="img-reports" className={`${styles.img_reports}`} alt="#" src={reportsImgBlack} /> :
                                    <Image id="img-reports" className={`${styles.img_reports}`} alt="#" src={reportsImgWhite} />
                                }
                                {optionFocus.reports ?
                                    <span className="text-dark ms-2 d-sm-inline">Reports</span> :
                                    <span className="text-light ms-2 d-sm-inline">Reports</span>
                                }
                            </Link>
                            {optionFocus.reports ? null : null}
                        </li>
                        <li className="mt-3">
                            <div className={`${styles.user_dropdown_div}`}>
                                <a className={`td-flex align-items-left px-3 align-middle text-decoration-none ${optionFocus.user_management ? `${styles.user_dropdown_div_selected}` : `${styles.sidebar_items}`}`}
                                    type="button"
                                    onClick={expandUserManagement}
                                >
                                    {optionFocus.user_management ?
                                        <Image className={`${styles.sidebar_items_img}`} alt="#" src={userImgBlack} /> :
                                        <Image className={`${styles.sidebar_items_img}`} alt="#" src={userImgWhite} />
                                    }

                                    {optionFocus.user_management ?
                                        <span className="text-dark ms-2 d-sm-inline">User Management<BiChevronDown style={{ fontSize: '17px' }} /></span> :
                                        <span className="text-light ms-2 d-sm-inline">User Management<BiChevronDown style={{ fontSize: '17px' }} /></span>
                                    }
                                </a>
                                {optionFocus.user_management ? <ul className={`bg-light ${styles.dropdown_menu} `}>
                                    <li className={`${styles.user_dropdown}`}><Link className="text-dark" href="/admin/userManagement/roles" >Roles</Link></li>
                                    <li className={`${styles.user_dropdown}`}><Link className="text-dark" href="/admin/userManagement/users" >Users</Link></li>
                                    <li className={`${styles.user_dropdown}`}><Link className="text-dark" href="/admin/userManagement/groups">Groups</Link></li>
                                </ul> : null}
                            </div>
                        </li>
                    </ul>
                    <hr />

                    <div>
                        <div>
                            <label className={`d-flex align-items-center text-white text-decoration-none ${styles.admin}`}>
                                <img src="https://github.com/mdo.png" alt="hugenerd" width="45" height="45" className="rounded-circle" />
                                <div className="d-flex flex-column" style={{ width: "109px" }}>
                                    {/* <span className={`d-sm-inline mx-3 ${styles.username}`}>John Smith</span> */}

                                    {session?.user && (
                                        <>
                                            <strong className={`d-sm-inline mx-3 ${styles.username}`}>{session.user.name}</strong>
                                            <span className={`d-sm-inline mx-3 ${styles.userRole}`}>{session.user.roles}</span>
                                        </>
                                    )}
                                </div>
                                <GoKebabVertical style={{ fontSize: "20px", marginLeft: "-7px", }} onClick={handleClick} />
                            </label>

                        </div>

                        <Menu style={{ top: "-5px", left: "40px", fontSize: "20px" }} keepMounted anchorEl={anchorEl} onClose={handleClose} open={Boolean(anchorEl)}>
                            <MenuItem style={{ fontSize: "20px", marginBottom: "-18px", marginTop: "-8px" }} onClick={handleClose}>
                                <CgProfile style={{ fontSize: "20px" }} /> &nbsp;
                                Profile
                            </MenuItem><hr />
                            <MenuItem style={{ fontSize: "20px", marginBottom: "-18px", marginTop: "-18px" }} onClick={handleClose}>
                                <CgPassword style={{ fontSize: "20px" }} /> &nbsp;
                                Change Password
                            </MenuItem><hr />
                            <MenuItem style={{ fontSize: "20px", marginBottom: "-18px", marginTop: "-18px" }} onClick={handleClose}>
                                <CgFileDocument style={{ fontSize: "20px" }} /> &nbsp;
                                Privacy Policies

                            </MenuItem><hr />
                            {session ? (
                                <MenuItem style={{ color: "#3340B1", fontSize: "20px", marginBottom: "-8px", marginTop: "-18px" }} onClick={() => signOut()}>
                                    <CgLogOut style={{ fontSize: "20px" }} /> &nbsp;
                                    Log out
                                </MenuItem>
                            ) : null}
                        </Menu>
                    </div>
                </div>
            ) : (
                <UserSideBar />
              )}
        </>
    )
}

export default SideBar;
