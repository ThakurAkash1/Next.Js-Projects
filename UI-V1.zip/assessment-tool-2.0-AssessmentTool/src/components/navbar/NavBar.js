import React, { useState ,useEffect} from 'react';
import Image from "next/image";
import styles from "@/styles/navbar.module.css";
import { BsSearch, BsQuestionCircle } from "react-icons/bs";
import navbarnotification from "@/assets/images/navbar-notification.svg";
import navbarquesion from "@/assets/images/query.svg";
import { useRouter} from "next/navigation";
import { useSession } from "next-auth/react";

const Navbar = () => {
  const [searchQuery, setSearchQuery] = useState("Search");
  const { data: session } = useSession();
  const { status } = useSession();
  const router = useRouter();
  const handleSearch = () => {
    console.log("Performing search for:", searchQuery);
  };

  const handleChange = (e) => {
    setSearchQuery(e.target.value);
  };

  useEffect(() => {
    if (status === "loading") return; 
    if (status === "unauthenticated") {
        signIn("keycloak");
    } else if (status === "authenticated") {
        if (session?.user?.roles?.includes("User")) {
            router.push("/user/dashboard");
        } else if (session?.user?.roles?.includes("Admin")) {
            router.push("/admin/dashboard");
        }
    }
}, [status, session]);

  return (
    <nav className={`navbar navbar-expand-lg navbar-light bg-light`}>
      <div className={`container-fluid ${styles.navbarContainer}`}>
        <div className={`d-flex align-items-center ${styles.leftColumn}`}>
          <div className={`rounded d-flex align-items-center  ${styles.searchBar}`}>
            <BsSearch className={"ms-3 "}/>
            <input type="search" className="border-0 p-1 m-1 text-dark shadow-none" placeholder="Search.."  onChange={handleChange}/>
          </div>
        </div>
        <div className={`d-flex align-items-center ${styles.rightColumn}`}>
          <Image alt="#" src={navbarnotification} /> &nbsp; &nbsp;
          <Image alt="#" src={navbarquesion} />
        </div>
      </div>
    </nav>
  );
};

export default Navbar;