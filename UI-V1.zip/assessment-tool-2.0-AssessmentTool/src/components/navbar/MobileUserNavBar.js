import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import vector from '@/assets/images/Vector.svg';
import styles from '../../styles/navbar.module.css';
import navbarnotification from '@/assets/images/navbar-notification.svg';
import navbarquesion from '@/assets/images/query.svg';
import searchCircle from '@/assets/images/search-circle.svg';
import MobileUserSideBar from '../sidebar/MobileUserSideBar';
import { usePathname } from 'next/navigation'


const MobileUserNavBar = () => {
	const pathname = usePathname().toString()
  const [isSlideBarVisible, setSlideBarVisible] = useState(false);
  const [isDesktop, setIsDesktop] = useState(false);

  const handleToggleClick = () => {
    setSlideBarVisible(!isSlideBarVisible);


    if (!isSlideBarVisible) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }

  };

  return (
    <>
      <div className={isSlideBarVisible ? styles.overlayBlur : ''} onClick={handleToggleClick} />
      <nav id="content-container" className={`w-100 navbar navbar-expand-lg navbar-light bg-light`}>
        <button className="navbar-toggler" type="button" onClick={handleToggleClick}>
          <a className="navbar-brand" href="#">
            <Image className="m-0 m-md-auto mt-md-5 mb-md-5 mx-md-5" alt="#" src={vector} />
          </a>
        </button>
        <span className={` h-22  fs-18 lh-22 text-dark ${styles.navbarbrand}`}>
        	{pathname === "/admin/dashboard" && "Dashboard"}
        	{pathname === "/admin/myAssessment" && "My Assessments"}
        	{pathname === "/admin/reports" && "Reports"}
        	{pathname === "/admin/userManagement/roles" && "Roles"}
        	{pathname === "/admin/userManagement/groups" && "Groups"}
        	{pathname === "/admin/userManagement/users" && "Users"}
        </span>
        <div className="ml-auto">
          <Image alt="#" src={searchCircle} /> &nbsp;
          <Image alt="#" src={navbarnotification} /> &nbsp;
          <Image alt="#" src={navbarquesion} />
        </div>
        
        {isSlideBarVisible && (
          <div className={`text-center position-absolute top-0 start-0 ${styles.mobilebar}`}>
            <ul class="font-size-12 px-0">
              <MobileUserSideBar />
            </ul>
          </div>
        )}
      </nav>
    </>
  );
};

export default MobileUserNavBar;
