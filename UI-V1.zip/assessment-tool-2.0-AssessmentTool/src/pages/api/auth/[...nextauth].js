import NextAuth from "next-auth";
import KeycloakProvider from 'next-auth/providers/keycloak';
import getConfig from "next/config";

const {
    publicRuntimeConfig: { processEnv },
} = getConfig();

const {
    NEXT_PUBLIC_AUTH_CLIENT_ID,
    NEXT_PUBLIC_AUTH_CLIENT_SECRET,
    NEXT_PUBLIC_AUTH_ISSUER,
} = processEnv;

const refreshAccessToken = async (token) => {
    try {
        const response = await fetch(`${processEnv.NEXT_PUBLIC_AUTH_ISSUER}/protocol/openid-connect/token`, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
                client_id: processEnv.NEXT_PUBLIC_AUTH_CLIENT_ID,
                client_secret: processEnv.NEXT_PUBLIC_AUTH_CLIENT_SECRET,
                // scope: "openid",
                grant_type: "refresh_token",
                refresh_token: token.refresh_token, // Use refresh token to get a new access token
            }),
        });

        const refreshedTokens = await response.json();

        if (!response.ok) {
            throw refreshedTokens;
        }
         // Log the refresh token is generating by accesstoken
         console.log("Refresh Token:", refreshedTokens.refresh_token);

        return {
            ...token,
            accessToken: refreshedTokens.access_token,
            accessTokenExpires: Date.now() + (refreshedTokens.expires_in - 15) * 1000, // Refresh token 15 seconds before expiry
            refreshToken: refreshedTokens.refresh_token || token.refreshToken,
        };
    } catch (error) {
        console.error("Error refreshing token:", error);
        return {
            ...token,
            error: "RefreshAccessTokenError",
        };
    }
};

const authOptions = {
    providers: [
        KeycloakProvider({
            clientId: NEXT_PUBLIC_AUTH_CLIENT_ID,
            clientSecret: NEXT_PUBLIC_AUTH_CLIENT_SECRET,
            issuer: NEXT_PUBLIC_AUTH_ISSUER,
            refreshToken: true,
        })
    ],
    callbacks: {
        async session({ session, token }) {
            // Log the access token
            // console.log("Access Token:", token.access_token);
            
            session.user.id = token.id_token;
            session.user.access_token = token.access_token;

            session.user.roles = JSON.parse(Buffer.from(token.access_token.split('.')[1], 'base64').toString()).realm_access.roles

            return session;
        },
        async jwt({ token, account }) {
            if (account) {
                token.id_token = account.id_token
                token.provider = account.provider
                token.access_token = account.access_token
            }
            return token
        },
    },
    events: {
        async signOut({ token }) {
            if (token.provider === "keycloak") {
                const logOutUrl = new URL(`${NEXT_PUBLIC_AUTH_ISSUER}/protocol/openid-connect/logout`)
                logOutUrl.searchParams.set("id_token_hint", token.id_token)
                await fetch(logOutUrl);
            }
        },
    },
    secret: "de2R96laWDRcvSYsvgboNxnzVQOn970ufvmTLifk998=",
};

export default NextAuth(authOptions);





// import NextAuth from "next-auth";
// import KeycloakProvider from 'next-auth/providers/keycloak';
// import getConfig from "next/config";

// const {
//     publicRuntimeConfig: { processEnv },
// } = getConfig();

// const {
//     NEXT_PUBLIC_AUTH_CLIENT_ID,
//     NEXT_PUBLIC_AUTH_CLIENT_SECRET,
//     NEXT_PUBLIC_AUTH_ISSUER,
// } = processEnv;

// const authOptions = {
//     providers: [
//         KeycloakProvider({
//             clientId: NEXT_PUBLIC_AUTH_CLIENT_ID,
//             clientSecret: NEXT_PUBLIC_AUTH_CLIENT_SECRET,
//             issuer: NEXT_PUBLIC_AUTH_ISSUER,
//             refreshToken: true,
//         })
//         // KeycloakProvider({
//         //     clientId: process.env.KEYCLOAK_ID,
//         //     clientSecret: process.env.KEYCLOAK_SECRET,
//         //     issuer: process.env.KEYCLOAK_ISSUER,
//         //   })
//     ],
//     callbacks: {
//         async session({ session, token }) {
//             session.user.id = token.id_token;
//             session.user.access_token = token.access_token;

//            session.user.roles = JSON.parse(Buffer.from(token.access_token.split('.')[1], 'base64').toString()).realm_access.roles

//             // Add userRole to the session if available in the token
//             // if (token.id_token && token.id_tokenParsed) {
//             //     session.user.userRole = token.id_tokenParsed.realm_access.roles;
//             // }

//             return session;
//         },
//         async jwt({ token, account }) {
//             if (account) {
//                 token.id_token = account.id_token
//                 token.provider = account.provider
//                 token.access_token = account.access_token
//             }
//             return token
//         },
//     },
//     events: {
//         async signOut({ token }) {
//             if (token.provider === "keycloak") {
//                 const logOutUrl = new URL(`${NEXT_PUBLIC_AUTH_ISSUER}/protocol/openid-connect/logout`)
//                 logOutUrl.searchParams.set("id_token_hint", token.id_token)
//                 await fetch(logOutUrl);
//             }
//         },
//     },
//     secret: "de2R96laWDRcvSYsvgboNxnzVQOn970ufvmTLifk998="
// };

// export default NextAuth(authOptions);
