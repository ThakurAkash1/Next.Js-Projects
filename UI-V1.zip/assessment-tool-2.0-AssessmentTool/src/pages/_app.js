// import React, { useState, useEffect } from 'react';
import '@/styles/globals.css'
import { Poppins } from 'next/font/google';
import 'bootstrap/dist/css/bootstrap.css'
import SideBar from '../components/sidebar/SideBar'
import Navbar from '@/components/navbar/NavBar'
import MobileNavbar from '@/components/navbar/MobileNavBar';
import styles from '@/styles/index.module.css';
import { Inter } from 'next/font/google';
import { SessionProvider } from "next-auth/react"; 
// import { useSession } from "next-auth/react";
// import { useRouter } from "next/navigation";

const inter = Inter({ subsets: ['latin'] });

export default function App({ Component, pageProps }) {

  return (
    <SessionProvider session={pageProps.session} refetchInterval={0}>
      <div className="container-fluid">

        <div className="row">

          <div className={`col-4 col-md-3 col-lg-2 .d-md-none .d-lg-block d-none d-sm-none d-md-block ${styles.sidebar}`} id="sidebar-container">
            <SideBar />
          </div>

          <div className={`col-9 col-sm-12 ${styles.navbar}`} >
            <div className="row" style={{ backgroundColor: "#F5F5F5" }}>
              <div className='d-none d-sm-none d-md-block'><Navbar /></div>
              <div className='d-block d-md-none d-sm-block'><MobileNavbar /></div>
              <div className={` ${styles.primarycontent}`}></div>
              <Component {...pageProps} />
            </div>
          </div>
        </div>
      </div>
    </SessionProvider>
  )
}
