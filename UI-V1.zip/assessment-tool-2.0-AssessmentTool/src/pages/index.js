import React, { useState, useEffect } from 'react';
import { Inter } from 'next/font/google';
import { signIn, signOut, useSession } from "next-auth/react";

const inter = Inter({ subsets: ['latin'] });
export default function Home() {

  const { data: session } = useSession();

  return (
    <>
      <div className={`inter.className`}>
      </div>
    </>
  );
}














// import React, { useState, useEffect } from 'react';
// import { Inter } from 'next/font/google';
// import { signIn, signOut, useSession } from "next-auth/react";

// const inter = Inter({ subsets: ['latin'] });
// export default function Home() {
//   const { data: session, status } = useSession();

//   useEffect(() => {
//     const interval = setInterval(async () => {
//       if (status === "authenticated" && session?.accessToken) {
//         try {
//           const response = await fetch('/api/refresh-token');
//           if (response.ok) {
//             console.log('Token refreshed successfully.');
//           } else {
//             console.error('Failed to refresh token:', response.statusText);
//           }
//         } catch (error) {
//           console.error('Error refreshing token:', error);
//         }
//       }
//     }, 110000); 
//     return () => clearInterval(interval);
//   }, [session, status]);

//   return (
//     <>
//       <div className={`inter.className`}>
//       </div>
//     </>
//   );
// }
