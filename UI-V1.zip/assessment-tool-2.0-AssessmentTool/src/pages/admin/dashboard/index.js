import React, { useEffect } from "react";
import { Poppins } from 'next/font/google';
import styles from "@/styles/dashboard.module.css";
import Overview from '@/components/dashboard/Overview';
import ResultTable from '@/components/dashboard/ResultTable';
import SubmissionChart from '@/components/dashboard/submission';
import TopScores from '@/components/dashboard/TopScores';
import RecentActivities from '@/components/dashboard/RecentActivites';
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";


// const poppins = Poppins({ subsets: ['latin'] });
const poppins = Poppins({
  weight: '500',
  subsets: ['latin'],
})

const Dashboard = () => {

  const { data: session, status } = useSession();
  const router = useRouter();

useEffect(() => {
  // Check if the session is loaded and the user is authenticated

  if (status === "authenticated" && session?.user?.roles?.includes("User")){
      router.push("/user/dashboard")
    }

}, [session, status]);
//Show a loading indicator while the session is loading
if (status === "loading") {
  return <p>Loading...</p>
}else if (status === "authenticated" && session?.user?.roles?.includes("User")){
  return <p>forbidden...</p>
}

  return (
    <div className={poppins.className}>
    <div className={`${styles.Dashboardcontainer}`} >
      <div className= "row" >
        
        {/* Left Side */}
        <div className="col-md-8">
          <div className= 'row mt-2'>
            <div className="col-md-12">
              <div className={`card ${styles.card}`}>
                <div className="card-body">
                  <Overview />
                </div>
              </div>
            </div>
          </div>
          <div className= 'row mt-2'>
            <div className="col-md-12">
              <div className="card">
                <div className="card-body">
                  <SubmissionChart />
                </div>
              </div>
            </div>
          </div>
          <div className= "row mt-2 ">
            <div className="col-md-12 ">
              <div className="card h-100" >
                <div className="card-body">
                  <ResultTable />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side */}
        <div className="col-md-4">
          <div className={`row ${styles.Dashboard1}`}>
            <div className={`col-md-12 ${styles.topscoredetails}`}>
              <div className="row mt-2">
                <div className="col-md-12 col-lg-12">
                  <div className="card mb-3 h-100">
                    <div className="card-body">
                      <TopScores />
                    </div>
                  </div>
                </div>
              </div>
              <div className="row mt-2">
                <div className="col-md-12">
                  <div className="card mb-3 h-100">
                    <div className="card-body">
                      <RecentActivities />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  );
}
export default Dashboard;