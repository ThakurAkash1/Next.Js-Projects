import React, { useState, useEffect } from 'react';
import ActivityLog from '@/components/reports/ActivityLog';
import AllAssessments from '@/components/reports/AllAssessments';
import AssessmentIntake from '@/components/reports/AssessmentIntake';
import UserManagement from '@/components/reports/Usermanagement';
import Reports from '@/components/reports/Reports';
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

const RenderReport = () => {
  const [step, setStep] = useState(0);

  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    // Check if the session is loaded and the user is authenticated

    if (status === "authenticated" && session?.user?.roles?.includes("User")) {
      router.push("/user/dashboard")
    }

  }, [session, status]);
  //Show a loading indicator while the session is loading
  if (status === "loading") {
    return <p>Loading...</p>
  } else if (status === "authenticated" && session?.user?.roles?.includes("User")) {
    return <p>forbidden...</p>
  }
  
  return (
    <>
        {step === 0 && <Reports step={step} stepChange={setStep} />}
        {step === 1 && <ActivityLog step={step} stepChange={setStep} />}
        {step === 2 && <AllAssessments step={step} stepChange={setStep} />}
        {step === 3 && <AssessmentIntake step={step} stepChange={setStep} />}
        {step === 4 && <UserManagement step={step} stepChange={setStep} />}
    </>
  );
};
export default RenderReport;