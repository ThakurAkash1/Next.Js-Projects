import React, { useState, useEffect } from "react";
import NewAssessment from "@/components/myassessment/NewAssessment";
import CreateAssessment from "@/components/myassessment/CreateAssessment";
import AddQuestionAssessment from "@/components/myassessment/AddQuestionAssessment";
import AddQuestions from "@/components/myassessment/AddQuestions";
import AllQuestion from "@/components/myassessment/AllQuestion";
import Settings from "@/components/myassessment/Settings";
import AssessmentMobileSideBar from "@/components/myassessment/AssessmentMobileSideBar";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import BasicDetails from "@/components/myassessment/BasicDetails";
import AllQuestionDetails from "@/components/myassessment/AllQuestionDetails";
import SettingDetails from "@/components/myassessment/SettingDetails";
import AssessmentResultTable from "@/components/myassessment/AssessmentResultTable";
import ReceiveAllQuestions from "@/components/myassessment/ReceiveAllQuestions";

const MyAssessment = () => {
  const [step, setStep] = useState(0);
  const [assessmentId, setAssessmentId] = useState(null); // Initialize a state variable to hold the assessmentId
  const [question, setQuestion] = useState("");
  const [optionsData, setOptionsData] = useState([]);
  const [receivedOptionsData, setReceivedOptionsData] = useState([]);
  const [receivedQuestions, setReceivedQuestions] = useState([]);
  // const [assessmentholdId, setAssessmentholdId] = useState(null);

  const handleGetId = (assessmentId, question) => {
    setAssessmentId(assessmentId); // Update the state with the assessmentId from CreateAssessment
    setQuestion(question); // Update the state with EnterQuestion
    // console.log(assessmentId);
    // console.log(assessmentId,step===10);
  };

  // const handleGetId = async (assessmentId, question) => {
  //   // Wrap the state update in a Promise to use await
  //   await new Promise((resolve) => {
  //     setAssessmentId(assessmentId, () => {
  //       // This callback ensures that the state has been updated before resolving
  //       resolve();
  //     });
  //   });

  //   setQuestion(question); // Update the state with EnterQuestion
  //   // Now you can safely proceed after assessmentId is set
  // };

  const handleGetOptions = (newOptions, newQuestion) => {
    setReceivedOptionsData((prevData) => [...prevData, ...newOptions]);
    setReceivedQuestions((prevQuestions) => [
      ...prevQuestions,
      { question: newQuestion },
    ]);
  };

  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    // Check if the session is loaded and the user is authenticated

    if (status === "authenticated" && session?.user?.roles?.includes("User")) {
      router.push("/user/dashboard");
    }
  }, [session, status]);

  // useEffect(() => {
  //   // Check if assessmentId is not null before moving to the next step
  //   if (assessmentId !== null) {
  //     setStep(step + 1); // Move to the next step
  //     // setStep((prevStep) => prevStep + 1);
  //   }
  // }, [assessmentId, step]);

  //Show a loading indicator while the session is loading
  if (status === "loading") {
    return <p>Loading...</p>;
  } else if (
    status === "authenticated" &&
    session?.user?.roles?.includes("User")
  ) {
    return <p>forbidden...</p>;
  }
  
  // console.log(assessmentId);

  return (
    <>
      {step === 0 && (
        <NewAssessment
          step={step}
          stepChange={setStep}
          setAssessmentId={setAssessmentId}
          // setAssessmentholdId={setAssessmentholdId}
        />
      )}
      {step === 1 && (
        <CreateAssessment
          step={step}
          stepChange={setStep}
          onGetId={handleGetId}
        />
      )}
      {step === 2 && <AddQuestionAssessment step={step} stepChange={setStep} />}
      {step === 3 && (
        <AddQuestions
          step={step}
          stepChange={setStep}
          assessmentId={assessmentId}
          receivedQuestionId={question}
          // onGetId={handleGetId}
          question={question}
          onGetOptions={handleGetOptions} // Pass the handler to AddQuestions
          // assessmentholdId={assessmentholdId}
        />
      )}

      {step === 4 && (
        <AllQuestion
          step={step}
          stepChange={setStep}
          // receivedQuestionId={assessmentId}
          // receivedQuestion={question}
          // optionsData={[...optionsData, ...receivedOptionsData]}
          receivedQuestions={receivedQuestions}
          assessmentId={assessmentId}
        />
      )}
      {step === 5 && (
        <Settings
          step={step}
          stepChange={setStep}
          assessmentId={assessmentId}
          onGetId={handleGetId}
        />
      )}
      {step === 6 && (
        <AssessmentMobileSideBar step={step} stepChange={setStep} />
      )}
      {step === 7 && (
        <BasicDetails
          step={step}
          stepChange={setStep}
          assessmentId={assessmentId}
        />
      )}
      {step === 8 && (
        <AllQuestionDetails
          step={step}
          stepChange={setStep}
          // receivedQuestionId={assessmentId}
          // receivedQuestion={question}
          // optionsData={[...optionsData, ...receivedOptionsData]}
          receivedQuestions={receivedQuestions}
          assessmentId={assessmentId}
        />
      )}
      {step === 9 && (
        <SettingDetails
          step={step}
          stepChange={setStep}
          assessmentId={assessmentId}
        />
      )}
      {step === 10 && (
        <AssessmentResultTable
          step={step}
          stepChange={setStep}
          // assessmentId={assessmentId}
        />
      )}
      {step === 11 && (
        <ReceiveAllQuestions
          step={step}
          stepChange={setStep}
          // receivedQuestionId={assessmentId}
          // receivedQuestion={question}
          // optionsData={[...optionsData, ...receivedOptionsData]}
          receivedQuestions={receivedQuestions}
          // assessmentholdId={false ? assessmentholdId : assessmentId}
          assessmentId={assessmentId}
        />
      )}
    </>
  );
};

export default MyAssessment;
