import React, { useState, useEffect } from 'react';
import { Modal, Form, Button, Placeholder } from 'react-bootstrap';
import Image from 'next/image';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Userdata from '@/components/usermangement/Userdata';
import { Container, Table, Pagination } from 'react-bootstrap';
import Sorting from '@/assets/images/sorting.svg';
import styles from '@/styles/usermangement.module.css';
import RoleEdit from "@/assets/images/Propertyedit.svg";
import RoleEDelete from "@/assets/images/PropertyDelete.svg";
import { BsChevronDown } from 'react-icons/bs';
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";



const AddUser = (props) => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [sortColumn, setSortColumn] = useState(null);
  const [sortOrder, setSortOrder] = useState('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [showPopup, setShowPopup] = useState(false);
  const [editPopup, setShowPopupTest] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [role, setRole] = useState('');

  const handleRowDeletion = (rowIndex) => {
    const updatedData = [...roleData];
    updatedData.splice(rowIndex + indexOfFirstItem, 1);
    setRoleData(updatedData);
  };

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  const handlePaginationClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleSort = (column) => {
    if (column === sortColumn) {
      const newSortOrder = sortOrder === 'asc' ? 'desc' : 'asc';
      setSortOrder(newSortOrder);
    } else {
      setSortOrder('asc');
      setSortColumn(column);
    }
  };

  const handleAddMember = () => {
    setShowPopup(false);
  
  };

  const totalItems = Userdata.length;
  const itemsPerPage = 4;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = Userdata.slice(indexOfFirstItem, indexOfLastItem);

  const sortedItems = [...currentItems].sort((a, b) => {
    if (sortColumn) {
      if (sortOrder === 'asc') {
        return a[sortColumn].localeCompare(b[sortColumn]);
      } else {
        return b[sortColumn].localeCompare(a[sortColumn]);
      }
    }
    return 0;
  });

  const { data: session, status } = useSession();
  const router = useRouter();

useEffect(() => {
  // Check if the session is loaded and the user is authenticated

  if (status === "authenticated" && session?.user?.roles?.includes("User")){
      router.push("/user/dashboard")
    }

}, [session, status]);
//Show a loading indicator while the session is loading
if (status === "loading") {
  return <p>Loading...</p>
}else if (status === "authenticated" && session?.user?.roles?.includes("User")){
  return <p>forbidden...</p>
}

  return (
    <div className="table-responsive mt-1">
      <div className={`mt-1 ${styles.Totalcard}`}>
        <div className="d-flex justify-content-between">
          <div className="d-flex align-items-center mt-1">
            <h5 className={`mt-4 h6 text-dark  ${styles.Activitytitle}`}>Users</h5>
            <Button variant="link" onClick={() => props.stepChange(props.step - 1)}></Button>
          </div>
          <div className="w-100 mt-3">
            <div className={`float-end ${styles.dropdowns} justify-content-end`}>
              <Form.Control as="select" id="group-dropdown" onChange={(e) => setRole(e.target.value)}>
                <option value="" disabled selected>Select Role</option>
                <option value="admin">admin</option>
                <option value="Leader">Leader</option>
                <option value="Super admin">Super admin</option>
              </Form.Control>
            </div>
          </div>
        </div>


        <Modal show={editPopup} onHide={() => setShowPopupTest(false)}>
          <div className={`${styles.EditMember}`}>
            <Modal.Header closeButton className={`${styles.EditMemberTitle}`}>
              <Modal.Title>Edit User</Modal.Title>
            </Modal.Header>
            <Modal.Body>

            <Form.Group controlId="formRoles">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  className="form-control" placeholder="Gretchen Press"
                  onChange={(e) => setRole(e.target.value)} 
                >    
                </Form.Control>
              </Form.Group>

              <Form.Group controlId="formRoles">
                <Form.Label>Email ID</Form.Label>
                <Form.Control
                  className="form-control" placeholder="Gretchen@gmail.com" 
                  onChange={(e) => setRole(e.target.value)} 
                >   
                </Form.Control>
              </Form.Group>

              <Form.Group controlId="formRoles">
                <Form.Label>Select Role</Form.Label>
                <Form.Control
                  as="select"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                >
                  <option value="" disabled selected>Admin </option>
                  <option value="admin">admin</option>
                  <option value="Leader">Leader</option>
                  <option value="Super admin">Super admin</option>
                </Form.Control>
              </Form.Group>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowPopupTest(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleAddMember}>
                Save
              </Button>
            </Modal.Footer>
          </div>
        </Modal>


        <Modal show={showPopup} onHide={() => setShowPopup(false)}>
          <div className={`${styles.AddMember}`}>
            <Modal.Header closeButton className={`${styles.AddMemberTitle}`}>
              <Modal.Title>
                <span className={styles.AddRoleTitle}>Add Role</span>
              </Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form.Group controlId="formRoles">
                <Form.Label>Select Role</Form.Label>
                <Form.Control
                  as="select"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                >
                  <option value="" disabled selected>Select </option>
                  <option value="admin">admin</option>
                  <option value="Leader">Leader</option>
                  <option value="Super admin">Super admin</option>
                </Form.Control>
              </Form.Group>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowPopup(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleAddMember}>
                Add
              </Button>
            </Modal.Footer>
          </div>
        </Modal>

        <table className={`${styles.table}`}>
          <thead>
            <tr>
              <th>S.No</th>
              <th>
                <div className="d-flex align-items-center">
                  Name
                  <Button variant="link" onClick={() => handleSort('Name')}>
                    <Image alt="#" src={Sorting} />
                  </Button>
                </div>
              </th>
              <th>Email ID</th>
              <th>Group</th>
              <th>Role</th>
              <th>
                <div className="d-flex align-items-center">
                  Created On
                  <Button variant="link" onClick={() => handleSort('CreatedOn')}>
                    <Image alt="#" src={Sorting} />
                  </Button>
                </div>
              </th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {sortedItems.map((User, index) => (
              <tr key={index} className={`m-4 ${styles.row}`}>
                <td>{User.sno}</td>
                <td>{User.Name}</td>
                <td>{User.EmailID}</td>
                <td>{User.Group}</td>
                <td>
                  <Button variant ="link" className={styles.AddRoleCell} 
                  onClick={() => {
                    setSelectedUserId(User.id);
                    setShowPopup(true);
                  }}
                >
                  {User.Role}
                  </Button>
                </td>
                <td>{User.CreatedOn}</td>
                <td>
                  <div className="d-flex align-items-center  g-5">
                    <div className={`${styles.RoleEditContainer} me-2`}>
                      <Image className={`${styles.custommessageframerole}`} alt="#" src={RoleEdit} 
                       onClick={() => {
                        setSelectedUserId(User.id);
                        setShowPopupTest(true);
                      }}/>
                    </div>
                    <div className={`${styles.RoledeleteContainer} `}>
                       <span onClick={() => handleRowDeletion(index)}>
                        <Image className={`${styles.custommessageframerole}`} alt="#" src={RoleEDelete} />
                      </span>
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="d-flex justify-content-center">
          <Pagination>
            <Pagination.Prev onClick={() => handlePaginationClick(currentPage - 1)} disabled={currentPage === 1} />
            {Array.from({ length: totalPages }, (_, index) => (
              <Pagination.Item
                key={index + 1}
                active={index + 1 === currentPage}
                onClick={() => handlePaginationClick(index + 1)}
              >
                {index + 1}
              </Pagination.Item>
            ))}
            <Pagination.Next
              onClick={() => handlePaginationClick(currentPage + 1)}
              disabled={currentPage === totalPages}
            />
          </Pagination>
        </div>
      </div>
    </div>
  );
};

export default AddUser;
