import React, { useState, useEffect } from 'react';
import Group from '@/components/usermangement/Groups';
import DevelopmentGroup from '@/components/usermangement/DevelopmentGroup';
import DesignGroup from '@/components/usermangement/DesignGroup';
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

const RenderGroup = () => {
  const [step, setStep] = useState(0);

  const { data: session, status } = useSession();
  const router = useRouter();

useEffect(() => {
  // Check if the session is loaded and the user is authenticated

  if (status === "authenticated" && session?.user?.roles?.includes("User")){
      router.push("/user/dashboard")
    }

}, [session, status]);
//Show a loading indicator while the session is loading
if (status === "loading") {
  return <p>Loading...</p>
}else if (status === "authenticated" && session?.user?.roles?.includes("User")){
  return <p>forbidden...</p>
}

  return (
    <>
        {step === 0 && <Group step={step} stepChange={setStep}/>}
        {step === 1 && <DevelopmentGroup step={step} stepChange={setStep} />}
        {step === 2 && <DesignGroup step={step} stepChange={setStep} />}
    </>
  );
};
export default RenderGroup;