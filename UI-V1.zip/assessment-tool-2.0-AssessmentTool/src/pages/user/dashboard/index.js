/* eslint-disable react/jsx-no-undef */
import React, { useEffect } from "react";
import { Poppins } from 'next/font/google';
import styles from "@/styles/dashboard.module.css";
import UserOverview from '@/components/userdashboard/overview';
import RecentAssessment from '@/components/userdashboard/RecentAssessments';
import Performance from '@/components/userdashboard/perfomance';
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";


const poppins = Poppins({
    weight: '500',
    subsets: ['latin'],
});

const Dashboard = () => {
    const { data: session, status } = useSession();
    const router = useRouter();

    // useEffect(() => {
    //     // Check if the session is loaded and the user is authenticated

    //     if (status === "authenticated" && session?.user?.roles?.includes("Admin")) {
    //         router.push("/admin/dashboard")
    //     }

    // }, [session, status]);
    // //Show a loading indicator while the session is loading
    // if (status === "loading") {
    //     return <p>Loading...</p>
    // } else if (status === "authenticated" && session?.user?.roles?.includes("Admin")) {
    //     return <p>forbidden...</p>
    // }
    return (
        <div className={`container-fluid ${poppins.className}`}>
            <div className='row'>
                <div className='row mt-2'>
                    <div className="col-md-8 mt-4 bg-light">
                        <div className={`card ${styles.card}`}>
                            <div className="card-body">
                                <UserOverview />
                            </div>
                        </div>
                    </div>
                    <div className={`col-md-4 ml-2 mt-4 bg-light ${styles.userAvgPerformace}`}>
                        <div className={`card ${styles.card}`}>
                            <div className="card-body">
                                <Performance />
                            </div>
                        </div>
                    </div>
                </div>
                <div className='row mt-2'>
                    <div className="col-md-12 mt-4 bg-light">
                        <div className={`card ${styles.card}`}>
                            <div className="card-body">
                                <RecentAssessment />
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default Dashboard;