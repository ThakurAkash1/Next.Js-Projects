import React, { useState, useEffect } from 'react';
import NewAssessment from '@/components/userassessment/NewAssessment';
import CreateAssessment from '@/components/userassessment/CreateAssessment';
import AddQuestionAssessment from '@/components/userassessment/AddQuestionAssessment';
import AddQuestions from '@/components/userassessment/AddQuestions';
import AllQuestion from '@/components/userassessment/AllQuestion';
import AssessmentMobileSideBar from '@/components/userassessment/AssessmentMobileSideBar';
import AssessmentResultTable from '@/components/userassessment/AssessmentResultTable';
import CertificateTable from '@/components/userassessment/CertificateTable';
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

const MyAssessment = () => {
  const [step, setStep] = useState(0);

  const { data: session, status } = useSession();
  const router = useRouter();
  const [assessmentholdId, setAssessmentholdId] = useState(null);

  // useEffect(() => {
  //   // Check if the session is loaded and the user is authenticated

  //   if (status === "authenticated" && session?.user?.roles?.includes("Admin")) {
  //     router.push("/admin/dashboard")
  //   }

  // }, [session, status]);
  // //Show a loading indicator while the session is loading
  // if (status === "loading") {
  //   return <p>Loading...</p>
  // } else if (status === "authenticated" && session?.user?.roles?.includes("Admin")) {
  //   return <p>forbidden...</p>
  // }


  return (
    <>
      {step === 0 && <NewAssessment step={step} stepChange={setStep} setAssessmentholdId={setAssessmentholdId}  />}
      {step === 1 && <CreateAssessment step={step} stepChange={setStep} />}
      {step === 2 && <AddQuestionAssessment step={step} stepChange={setStep} />}
      {step === 3 && <AddQuestions step={step} stepChange={setStep} assessmentholdId={assessmentholdId} />}
      {step === 4 && <AllQuestion step={step} stepChange={setStep} assessmentholdId={assessmentholdId}/>}
      {step === 5 && <AssessmentMobileSideBar step={step} stepChange={setStep} />}
      {step === 6 && <AssessmentResultTable step={step} stepChange={setStep} />}
      {step === 7 && <CertificateTable step={step} stepChange={setStep} />}

    </>
  );
};

export default MyAssessment;