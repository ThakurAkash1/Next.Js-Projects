package com.prodevans.assessitapi.model

import lombok.AllArgsConstructor
import lombok.Builder
import lombok.Data
import lombok.NoArgsConstructor
import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Document(collection = "candidate")
data class CandidateAssessment (
    @Id
    var candidateId: String,
    var name : String,
    var id: String
)