package com.prodevans.assessitapi.model

import com.prodevans.assessitapi.model.inputs.QuestionInput
import lombok.AllArgsConstructor
import lombok.Builder
import lombok.Data
import lombok.NoArgsConstructor
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.Id
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.mongodb.core.mapping.DBRef
import org.springframework.data.mongodb.core.mapping.Document
import java.util.*


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Document(collection = "assessments")
data class Assessment(
        @Id
        var id: String?=null,

        var name: String,

        var description: String,

        @DBRef
        var categoryId: Category,

        @CreatedDate
        var createdAt: Date =Date(),

        @LastModifiedDate
        var updatedAt: Date=Date(),

        var createdBy: String,

        var totalScore: Float,

//    var publishedQuestions: List<Question>,

        var draftQuestions: List<Question>,

        var testLanguage: String,

        var thumbnailImg: String,

        var perQuestionDuration: String,

        var duration: String,

        var status: String,
)
