package com.prodevans.assessitapi.utils

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import kotlin.random.Random

class Constants{
    private val characters = ('a'..'z') + ('A'..'Z') + ('0'..'9') + listOf('!', '@', '#', '$', '%',  '&', '*')

    fun generateId(prefix: String, length: Int): String {
        val randomId = (1..length)
            .map { characters.random() }
            .joinToString("")
        return "$prefix-$randomId"
    }
    private val logger: Logger = LoggerFactory.getLogger(Constants::class.java)


    fun logInfo(message: String) {
        logger.info(message)
    }

    fun logError(message: String) {
        logger.error(message)
    }

}
