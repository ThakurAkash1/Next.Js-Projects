package com.prodevans.assessitapi.service

import com.prodevans.assessitapi.model.Location
import com.prodevans.assessitapi.model.input.LocationInput
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.stereotype.Service
import java.util.*


@Service
class LocationService{
    @Qualifier("user")
    @Autowired
    private val locationDbMongoTemplate: MongoTemplate? = null

    fun save(location: Location): Location {
        return locationDbMongoTemplate!!.save(location)
    }
    fun fetchAllLocations(): List<Location> {
        return locationDbMongoTemplate!!.findAll(Location::class.java)
    }

    fun createLocation(input: LocationInput.CreateLocationInput): Location {
        // Generate a unique ID for the new location
//        val newId = UUID.randomUUID().toString()
        // Create a new Location instance with the provided name and generated ID
        val location = Location(name = input.name)
        return save(location)
    }
    fun updateLocation(id: String, name: String): Location {
        val location = locationDbMongoTemplate!!.findById(id, Location::class.java)
            ?: throw IllegalArgumentException("Location not found with ID: $id")

        location.name = name
        return save(location)
    }

    fun deleteLocation(id: String): Boolean {
        val location = locationDbMongoTemplate!!.findById(id, Location::class.java)
            ?: throw IllegalArgumentException("Location not found with ID: $id")

        locationDbMongoTemplate!!.remove(location)
        return true
    }

}