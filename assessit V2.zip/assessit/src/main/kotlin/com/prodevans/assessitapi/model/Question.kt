package com.prodevans.assessitapi.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.DBRef
import java.time.LocalDateTime
import java.util.Date

data class Question(
        var questionId: String,

        @DBRef
        var subcategoryId: SubCategory?,

        var question: String,

        var questionType: String,

        var options: List<Option>,

        var answer: List<String>,

        var multipleChoice: Boolean,

        var totalWeightage: Float,

        var createdAt: Date,

        var updatedAt: LocalDateTime
)