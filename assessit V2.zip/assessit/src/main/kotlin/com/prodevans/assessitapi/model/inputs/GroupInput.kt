package com.prodevans.assessitapi.model.input

import com.prodevans.assessitapi.model.Group


class GroupInput {

    data class CreateGroupInput(
        val groupName: String,
        val groupMember: List<Group.GroupMember>,
        val createdBy: String
    )

    data class UpdateGroupInput(
        val groupId: String,
        val groupName: String,
        val groupMember: List<Group.GroupMember>
    )

    data class DeleteGroupInput(
        val groupId: String
    )
}