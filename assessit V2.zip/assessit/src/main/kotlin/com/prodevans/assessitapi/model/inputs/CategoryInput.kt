package com.prodevans.assessitapi.model.inputs

data class CategoryInput(
    val name :String,
    val createdBy : String
) {
}