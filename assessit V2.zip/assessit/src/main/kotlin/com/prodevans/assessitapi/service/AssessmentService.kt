


package com.prodevans.assessitapi.service

import com.prodevans.assessitapi.model.*
import com.prodevans.assessitapi.model.inputs.AssessmentInput
import com.prodevans.assessitapi.model.inputs.OptionInput
import com.prodevans.assessitapi.model.inputs.QuestionInput
import com.prodevans.assessitapi.utils.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.data.mongodb.core.query.Criteria
import org.springframework.data.mongodb.core.query.Query
import org.springframework.stereotype.Service
import java.time.LocalDateTime
import java.util.*
import kotlin.random.Random



@Service
class AssessmentService {
    @Qualifier("assessment")
    @Autowired
    private val assessmentDbMongoTemplate: MongoTemplate? = null

    val constants = Constants()
    fun findAll(): List<Assessment> {
        return assessmentDbMongoTemplate!!.findAll(Assessment::class.java)
    }

    fun findById(id: String): Assessment? {
        return assessmentDbMongoTemplate!!.findById(id, Assessment::class.java)
    }

    fun createAssessment(assessmentInput: AssessmentInput): Assessment {
//        val publishedQuestions: List<Question> = mapQuestions(assessmentInput.publishedQuestions)
        val draftQuestions: List<Question> = mapQuestions(assessmentInput.draftQuestions)

        val category = getCategoryById(assessmentInput.categoryId)

        val assessment = Assessment(
            name = assessmentInput.name,
            description = assessmentInput.description,
            categoryId = category,
            createdBy = assessmentInput.createdBy,
            totalScore = assessmentInput.totalScore,
            testLanguage = assessmentInput.testLanguage,
            thumbnailImg = assessmentInput.thumbnailImg,
            perQuestionDuration = assessmentInput.perQuestionDuration,
            duration = assessmentInput.duration,
            status = assessmentInput.status,
//            publishedQuestions = publishedQuestions,
            draftQuestions = draftQuestions
        )

        return assessmentDbMongoTemplate!!.save(assessment)
    }
    private fun getCategoryById(categoryId: String): Category {
        val category = assessmentDbMongoTemplate!!.findById(categoryId, Category::class.java)
        return category ?: throw IllegalArgumentException("Category not found with ID: $categoryId")
    }
    private fun getSubCategoryById(subcategoryId: String): SubCategory {
        if (subcategoryId.isBlank()) {
            throw IllegalArgumentException("SubCategory ID cannot be null or empty")
        }

        val subCategory = assessmentDbMongoTemplate!!.findById(subcategoryId, SubCategory::class.java)
        return subCategory ?: throw IllegalArgumentException("SubCategory not found with ID: $subcategoryId")
    }

    private fun mapQuestions(questionInputs: List<QuestionInput>): List<Question> {
        val currentDateTime = LocalDateTime.now()
        val subCategoryId = questionInputs.firstOrNull()?.subcategoryId ?: throw IllegalArgumentException("SubCategory ID is missing")
        val subCategory = getSubCategoryById(subCategoryId)

        return questionInputs.map { questionInput ->
            Question(
                questionId = constants.generateId("AQT", 6),
                subcategoryId = subCategory,
                question = questionInput.question,
                questionType = questionInput.questionType,
                answer = questionInput.answer,
                multipleChoice = questionInput.multipleChoice,
                totalWeightage = questionInput.totalWeightage,
                options = mapOptions(questionInput.options),
                updatedAt = currentDateTime,
                createdAt = Date()
            )
        }
    }
    private fun mapOptions(options: List<OptionInput>): List<Option> {
        return options.map { optionInput ->
            Option(
                option = optionInput.option,
                weightage = optionInput.weightage
            )
        }
    }
//start for update


    fun updateAssessment(id: String, assessmentInput: AssessmentInput): Assessment? {
        val category = assessmentDbMongoTemplate?.findById(assessmentInput.categoryId, Category::class.java)
            ?: throw IllegalArgumentException("Category not found with ID: ${assessmentInput.categoryId}")

        val existingAssessment = assessmentDbMongoTemplate.findById(id, Assessment::class.java)
        if (existingAssessment != null) {
            val currentDateTime = Date()

            // Update Assessment fields
            val updatedAssessment = existingAssessment.apply {
                name = assessmentInput.name
                description = assessmentInput.description
                categoryId = category
                createdBy = assessmentInput.createdBy
                totalScore = assessmentInput.totalScore
                testLanguage = assessmentInput.testLanguage
                thumbnailImg = assessmentInput.thumbnailImg
                perQuestionDuration = assessmentInput.perQuestionDuration
                duration = assessmentInput.duration
                status = assessmentInput.status
                updatedAt = currentDateTime
            }

            val updatedQuestions = mapQuestionsUpdate(existingAssessment.draftQuestions, assessmentInput.draftQuestions, currentDateTime, assessmentInput.subCategoryId)
            updatedAssessment.draftQuestions = updatedQuestions

            constants.logInfo("Updated the assessment with assessment_id: $id and assessment_name: ${updatedAssessment.name}")

            assessmentDbMongoTemplate.save(updatedAssessment)
            return updatedAssessment
        } else {
            // Handle case where assessment with given ID is not found
            return null
        }
    }
    private fun mapQuestionsUpdate(
        existingQuestions: List<Question>,
        questionInputs: List<QuestionInput>,
        assessmentUpdatedAt: Date,
        subcategoryId: String,

        ): List<Question> {
        val updatedQuestions = mutableListOf<Question>()

        val subCategoryQuery = Query().addCriteria(Criteria.where("_id").`is`(subcategoryId))
        val subCategory = assessmentDbMongoTemplate!!.findOne(subCategoryQuery, SubCategory::class.java)
            ?: throw IllegalArgumentException("SubCategory not found with ID: $subcategoryId")

        val updatedQuestionIds = mutableSetOf<String>()

        for (input in questionInputs) {
            val existingQuestion = existingQuestions.find { it.questionId == input.questionId }

            if (existingQuestion != null) {
                // Remove all occurrences of the previous question with the same ID
                updatedQuestions.removeAll { it.questionId == input.questionId }

                // Add updated question
                val updatedQuestion = Question(
                    questionId = input.questionId, // Use input ID for updated question
                    subcategoryId = subCategory,
                    question = input.question,
                    questionType = input.questionType,
                    answer = input.answer,
                    multipleChoice = input.multipleChoice,
                    totalWeightage = input.totalWeightage,
                    options = mapOptionsUpdate(input.options),
                    createdAt = assessmentUpdatedAt,
                    updatedAt = LocalDateTime.now()
                )
                updatedQuestions.add(updatedQuestion)
                updatedQuestionIds.add(updatedQuestion.questionId) // Mark as updated
            } else {
                // Add new question
                val newQuestion = Question(
                    questionId = constants.generateId("AQ",6) ,// Use input ID for new question
                    subcategoryId = subCategory,
                    question = input.question,
                    questionType = input.questionType,
                    answer = input.answer,
                    multipleChoice = input.multipleChoice,
                    totalWeightage = input.totalWeightage,
                    options = mapOptionsUpdate(input.options),
                    createdAt = assessmentUpdatedAt,
                    updatedAt = LocalDateTime.now()
                )
                updatedQuestions.add(newQuestion)
                updatedQuestionIds.add(newQuestion.questionId) // Mark as updated
            }
        }

        return updatedQuestions
    }

    private fun existingQuestionHasChanged(existingQuestion: Question, input: QuestionInput): Boolean {
        val existingOptions = existingQuestion.options.map { it.option }
        val inputOptions = input.options.map { it.option }
        return existingQuestion.subcategoryId?.id != input.subcategoryId ||
                existingQuestion.question != input.question ||
                existingQuestion.questionType != input.questionType ||
                existingQuestion.answer != input.answer ||
                existingQuestion.multipleChoice != input.multipleChoice ||
                existingQuestion.totalWeightage != input.totalWeightage ||
                existingOptions != inputOptions
    }

    private fun mapOptionsUpdate(options: List<OptionInput>): List<Option> {
        return options.map { optionInput ->
            Option(
                option = optionInput.option,
                weightage = optionInput.weightage
            )
        }
    }



//update end

    fun deleteAssessmentById(id: String): Boolean {
        val query = Query(Criteria.where("_id").`is`(id))
        val assessment = assessmentDbMongoTemplate?.findOne(query, Assessment::class.java)

        if (assessment != null) {
            assessmentDbMongoTemplate?.remove(query, Assessment::class.java)
//            Constants.logInfo("Deleted the assessment with assessment_Id: $id")
            return true
        } else {
//            Constants.logError("Failed to delete assessment with id: $id. Assessment not found.")
            throw RuntimeException("Assessment with given id does not exist")
        }
    }


    fun questionByAssessmentAndId(assessmentId: String?, questionId: String?): Question? {
        if (assessmentId == null || questionId == null) {
            // Handle null parameters
            return null
        }

        // Query to find the assessment by ID
        val assessmentQuery = Query.query(Criteria.where("_id").`is`(assessmentId))
        val assessment = assessmentDbMongoTemplate!!.findOne(assessmentQuery, Assessment::class.java)

        return assessment?.let { assessment ->
            // Search for the question within published and draft questions lists
            val question = assessment.draftQuestions.find { it.questionId == questionId }
                ?: assessment.draftQuestions.find { it.questionId == questionId }
            question
        }
    }

}



