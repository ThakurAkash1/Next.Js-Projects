package com.prodevans.assessitapi.service

import com.prodevans.assessitapi.model.Group
import com.prodevans.assessitapi.model.input.GroupInput
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.stereotype.Service
import java.util.*

@Service
class GroupService
{

    @Qualifier("user")
    @Autowired
    val groupDbMongoTemplate: MongoTemplate? = null

    fun save(group: Group): Group {
        return groupDbMongoTemplate!!.save(group)
    }



    fun findAll(): List<Group> {
        return groupDbMongoTemplate!!.findAll(Group::class.java)
    }


    fun findById(id: String): Group? {
        return groupDbMongoTemplate!!.findById(id, Group::class.java)
    }

    fun createGroup(input: GroupInput.CreateGroupInput): Group {
        val group = Group(
            groupName = input.groupName,
            groupMember = input.groupMember.map { memberInput ->
                Group.GroupMember(memberInput.candidateId, memberInput.candidateName)
            },
            createdBy = input.createdBy
        )
        return save(group)
    }

    fun updateGroup(input: GroupInput.UpdateGroupInput): Group {
        val group = groupDbMongoTemplate?.findById(input.groupId, Group::class.java)
            ?: throw IllegalArgumentException("Group not found with ID: ${input.groupId}")

        group.apply {
            groupName = input.groupName
            groupMember = input.groupMember.map { memberInput ->
                Group.GroupMember(memberInput.candidateId, memberInput.candidateName)
            }
            updatedAt = Date()
        }

        return save(group)
    }

    fun deleteGroup(input: GroupInput.DeleteGroupInput): Boolean {
        val group = groupDbMongoTemplate?.findById(input.groupId, Group::class.java)
            ?: throw IllegalArgumentException("Group not found with ID: ${input.groupId}")

        groupDbMongoTemplate?.remove(group)
        return true
    }
}