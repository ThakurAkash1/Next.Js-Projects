package com.prodevans.assessitapi.model

import org.springframework.data.annotation.Id
import org.springframework.data.annotation.Transient
import org.springframework.data.mongodb.core.mapping.Document
import java.util.Date

@Document(collection = "admin_info")
data class AdminInfo(

    @Id
    var id : String? = null,
    var name:String,
    var email:String,
    var location: String,
    var phoneNumber: String,
    val role:String,
    val isActive:Boolean,
    var createdAt:Date = Date(),
    var updatedAt:Date = Date(),

    val deptId: String,

    ){
    @Transient
    var userGroup: List<Group> = ArrayList()
}