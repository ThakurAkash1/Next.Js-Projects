package com.prodevans.assessitapi.controller

import com.prodevans.assessitapi.model.SubCategory
import com.prodevans.assessitapi.model.inputs.SubCategoryInput

import com.prodevans.assessitapi.service.SubCategoryService
import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.graphql.data.method.annotation.MutationMapping
import org.springframework.graphql.data.method.annotation.QueryMapping
import org.springframework.stereotype.Controller



@Controller
class SubCategoryController (val subCategoryService: SubCategoryService){

    @QueryMapping
    fun subCategory():List<SubCategory>{
        return  subCategoryService.findAll()
    }

    @QueryMapping
    fun subCategoryById(@Argument id: String): SubCategory?{
        return subCategoryService.findById(id)
    }
    @MutationMapping
    fun createSubCategory(@Argument subCategoryInput: SubCategoryInput): SubCategory? {
        return subCategoryService.createSubCategory(subCategoryInput)
    }

    @MutationMapping
    fun updateSubCategory(@Argument id: String, @Argument subCategoryInput: SubCategoryInput): SubCategory? {
        return subCategoryService.updateSubCategory(id, subCategoryInput)
    }

    @MutationMapping
    fun deleteSubCategory(@Argument("id") id: String): Boolean {
        return subCategoryService.deleteSubCategory(id)
    }
}