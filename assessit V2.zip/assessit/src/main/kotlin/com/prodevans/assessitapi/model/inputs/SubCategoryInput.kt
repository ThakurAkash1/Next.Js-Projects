package com.prodevans.assessitapi.model.inputs;



data class SubCategoryInput (
    val name: String,
    val createdBy: String,
    val categoryId: String
)