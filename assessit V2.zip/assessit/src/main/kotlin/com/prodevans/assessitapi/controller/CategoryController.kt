package com.prodevans.assessitapi.controller

import com.prodevans.assessitapi.model.Category
import com.prodevans.assessitapi.model.inputs.CategoryInput
import com.prodevans.assessitapi.service.CategoryService
import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.graphql.data.method.annotation.MutationMapping
import org.springframework.graphql.data.method.annotation.QueryMapping
import org.springframework.stereotype.Controller



@Controller
class CategoryController(val categoryService: CategoryService){

    @QueryMapping
    fun categories(): List<Category> {
        return categoryService.getAllCategory()
    }

    @QueryMapping
    fun categoryById(@Argument id: String): Category? {
        return categoryService.findById(id)
    }

    @MutationMapping
    fun createCategory(@Argument categoryInput: CategoryInput): Category {
        return categoryService.createCategory(categoryInput)
    }

    @MutationMapping
    fun deleteCategory(@Argument id: String):Boolean{
        return categoryService.deleteCategory(id)
    }

    @MutationMapping
    fun updateCategory(@Argument id: String,@Argument categoryInput: CategoryInput): Category {
        return categoryService.updateCategory(id, categoryInput)
    }
}