package com.prodevans.assessitapi.model.input

class LocationInput {

    data class CreateLocationInput(val name: String)
    data class UpdateLocationInput(val id: String ,
                                   val name: String)
    data class DeleteLocationInput(val id: String)
}