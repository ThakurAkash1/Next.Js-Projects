package com.prodevans.assessitapi.model.inputs




data class AssessmentInput(
        val name: String,
        val description: String,
//    val createdAt: Date,
        val categoryId: String,
//    val updateAt: Date,
        val createdBy: String,
        val totalScore: Float,
        val testLanguage: String,
        val thumbnailImg: String,
        val perQuestionDuration: String,
        val duration: String,
        val status: String,
//    val publishedQuestions: List<QuestionInput>,
        val draftQuestions: List<QuestionInput>,
        val subCategoryId : String

)