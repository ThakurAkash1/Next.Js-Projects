package com.prodevans.assessitapi.service



import com.prodevans.assessitapi.model.Department
import com.prodevans.assessitapi.model.input.DepartmentInput
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.stereotype.Service
import java.util.*

@Service
class DepartmentService
{

    @Qualifier("user")
    @Autowired
    val departmentDbMongoTemplate: MongoTemplate? = null

    // Method to save department to the database
    fun save(department: Department): Department {
        return departmentDbMongoTemplate!!.save(department)
    }

    fun findAll(): List<Department> {
        return departmentDbMongoTemplate!!.findAll(Department::class.java)
    }

    fun findById(id: String): Department? {
        return departmentDbMongoTemplate!!.findById(id, Department::class.java)
    }

    fun createDepartment(input: DepartmentInput.CreateDepartmentInput): Department {
//        val newId = UUID.randomUUID().toString()
        // Create a new department instance with the provided name and generated ID
        val department = Department(name = input.name)
        return save(department)
    }

    fun updateDepartment(id: String, name: String): Department {
        val department = departmentDbMongoTemplate!!.findById(id, Department::class.java)
            ?: throw IllegalArgumentException("Department not found with ID: $id")

        department.name = name
        return save(department)
    }

    fun deleteDepartment(id: String): Boolean {
        val department = departmentDbMongoTemplate!!.findById(id, Department::class.java)
            ?: throw IllegalArgumentException("Department not found with ID: $id")

        departmentDbMongoTemplate!!.remove(department)
        return true
    }

//    // Method to save department to the database
//    private fun save(department: Department): Department {
//        return departmentDbMongoTemplate!!.save(department)
//    }



}