package com.prodevans.assessitapi.controller

import com.prodevans.assessitapi.model.*
import com.prodevans.assessitapi.model.input.*
import com.prodevans.assessitapi.service.*
import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.graphql.data.method.annotation.MutationMapping
import org.springframework.graphql.data.method.annotation.QueryMapping
import org.springframework.stereotype.Controller

@Controller
class UserController(
    private val departmentService: DepartmentService,
    private val locationService: LocationService,
    private val adminInfoService: AdminInfoService,
    private val candidateInfoService: CandidateInfoService,
    private val groupService: GroupService
) {

    // DepartmentController methods
    @QueryMapping
    fun department(): List<Department> = departmentService.findAll()

    @QueryMapping
    fun getDepartmentById(@Argument id: String): Department? = departmentService.findById(id)

    @MutationMapping
    fun createDepartment(@Argument input: DepartmentInput.CreateDepartmentInput): Department =
        departmentService.createDepartment(input)

    @MutationMapping
    fun updateDepartment(@Argument input: DepartmentInput.UpdateDepartmentInput): Department =
        departmentService.updateDepartment(input.id, input.name)

    @MutationMapping
    fun deleteDepartment(@Argument input: DepartmentInput.DeleteDepartmentInput): Boolean =
        departmentService.deleteDepartment(input.id)






    // LocationController methods
    @QueryMapping
        fun location(): List<Location> = locationService.fetchAllLocations()

    @MutationMapping
    fun createLocation(@Argument input: LocationInput.CreateLocationInput): Location =
        locationService.createLocation(input)

    @MutationMapping
    fun updateLocation(@Argument input: LocationInput.UpdateLocationInput): Location =
        locationService.updateLocation(input.id, input.name)

    @MutationMapping
    fun deleteLocation(@Argument input: LocationInput.DeleteLocationInput): Boolean =
        locationService.deleteLocation(input.id)



    //AdminController methods
    @QueryMapping
    fun admin_info(): List<AdminInfo> = adminInfoService.findAll()

    @QueryMapping
    fun getAdminById(@Argument id: String): AdminInfo? = adminInfoService.findById(id)

    @MutationMapping
    fun createAdminInfo(@Argument input: AdminInfoInput.CreateAdminInfoInput): AdminInfo {
        return adminInfoService.createAdminInfo(input)
    }

    @MutationMapping
    fun updateAdminInfo(@Argument input: AdminInfoInput.UpdateAdminInfoInput): AdminInfo {
        return adminInfoService.updateAdminInfo(input)
    }

    @MutationMapping
    fun deleteAdminInfo(@Argument input: AdminInfoInput.DeleteAdminInfoInput): Boolean {
        return adminInfoService.deleteAdminInfo(input)
    }





    //CandidateInfoController methods
    @QueryMapping
    fun candidate_info(): List<CandidateInfo> = candidateInfoService.findAll()

    @QueryMapping
    fun getCandidateInfoById(@Argument id: String): CandidateInfo? = candidateInfoService.findById(id)

    @MutationMapping
    fun createCandidateInfo(@Argument input: CandidateInfoInput.CreateCandidateInfoInput): CandidateInfo {
        return candidateInfoService.createCandidateInfo(input)
    }

    @MutationMapping
    fun updateCandidateInfo(@Argument input: CandidateInfoInput.UpdateCandidateInfoInput): CandidateInfo {
        return candidateInfoService.updateCandidateInfo(input)
    }

    @MutationMapping
    fun deleteCandidateInfo(@Argument input: CandidateInfoInput.DeleteCandidateInfoInput): Boolean {
        return candidateInfoService.deleteCandidateInfo(input)
    }




    //GroupController methods
    @QueryMapping
    fun groups(): List<Group> = groupService.findAll()

    @QueryMapping
    fun getGroupById(@Argument id: String): Group? = groupService.findById(id)

    @MutationMapping
    fun createGroup(@Argument input: GroupInput.CreateGroupInput): Group {
        return groupService.createGroup(input)
    }

    @MutationMapping
    fun updateGroup(@Argument input: GroupInput.UpdateGroupInput): Group {
        return groupService.updateGroup(input)
    }

    @MutationMapping
    fun deleteGroup(@Argument input: GroupInput.DeleteGroupInput): Boolean {
        return groupService.deleteGroup(input)
    }


}