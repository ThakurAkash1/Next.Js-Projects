package com.prodevans.assessitapi.model

import org.springframework.data.annotation.CreatedBy
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.Id
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.mongodb.core.mapping.Document
import java.util.*


@Document(collection = "category")
data class Category (
    @Id
    var id: String? = null,
    var name : String,

    @CreatedDate
    val createdAt : Date=Date(),

    var createdBy:  String,
    @LastModifiedDate
    var updatedAt : Date= Date(),
)