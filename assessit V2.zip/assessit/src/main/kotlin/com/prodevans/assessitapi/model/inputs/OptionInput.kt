package com.prodevans.assessitapi.model.inputs

data class OptionInput(
        val option: String,
        val weightage: Float
)