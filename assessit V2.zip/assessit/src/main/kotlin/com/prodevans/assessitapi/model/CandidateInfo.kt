package com.prodevans.assessitapi.model

import org.springframework.data.annotation.Id
import org.springframework.data.annotation.Transient
import org.springframework.data.mongodb.core.mapping.Document
import java.util.*

@Document(collection = "candidate_info")
data class CandidateInfo(

    @Id
    var id : String? = null,
    var name:String,
    var email:String,
    var address:String,
    var phoneNumber:String,
    val isActive:Boolean,
    var createdAt: Date = Date(),
    var updatedAt: Date = Date(),


    )