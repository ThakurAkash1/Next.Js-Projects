package com.prodevans.assessitapi.service

import com.prodevans.assessitapi.model.Assessment
import com.prodevans.assessitapi.model.Category
import com.prodevans.assessitapi.model.SubCategory
import com.prodevans.assessitapi.model.inputs.CategoryInput
import com.prodevans.assessitapi.utils.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.data.mongodb.core.query.Criteria
import org.springframework.data.mongodb.core.query.Query
import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.stereotype.Service
import org.yaml.snakeyaml.tokens.Token
import java.util.*

@Service
class CategoryService(val categoryMongoTemplate: MongoTemplate) {
    val constants = Constants()

    fun getAllCategory(): List<Category> {
        constants.logInfo("Getting All Category")
        return categoryMongoTemplate.findAll(Category::class.java)
    }

    fun findById(id: String): Category? {
        return categoryMongoTemplate.findById(id, Category::class.java)
    }

    fun createCategory(categoryInput: CategoryInput): Category {
        val category = Category(
            id = UUID.randomUUID().toString(),
            name = categoryInput.name,
            createdBy = categoryInput.createdBy,
            createdAt = Date(),
            updatedAt = Date()
        )
        categoryMongoTemplate.save(category)
        return category
    }


    fun deleteCategory(id: String): Boolean {
        val category = categoryMongoTemplate.findById(id, Category::class.java)

        if (category != null) {
            val assessmentsWithCategory = categoryMongoTemplate.find(
                Query.query(Criteria.where("categoryId").`is`(id)),
                Assessment::class.java
            )
            if (assessmentsWithCategory.isNotEmpty()) {
                constants.logInfo("Cannot delete category because it is used in assessments.")
                return false
            } else {
                categoryMongoTemplate.remove(category)
                constants.logInfo("Category deleted successfully.")
                return true
            }
        } else {
            throw RuntimeException("Category with given id does not exist")
        }
    }

    fun updateCategory(id: String, categoryInput: CategoryInput): Category {
        val existingCategory = categoryMongoTemplate.findById(id, Category::class.java)
            ?: throw RuntimeException("Category with given id does not exist")

        val currentDateTime = Date()

        existingCategory.apply {
            name = categoryInput.name
            createdBy = categoryInput.createdBy
            // Add more properties to update as necessary
            updatedAt = currentDateTime
        }

        categoryMongoTemplate.save(existingCategory)
        return existingCategory
    }

}