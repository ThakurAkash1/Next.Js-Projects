package com.prodevans.assessitapi.service

import com.prodevans.assessitapi.model.CandidateAssessment
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.stereotype.Service

@Service
class CandidateAssessmentService
{



    @Qualifier("candidate")
    @Autowired
    val candidateDbMongoTemplate: MongoTemplate? = null
    fun save(candidateAssessment: CandidateAssessment): CandidateAssessment {
        return candidateDbMongoTemplate!!.save(candidateAssessment)
    }



    fun findAll(): List<CandidateAssessment> {
        return candidateDbMongoTemplate!!.findAll(CandidateAssessment::class.java)
    }

    fun findById(candidateId: String): CandidateAssessment? {
        return candidateDbMongoTemplate!!.findById(candidateId, CandidateAssessment::class.java)
    }

}
