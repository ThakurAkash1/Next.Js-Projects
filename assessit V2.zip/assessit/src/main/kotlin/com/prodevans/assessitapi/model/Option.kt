package com.prodevans.assessitapi.model

data class Option(

    var option: String,

    var weightage: Float

)