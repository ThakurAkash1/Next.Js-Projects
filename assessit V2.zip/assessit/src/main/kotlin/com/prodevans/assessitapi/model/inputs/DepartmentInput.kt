package com.prodevans.assessitapi.model.input


class DepartmentInput{
    data class CreateDepartmentInput(val name: String)
    data class UpdateDepartmentInput(val id: String ,
                                     val name: String)
    data class DeleteDepartmentInput(val id: String)
}