package com.prodevans.assessitapi.controller

import com.prodevans.assessitapi.model.Assessment
import com.prodevans.assessitapi.model.Question
import com.prodevans.assessitapi.model.inputs.AssessmentInput
import com.prodevans.assessitapi.service.AssessmentService
import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.graphql.data.method.annotation.MutationMapping
//import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.graphql.data.method.annotation.QueryMapping

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.DeleteMapping



@Controller
class AssessmentController(val assessmentService: AssessmentService) {

//    @PreAuthorize("hasRole('SCOPE_openid')")


    @QueryMapping
    fun assessments(): List<Assessment> {
//        val authentication = SecurityContextHolder.getContext().authentication
//
//        if (authentication != null && authentication.isAuthenticated) {
//            println("User roles:")
//            authentication.authorities.forEach { authority ->
//                println(authority.authority)
//            }
//        } else {
//            println("User is not authenticated.")
//        }
        return assessmentService.findAll()
    }

    @QueryMapping
    fun assessmentById(@Argument id: String): Assessment? {
        return assessmentService.findById(id)
    }

    @MutationMapping
    fun addAssessment(@Argument assessmentInput: AssessmentInput): Assessment {
        return assessmentService.createAssessment(assessmentInput)
    }
    @MutationMapping
    fun updateAssessmentDetails(@Argument("id") id: String, @Argument("assessmentInput") assessmentInput: AssessmentInput): Assessment {
        return assessmentService.updateAssessment(id, assessmentInput)
//            .orElseThrow { RuntimeException("Assessment with given id does not exist") }
            ?: throw RuntimeException("Assessment with given id does not exist")
    }


    @MutationMapping
    fun deleteAssessment(@Argument("id") id: String): Boolean {
        return assessmentService.deleteAssessmentById(id)

    }


    @QueryMapping
    fun questionByAssessmentId(@Argument assessmentId: String,@Argument questionId: String): Question? {
        return assessmentService.questionByAssessmentAndId(assessmentId, questionId)
    }

}

