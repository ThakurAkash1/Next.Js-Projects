package com.prodevans.assessitapi.model.inputs



data class QuestionInput(
        val questionId: String,
        val subcategoryId: String,
        val question: String,
        val questionType: String,
        val answer: List<String>,
        val multipleChoice: Boolean,
        val totalWeightage: Float,
        val options: List<OptionInput> =ArrayList()
)
