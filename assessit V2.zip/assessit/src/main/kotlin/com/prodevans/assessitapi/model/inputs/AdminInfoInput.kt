package com.prodevans.assessitapi.model.input

class AdminInfoInput {

    data class CreateAdminInfoInput(
//        val name: String,
//        val email: String,
        val location: String,
        val phoneNumber: String
    )
    data class UpdateAdminInfoInput(
        val id: String ,
        val name: String,
        val email:String,
        val location:String,
        val phoneNumber:String,
//        val role:String
    )
    data class DeleteAdminInfoInput(
        val id: String
    )
}