package com.prodevans.assessitapi.service

import com.prodevans.assessitapi.model.CandidateInfo
import com.prodevans.assessitapi.model.input.CandidateInfoInput
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.stereotype.Service
import java.time.LocalDateTime
import java.util.*

@Service
class CandidateInfoService
{



    @Qualifier("user")
    @Autowired
    val candidateInfoDbMongoTemplate: MongoTemplate? = null
    fun save(candidateInfo: CandidateInfo): CandidateInfo {
        return candidateInfoDbMongoTemplate!!.save(candidateInfo)
    }

    fun findAll(): List<CandidateInfo> {
        return candidateInfoDbMongoTemplate!!.findAll(CandidateInfo::class.java)
    }

    fun findById(id: String): CandidateInfo? {
        return candidateInfoDbMongoTemplate!!.findById(id, CandidateInfo::class.java)
    }

    fun createCandidateInfo(input: CandidateInfoInput.CreateCandidateInfoInput): CandidateInfo {
        val candidateInfo = CandidateInfo(
            name = input.name,
            email = input.email,
            address = input.address,
            phoneNumber = input.phoneNumber,
            isActive = true, // Set default value if needed
//            createdAt = LocalDateTime.now().toString(),
//            updatedAt = LocalDateTime.now().toString()
        )
        return save(candidateInfo)
    }

    fun updateCandidateInfo(input: CandidateInfoInput.UpdateCandidateInfoInput): CandidateInfo {
        val candidateInfo = candidateInfoDbMongoTemplate?.findById(input.id, CandidateInfo::class.java)
            ?: throw IllegalArgumentException("CandidateInfo not found with ID: ${input.id}")

        input.name?.let { candidateInfo.name = it }
        input.email?.let { candidateInfo.email = it }
        input.address?.let { candidateInfo.address = it }
        input.phoneNumber?.let { candidateInfo.phoneNumber = it }
        candidateInfo.updatedAt = Date()

        return save(candidateInfo)
    }

    fun deleteCandidateInfo(input: CandidateInfoInput.DeleteCandidateInfoInput): Boolean {
        val candidateInfo = candidateInfoDbMongoTemplate?.findById(input.id, CandidateInfo::class.java)
            ?: throw IllegalArgumentException("CandidateInfo not found with ID: ${input.id}")

        candidateInfoDbMongoTemplate?.remove(candidateInfo)
        return true
    }


}