package com.prodevans.assessitapi.config


import com.mongodb.ConnectionString
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.core.env.Environment
import org.springframework.data.mongodb.core.MongoTemplate
import com.mongodb.client.MongoClients
import org.springframework.context.annotation.Primary

@Configuration
open class MongoDbConfig {
    @Autowired
    private lateinit var env: Environment

    @Primary
    @Bean(name = ["assessment"])
    open fun assessmentDbMongoTemplate(): MongoTemplate {
        val uri = env!!.getProperty("mongo.assessment.uri")
        val database = env!!.getProperty("mongo.assessment.database")
        if (uri == null || database == null) {
            throw IllegalArgumentException("MongoDB URI or database name is null")
        }

        val connectionString = ConnectionString(uri)
        val mongoClient = MongoClients.create(connectionString)
        return MongoTemplate(mongoClient, database)

    }

    @Bean(name = ["candidate"])
    open fun candidateAssessmentDbMongoTemplate(): MongoTemplate {
        val uri = env!!.getProperty("mongo.candidate-assessment.uri")
        val database = env!!.getProperty("mongo.candidate-assessment.database")
        if (uri == null || database == null) {
            throw IllegalArgumentException("MongoDB URI or database name is null")
        }
        val connectionString = ConnectionString(uri)
        val mongoClient = MongoClients.create(connectionString)
        return MongoTemplate(mongoClient, database)
    }

    @Bean(name = ["user"])
    open fun userDbMongoTemplate(): MongoTemplate {
        val uri = env!!.getProperty("mongo.user.uri")
        val database = env!!.getProperty("mongo.user.database")
        if (uri == null || database == null) {
            throw IllegalArgumentException("MongoDB URI or database name is null")
        }
        val connectionString = ConnectionString(uri)
        val mongoClient = MongoClients.create(connectionString)
        return MongoTemplate(mongoClient, database)
    }
}
