package com.prodevans.assessitapi.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import org.springframework.data.annotation.Transient

@Document(collection = "department")
data class Department(

    @Id
    var id : String? = null,

    var name : String
){

    @Transient
    var adminInfo: List<AdminInfo> = ArrayList() // Initializing  it with an empty list?
}

