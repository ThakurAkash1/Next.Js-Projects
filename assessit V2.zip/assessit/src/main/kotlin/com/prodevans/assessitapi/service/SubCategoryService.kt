package com.prodevans.assessitapi.service

import com.prodevans.assessitapi.model.Assessment
import com.prodevans.assessitapi.model.SubCategory
import com.prodevans.assessitapi.model.inputs.SubCategoryInput
import com.prodevans.assessitapi.utils.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.data.mongodb.core.query.Criteria
import org.springframework.data.mongodb.core.query.Query
import org.springframework.stereotype.Service
import java.time.LocalDateTime
import java.util.*


@Service
class SubCategoryService {

    @Qualifier("assessment")
    @Autowired
    private val subCategoryDbMongoTemplate: MongoTemplate? = null
    val constants = Constants()

    fun findAll(): List<SubCategory> {
        return subCategoryDbMongoTemplate!!.findAll(SubCategory::class.java)
    }

    fun findById(id: String): SubCategory? {
        return subCategoryDbMongoTemplate!!.findById(id, SubCategory::class.java)
    }


    fun createSubCategory(subCategoryInput: SubCategoryInput): SubCategory? {
        // Check if a subcategory with the same name already exists within the specified category
        val existingSubCategory = subCategoryDbMongoTemplate!!.findOne(
            Query(Criteria.where("name").`is`(subCategoryInput.name).and("categoryId").`is`(subCategoryInput.categoryId)),
            SubCategory::class.java
        )

        // If a subcategory with the same name already exists within the specified category, handle the duplication
        if (existingSubCategory != null) {

            throw IllegalArgumentException("Subcategory with the same name already exists within the category.")
        }

        // If no duplicate subcategory found, create and save the new subcategory
        val createdAt = LocalDateTime.now().toString()
        val subCategory = SubCategory(
            name = subCategoryInput.name,
            createdBy = subCategoryInput.createdBy,
            categoryId = subCategoryInput.categoryId
        )
        subCategoryDbMongoTemplate.save(subCategory)
        return subCategory
    }




    fun updateSubCategory(id: String, subCategoryInput: SubCategoryInput): SubCategory? {
        // Find the existing subcategory by its ID
        val existingSubCategory = findById(id)

        // If the subcategory exists, update its fields
        existingSubCategory?.apply {
            name = subCategoryInput.name
            createdBy = subCategoryInput.createdBy
            categoryId = subCategoryInput.categoryId
            updatedAt = Date() // Set updatedAt to the current date and time
        }
        // Save the updated subcategory if it exists
        return existingSubCategory?.let { subCategoryDbMongoTemplate?.save(it) }
    }



    fun deleteSubCategory(id: String): Boolean {
        val query = Query(Criteria.where("_id").`is`(id))
        val result = subCategoryDbMongoTemplate!!.remove(query, SubCategory::class.java)
        return result.deletedCount > 0
    }

}
