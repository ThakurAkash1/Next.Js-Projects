package com.prodevans.assessitapi.model

import lombok.AllArgsConstructor
import lombok.Builder
import lombok.Data
import lombok.NoArgsConstructor
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.Id
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.mongodb.core.mapping.Document
import java.util.Date

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Document(collection = "sub_category")
data class SubCategory (
    @Id
    var id: String?=null,
    var name : String?=null,

    @CreatedDate
    var createdAt : Date=Date(),
    var createdBy:  String?=null,

    @LastModifiedDate
    var updatedAt : Date=Date(),
    var categoryId: String?=null
)