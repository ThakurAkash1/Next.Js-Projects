package com.prodevans.assessitapi.model

import org.springframework.data.annotation.Id
import org.springframework.data.annotation.Transient
import org.springframework.data.mongodb.core.mapping.Document
import java.util.*
import kotlin.collections.ArrayList

@Document(collection = "groups")
data class Group(

    @Id
    var groupId:String? = null,
    var groupName:String,
    var groupMember: List<GroupMember>,
    val createdBy:String,
    val createdAt: Date = Date(),
    var updatedAt:Date = Date(),
){
    data class GroupMember(
        val candidateId: String,
        val candidateName: String
    )

    @Transient
     var candidateInfo: List<CandidateInfo> = ArrayList() // Initializing  it with an empty list?
}