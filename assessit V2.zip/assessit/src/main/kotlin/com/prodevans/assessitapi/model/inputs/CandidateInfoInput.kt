package com.prodevans.assessitapi.model.input

class CandidateInfoInput {

    data class CreateCandidateInfoInput(
        val name: String,
        val email: String,
        val address: String,
        val phoneNumber: String
    )

    data class UpdateCandidateInfoInput(
        val id: String,
        val name: String?,
        val email: String?,
        val address: String?,
        val phoneNumber: String?
    )

    data class DeleteCandidateInfoInput(
        val id: String
    )

}