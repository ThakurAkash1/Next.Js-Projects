package com.prodevans.assessitapi.controller


import com.prodevans.assessitapi.model.CandidateAssessment
import com.prodevans.assessitapi.service.CandidateAssessmentService
import org.springframework.graphql.data.method.annotation.QueryMapping
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.CrossOrigin


@Controller
class CandidateController(val candidateAssessmentService: CandidateAssessmentService) {

    @QueryMapping
    fun getAllCandidateAssessments(): List<CandidateAssessment> {
        return candidateAssessmentService.findAll()
    }

}
