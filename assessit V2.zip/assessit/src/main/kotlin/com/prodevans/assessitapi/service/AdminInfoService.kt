package com.prodevans.assessitapi.service

import com.prodevans.assessitapi.model.AdminInfo
import com.prodevans.assessitapi.model.input.AdminInfoInput
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.stereotype.Service
import java.util.*


@Service
class AdminInfoService
{

    @Qualifier("user")
    @Autowired
    val adminInfoDbMongoTemplate: MongoTemplate? = null
    fun save(adminInfo: AdminInfo): AdminInfo {
        return adminInfoDbMongoTemplate!!.save(adminInfo)
    }

    fun findAll(): List<AdminInfo> {
        return adminInfoDbMongoTemplate!!.findAll(AdminInfo::class.java)
    }

    fun findById(id: String): AdminInfo? {
        return adminInfoDbMongoTemplate!!.findById(id, AdminInfo::class.java)
    }

    fun createAdminInfo(input: AdminInfoInput.CreateAdminInfoInput): AdminInfo {
        val adminInfo = AdminInfo(
            name = "Null",
            email = "Null",
            location = input.location,
            phoneNumber = input.phoneNumber,
            role = "defaultRole",
            isActive = false, // Setting  default value
//            createdAt = Date().toString(), // Set current timestamp
//            updatedAt = Date().toString(), // Set current timestamp
            deptId = "defaultDeptId"
        )
        return adminInfoDbMongoTemplate?.save(adminInfo)!!
    }

    fun updateAdminInfo(input: AdminInfoInput.UpdateAdminInfoInput): AdminInfo {
        val adminInfo = adminInfoDbMongoTemplate?.findById(input.id, AdminInfo::class.java)
            ?: throw IllegalArgumentException("AdminInfo not found with ID: ${input.id}")

        adminInfo.name = input.name
        adminInfo.email = input.email
        adminInfo.location = input.location
        adminInfo.phoneNumber = input.phoneNumber
        adminInfo.updatedAt = Date() // Update updatedAt timestamp
        return adminInfoDbMongoTemplate?.save(adminInfo)!!
    }

    fun deleteAdminInfo(input: AdminInfoInput.DeleteAdminInfoInput): Boolean {
        val adminInfo = adminInfoDbMongoTemplate?.findById(input.id, AdminInfo::class.java)
            ?: throw IllegalArgumentException("AdminInfo not found with ID: ${input.id}")

        adminInfoDbMongoTemplate!!.remove(adminInfo)
        return true
    }

}