# DevOps Assessment Tool

## Prerequisites

- **MongoDB Compass 1.35.0**<br/>
 MongoDB Compass is a GUI for MongoDB which intuitively and flexibly provides detailed schema visualizations, real-time performance metrics and sophisticated querying abilities.

- **MongoDB v6.0.4**<br/>
 MongoDB is a popularly used NoSQL database. It is widely used for web application development and real-time storage.

- **Java version : 11**
- **Kotlin version : 1.6.21**
- **Apache Maven version : 3.8.6**
 
**Note :** As of `17/02/2023` ,the corresponding versions of these technologies are being used.

## Creating SpringBoot application
- Open `start.spring.io` and select these properties
 1. Project :  Maven
 2. Language : Kotlin
 3. Spring boot version : 2.6.4
 4. Java version : 11
 
 
<a href="https://ibb.co/Kw2qWbp"><img src="https://i.ibb.co/BNyZBc5/spring.png" alt="spring" border="0"></a>
 
- Add the `Spring Web` and `Spring Data MongoDB` dependencies : 

    ```
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>
    		
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-data-mongodb</artifactId>  
    </dependency>
    ```

- Open any IDE and import the file as `existing maven project`. 

- Open `pom.xml` and add the following `Graphql dependencies`:


    ```
    <dependency>  
        <groupId>com.graphql-java</groupId>  
        <artifactId>graphql-spring-boot-starter</artifactId>  
        <version>5.0.2</version>  
    </dependency> 
        	
    <dependency>  
        <groupId>com.graphql-java</groupId>  
        <artifactId>graphiql-spring-boot-starter</artifactId>  
        <version>5.0.2</version>  
    </dependency>  
        	
    <dependency>  
        <groupId>com.graphql-java</groupId>  
        <artifactId>graphql-java-tools</artifactId>  
        <version>5.2.4</version>  
    </dependency>
    ``` 

**Note :** As of `17/02/2023`, we used these dependencies.


- Now delete `application.properties` and add a file in `src\main\resources` as `application.yml` and add the following:


    ```
    server:  
      port: 9000  
      
    spring:  
      data:  
        mongodb:  
          database: AssessmentToolDB  
          port: 27017 
    ```