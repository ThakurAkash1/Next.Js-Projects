import Link from 'next/link';
import products from '../data/products';
import 'tailwindcss/tailwind.css'; 

export default function ProductDetail({ product }) {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
      <div className="container mx-auto px-4 py-8 bg-white rounded-lg shadow-lg lg:mr-10p">
        <h1 className="text-3xl font-bold mb-6 text-center">{product.name}</h1>
        <div className="w-full max-w-auto flex justify-center mb-6"> {/* Centering flex container */}
          <img src={product.image} alt={product.name} className="w-full h-auto max-h-96 object-contain rounded-lg shadow-lg" />
        </div>
        <div className="w-full max-w-auto text-center">
          <p className="text-gray-700 mb-4">{product.details}</p>
          <p className="text-xl font-bold mb-4">{product.price}</p>
          <Link href="/" passHref legacyBehavior>
            <a className="bg-blue-500 text-white py-2 px-4 rounded-lg shadow-lg hover:bg-blue-600 transition duration-300 inline-block">
              Back to Home
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
}
