import Link from 'next/link';
import products from '../data/products';

export default function Index() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Products</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((product) => (
          <div key={product.id} className="border p-4 rounded-lg shadow-lg">
            <img src={product.image} alt={product.name} className="w-full h-48 object-cover mb-4" />
            <h2 className="text-2xl font-bold mb-2">{product.name}</h2>
            <p className="text-gray-700 mb-4">{product.description}</p>
            <Link href={`/product/${product.id}`} passHref legacyBehavior>
              <a className="text-blue-500 hover:underline">View Details</a>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}



// import Link from 'next/link';
// import products from '../data/products';

// export default function Index() {
//   return (
//     <div className="container mx-auto px-4 py-8">
//     <h1 className="text-3xl font-bold mb-6">Products</h1>
//     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//       {products.map((product) => (
//         <div key={product.id} className="border p-4 rounded-lg shadow-lg">
//           <img src={product.image} alt={product.name} className="w-full h-48 object-cover mb-4" />
//           <h2 className="text-2xl font-bold mb-2">{product.name}</h2>
//           <p className="text-gray-700 mb-4">{product.description}</p>
//           <Link href={`/product/${product.id}`}>
//             <a className="text-blue-500 hover:underline">View Details</a>
//           </Link>
//         </div>
//       ))}
//     </div>
//     </div>
//   );
// }