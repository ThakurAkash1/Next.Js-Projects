// src/app/data/products.js
const products = [
    {
      id: 1,
      name: 'Roller Skates',
      description: 'Experience the thrill of skating with our premium Roller Skates. Designed for both beginners and seasoned skaters, our roller skates offer a perfect blend of style, comfort, and performance. Whether you re cruising down the street, enjoying a skate park, or participating in roller derby, these skates are built to enhance your skating experience.',
      details: '* Product Details Boot Material: Synthetic leather with a reinforced toe cap for added protection. Wheels: Polyurethane wheels that provide excellent grip and durability. Available in sizes 54mm, 58mm, and 62mm. Bearings: ABEC-7 bearings for a fast, smooth ride. Plate: Lightweight aluminum base plate for superior control and stability. Closure System: Lace-up front combined with an adjustable velcro strap for a secure fit. Brake: Replaceable toe stopper made from non-marking rubber. Sizes: Available in a range of sizes from youth to adult. Weight: Approximately 3 lbs per skate. Color Options: Classic black, vibrant red, electric blue, and more.',
      price: '$100.00',
      image: '/SkatingShoe.jpeg',
    },
    {
      id: 2,
      name: 'RedShoe',
      description: 'Step into the spotlight with the RedShoe Roller Skates, where fashion meets function. Perfect for skaters of all skill levels, these vibrant red skates are designed to make a statement while providing a smooth and comfortable ride. Whether you re at the rink, on the streets, or showcasing your skills at the park, RedShoe Roller Skates will keep you gliding effortlessly in style.his is a brief description of Product 2.',
      details: '* Boot Material: Durable synthetic leather with a reinforced toe cap for added protection. Wheels: 58mm polyurethane wheels designed for durability and a smooth ride. Bearings: ABEC-7 bearings for high-speed performance and reduced friction. Plate: Lightweight and strong aluminum base plate for enhanced stability and control. Closure System: Secure lace-up front with an additional velcro strap for a customized fit. Brake: Non-marking rubber toe stopper, which is replaceable and ideal for quick stops. Sizes: Available in a comprehensive range of sizes from youth to adult. Weight: Approximately 3 lbs per skate. Color Options: Available in signature red.',
      price: '$30.00',
      image: '/RedShoe.jpeg',
    },
    {
      id: 3,
      name: 'Hardtail Mountain Bike 2024',
      description: 'Conquer trails and explore new terrains with the Sport 29 Hardtail Mountain Bike 2024. Designed for both novice and experienced riders, this mountain bike combines cutting-edge technology with robust construction to deliver an exceptional riding experience. Whether you re tackling rugged mountain paths or cruising through forest trails, the Sport 29 provides the perfect balance of performance, durability, and comfort.',
      details: '* The Sport 29 Hardtail Mountain Bike 2024 features a lightweight 6061 aluminum alloy frame, ensuring durability without compromising on weight. Equipped with 29-inch double-walled alloy rims and all-terrain tires, this bike offers superior traction and a smoother ride over obstacles. Its front suspension fork with 100mm travel effectively absorbs shocks, providing a comfortable ride on rough terrains. The bikes 21-speed Shimano gear system allows for seamless shifting and optimal power transfer, making it versatile for various riding conditions. Hydraulic disc brakes with 160mm rotors ensure powerful and reliable stopping power in all weather conditions. The wide handlebars enhance control and maneuverability, while the ergonomic saddle ensures comfort on long rides. Additionally, alloy platform pedals provide a secure grip.',
      price: '$300.00',
      image: '/cycle.jpeg',
    },
    {
      id: 4,
      name: 'Badminton kit',
      description: 'Elevate your badminton game with our comprehensive Badminton Kit, designed for players of all skill levels. This all-in-one set includes everything you need for a fun and competitive match, whether you re playing in your backyard, at the park, or in a professional court. Crafted with high-quality materials, this kit ensures durability, performance, and convenience, making it the perfect choice for casual games and serious practice sessions alike.',
      details: '* The Badminton Kit features a pair of lightweight yet sturdy rackets made from premium aluminum alloy, ensuring a perfect balance of strength and agility. The rackets are designed with a comfortable grip, reducing hand fatigue and allowing for precise shots and powerful smashes. Included in the kit are high-quality shuttlecocks made from durable nylon with a cork base, providing consistent flight and durability during intense rallies. The shuttlecocks are designed to withstand high-impact play, making them ideal for both indoor and outdoor use.',
      price: '$40.00',
      image: '/BatmintanKit.jpeg',
    },
    {
      id: 5,
      name: 'Red Tennis Ball',
      description: 'Introducing the Red Tennis Ball, specifically designed for beginner and junior players to help them develop their skills with ease and confidence. Its vibrant red color not only makes it highly visible on the court but also adds a fun and energetic touch to your game.',
      details: '* The Red Tennis Ball is crafted from high-quality, non-toxic rubber, ensuring durability and safety for players of all ages. Its lower compression compared to standard tennis balls makes it softer and easier to hit, providing a slower and more controlled bounce. This feature is particularly beneficial for beginners, as it allows more time to react and improves stroke development. The balls felt covering is made from a durable, high-visibility material that stands up to frequent use while maintaining its bright red color. The felt is designed to withstand various playing surfaces, including hard courts, clay, and grass, ensuring versatile performance.',
      price: '$200.00',
      image: '/Boll.jpeg',
    },
    {
      id: 6,
      name: 'Rackets',
      description: 'Elevate your game with our high-performance Tennis Rackets, designed for players of all levels. Combining cutting-edge technology with superior materials, these rackets offer exceptional power, control, and comfort. Whether youre a beginner, an intermediate player, or an advanced competitor, our tennis rackets are engineered to enhance your performance on the court. ',
      details: '* Our Tennis Rackets are crafted from high-quality graphite, ensuring a perfect balance of strength, flexibility, and lightweight performance. The graphite frame provides excellent stability and power, allowing you to hit precise shots with minimal effort. The rackets feature an oversized head, offering a larger sweet spot to improve accuracy and power, especially beneficial for beginners and intermediate players. The string pattern is designed to provide optimal spin and control, enhancing your ability to execute various shot techniques.',
      price: '$50.00',
      image: '/Racket.jpeg',
    }
  ];
  
  export default products;
  