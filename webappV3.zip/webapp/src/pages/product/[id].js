// pages/product/[id].js

import products from '../../app/data/products';
import ProductDetail from '@/app/components/ProductDetail';

export async function getStaticPaths() {
  const paths = products.map((product) => ({
    params: { id: product.id.toString() },
  }));

  return { paths, fallback: false };
}

export async function getStaticProps({ params }) {
  const product = products.find((product) => product.id.toString() === params.id);

  if (!product) {
    return {
      notFound: true,
    };
  }

  return {
    props: {
      product,
    },
  };
}

export default function ProductPage({ product }) {
  return <ProductDetail product={product} />;
}
