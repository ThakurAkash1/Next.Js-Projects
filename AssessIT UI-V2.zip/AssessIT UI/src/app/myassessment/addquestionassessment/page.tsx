import AddQuestionAssessment from '@/components/myassessment/addQuestionAssessment';

const AddQuestionAssessments = () => {
    return(
            <AddQuestionAssessment />
    )
}
export default AddQuestionAssessments;