import CreateAssessment from '@/components/myassessment/createAssessment';
//import { useRouter } from 'next/router';

const CreateAssessments = () => {
    return(
            <CreateAssessment />
    )
}
export default CreateAssessments;