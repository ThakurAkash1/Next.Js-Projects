import AllQuestionDetails from "@/components/myassessment/allQuestionDetails";


const AllQuestionDetail = () => {
    return(
            <AllQuestionDetails />
    )
}
export default AllQuestionDetail;