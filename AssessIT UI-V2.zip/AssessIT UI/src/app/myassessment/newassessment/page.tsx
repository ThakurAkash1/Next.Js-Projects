import NewAssessment from '@/components/myassessment/newAssessment';
const NewAssessments = () => {
    return(
            <NewAssessment />
    )
}
export default NewAssessments;