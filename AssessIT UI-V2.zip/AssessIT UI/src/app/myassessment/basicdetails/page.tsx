import BasicDetails from '@/components/myassessment/basicDetails';


const BasicDetail = () => {
    return(
            <BasicDetails />
    )
}
export default BasicDetail;