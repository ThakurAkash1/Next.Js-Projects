import AllQuestion from '@/components/myassessment/allQuestion';


const AllQuestions = () => {
    return(
            <AllQuestion />
    )
}
export default AllQuestions;