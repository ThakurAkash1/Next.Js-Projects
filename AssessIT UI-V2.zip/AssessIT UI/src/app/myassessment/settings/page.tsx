import Settings from '@/components/myassessment/settings';


const Setting = () => {
    return(
            <Settings />
    )
}
export default Setting;