import SettingDetails from "@/components/myassessment/settingDetails";

const SettingDetail = () => {
    return(
            <SettingDetails />
    )
}
export default SettingDetail;