import AddQuestions from '@/components/myassessment/addQuestions';

const AddQuestion = () => {
    return(
            <AddQuestions />
    )
}
export default AddQuestion;