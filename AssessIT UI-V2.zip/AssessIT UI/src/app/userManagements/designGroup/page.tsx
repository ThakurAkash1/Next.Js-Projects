
import DesignGroup from '@/components/userManagement/designGroup'


const DesignGroups = () => {
    return (
      
          <DesignGroup/>
      
    )
  }
  
  export default DesignGroups