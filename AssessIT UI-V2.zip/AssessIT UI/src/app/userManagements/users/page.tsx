
import User from '@/components/userManagement/users'


const Users = () => {
    return (
  
          <User/>
     
    )
  }
  
  export default Users