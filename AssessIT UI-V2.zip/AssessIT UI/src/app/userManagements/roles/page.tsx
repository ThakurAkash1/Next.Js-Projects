import Roles from '@/components/userManagement/roles'



const Role = () => {
    return (
    
          <Roles/>
    
    )
  }
  
  export default Role