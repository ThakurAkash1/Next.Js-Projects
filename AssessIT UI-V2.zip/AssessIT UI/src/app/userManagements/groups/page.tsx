import Groups from '@/components/userManagement/groups'


const Group = () => {
    return (
     
          <Groups/>
     
    )
  }
  
  export default Group