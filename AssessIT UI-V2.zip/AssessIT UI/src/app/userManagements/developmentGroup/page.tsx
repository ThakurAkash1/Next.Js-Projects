
import DevelopmentGroup from '@/components/userManagement/developmentGroup'


const DevelopmentGroups = () => {
    return (
      
          <DevelopmentGroup/>
      
    )
  }
  
  export default DevelopmentGroups