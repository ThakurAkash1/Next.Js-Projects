import AssessmentIntakes from '@/components/reports/assessmentIntakes'


const AssessmentIntake = () => {
  return (
    <AssessmentIntakes/>
  )
}

export default AssessmentIntake