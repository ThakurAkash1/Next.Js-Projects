import UserManagement from '@/components/reports/userManagement'
import React from 'react'


const UserManagements = () => {
    return (
      <div><UserManagement/></div>
    )
  }
  
  export default UserManagements