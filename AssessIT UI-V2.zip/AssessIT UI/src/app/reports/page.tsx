
import Reports from '@/components/reports/report'

const Report = () => {
  return (
    <Reports/>
  )
}

export default Report