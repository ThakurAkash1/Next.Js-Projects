import ActivityLog from '@/components/reports/activityLog'

const ActivityLogs = () => {
  return (
    
        <ActivityLog />
    
  )
}

export default ActivityLogs