
import AllAssessments from '@/components/reports/allAssessments'

 const AllAssessment = () => {
  return (
  
    <AllAssessments />

  )
}

export default AllAssessment
