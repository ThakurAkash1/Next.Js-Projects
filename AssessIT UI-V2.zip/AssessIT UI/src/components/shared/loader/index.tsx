import React from 'react'
import style from './styles.module.css'

const Loader = () => {
  return (
    <div>

    </div>
  )
}

export default Loader