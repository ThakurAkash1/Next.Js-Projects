// DevelopmentGroupData.js
const groupData = [
    {
      sno: 1,
      GroupName: 'Development',
      Members: 'Sravani',
      CreatedOn: '2023-07-29,11:00 AM',
      Action: 'edit',
    },
    {
        sno: 2,
        GroupName: 'Design',
        Members: '',
        CreatedOn: '2023-07-2611:00 AM',
        Action: 'edit',
    },
  ];
  
  export default groupData;
  