"use client";
import React, { useEffect, useState, useRef } from "react";
import styles from "@/components/myassessment/newassessment/styles.module.css";
import Image from "next/image";
import documentImage from "/public/images/FrameFile.svg";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { BsEye, BsPlusSquare } from "react-icons/bs";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import { RiDeleteBin6Line } from "react-icons/ri";
import { MdOutlineModeEditOutline } from "react-icons/md";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { CallApi } from "@/utils/util";

interface Assessment {
  draftQuestions: any;
  id: string;
  name: string;
  status: string;
  description: string;
  createdAt: string;
  QuestionsAdd: String;
}

interface PopupProps {
  itemId: string;
  onDelete: (itemId: string) => void;
  onClose: () => void;
}

const NewAssessment: React.FC<any> = (props) => {
  const router = useRouter();
  const searchParam = useSearchParams();
  const [assessmentId, setAssessmentId] = useState<string | null>(null);

  useEffect(() => {
    const id = searchParam.get("assessmentId");
    // console.log("assessmentID", id);
    setAssessmentId(id);
  }, [searchParam]);

  const navigate = (page: String) => {
    router.push("/myassessment/" + page + "?assessmentId=" + assessmentId);
  };
  const [myData, setMyData] = useState<Assessment[]>([]);
  const [selectedAssessment, setSelectedAssessment] = useState<number | null>(
    null
  );
  const [isSidebarOpen, setSidebarOpen] = useState<boolean>(false);
  // const [assessmentId, setAssessmentId] = useState<string | null>(null);
  const popupRef = useRef<HTMLDivElement | null>(null);

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  // const handleOutsideClick = () => {
  //   setSidebarOpen(false);
  // };

  const handleOutsideClick = (event: MouseEvent) => {
    if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
      setSelectedAssessment(null);
    }
  };

  useEffect(() => {
    if (selectedAssessment !== null) {
      document.addEventListener("mousedown", handleOutsideClick);
    } else {
      document.removeEventListener("mousedown", handleOutsideClick);
    }
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [selectedAssessment]);

  const QuestionsAdd: string = "2";

  const getStatusBulletColor = (status: string): string => {
    switch (status) {
      case "PUBLISHED":
        return "rgba(67, 153, 81, 1)";
      case "DRAFT":
        return "rgba(173, 173, 173, 1)";
      case "DELETED":
        return "rgba(243, 86, 86, 1)";
      default:
        return "#808080";
    }
  };

  const handlePopupToggle = (index: number) => {
    if (selectedAssessment === index) {
      setSelectedAssessment(null);
    } else {
      setSelectedAssessment(index);
    }
  };

  const handleDelete = (itemId: string) => {};

  const Popup: React.FC<PopupProps> = ({ itemId, onDelete }) => {
    const deleteMutation = `mutation MyMutation {
      deleteAssessment(id: "${itemId}")
    }`;

    const deleteAssessment = async (deleteMutation: string) => {
      const isConfirmed = window.confirm("Are you sure you want to delete this assessment?");
      
      if (isConfirmed) {
        try {
          const deleteAssessment = await CallApi({
            query: deleteMutation,
            token: "",
          });
          return deleteAssessment;
        } catch (error) {
          console.error("Error:", error);
        }
      } else {
        console.log("Deletion cancelled by user.");
      }
    };
    
    return (
      <div ref={popupRef} className={`${styles.popup} `}>
        <ul className={`${styles.popupList}`}>
          <li>
            <button
              className={`${styles.threeboxbtn}`}
              onClick={() => handleIdPass(itemId, false)}
            >
              <BsEye />
              View
            </button>
          </li>
          <li>
            <button className={`${styles.threeboxbtn}`}
            onClick={() => handleIdPass(itemId, true)}>
              <MdOutlineModeEditOutline />
              Edit
            </button>
          </li>
          <li>
            <button
              className={`${styles.threeboxbtn}`}
              onClick={() => deleteAssessment(deleteMutation)}
            >
              <RiDeleteBin6Line />
              Delete
            </button>
          </li>
        </ul>
      </div>
    );
  };

  useEffect(() => {
    function ListApi() {
      var myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");
      const graphql = JSON.stringify({
        query:
          "query MyQuery {\r\n  assessments {\r\n   createdAt\r\n     description\r\n  id\r\n    name\r\n    status\r\n  draftQuestions{\r\n  question\r\n  }\r\n }\r\n}\r\n",
        variables: {},
      });

      var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: graphql,
      };

      fetch("http://localhost:9001/graphql", requestOptions)
        .then((response) => response.json())
        .then((result) => {
          console.log("Response from server:", result);
          setMyData(result.data.assessments);
        })
        .catch((error) => console.error(error));
    }

    ListApi();
  }, []);

  const handleIdPass = (id: string, isEdit: boolean) => {
    const url = isEdit
      ? `/myassessment/basicdetails?id=${id}&editable=true`
      : `/myassessment/basicdetails?id=${id}`;
    router.push(url);
    console.log(url); 
  };
  
  

  return (
    <div
      className={`${styles.MyAssessmentcontainer} h-100 w-99 d-flex flex-column`}
      // onBlur={handleOutsideClick}
    >
      {myData && myData.length === 0 ? (
        <div className={`mt-1 ${styles.total_card} gap-2 `}>
          <div className="d-flex justify-content-between align-items-center">
            <div className={` text-dark ${styles.Roles_title}`}>
              My Assessments
            </div>
            <button
              className={`${styles.Newrolebtn}`}
              onClick={() => router.push("createassessment")}
            >
              <div>
                <BsPlusSquare />
              </div>
              <div className="d-none d-md-inline">New</div>
            </button>
          </div>
          <div
            className={
              "d-flex align-items-center justify-content-center gap-2 "
            }
          >
            <Image
              className={`${styles.customImageassessment}`}
              alt="#"
              src={documentImage}
            />
          </div>
        </div>
      ) : myData && myData.length > 0 ? (
        <div className={`mt-1 ${styles.total_card}`}>
          <div className="d-flex align-items-center justify-content-between ">
            <div className={` text-dark ${styles.Roles_title}`}>
              My Assessments
            </div>
            <button
              className={`${styles.Newrolebtn}`}
              onClick={() => router.push("/myassessment/createassessment")}
            >
              <div>
                <BsPlusSquare />
              </div>
              <div className="d-none d-md-inline">New</div>
            </button>
          </div>

          <div className={`col-12  ${styles.Newcontainer}`}>
            <div className={`${styles.filecreateDrft}`}>
              <div className={`${styles.boxContainer} row col-12`}>
                {myData.map((item: Assessment, index: number) => (
                  <div
                    className={`col-xl-4 col-lg-4 col-md-4 col-sm-12 mx-1 ${
                      styles.box
                    } ${index === 0 ? styles.firstBox : styles.secondBox}`}
                    style={{
                      borderLeftColor:
                        item.status === "PUBLISHED" ? "green" : "grey",
                    }}
                    key={index}
                  >
                    <div className="d-flex flex-column mt-2">
                      <div className={`${styles.questionscoreone}`}>
                        <Link
                          href={{
                            pathname: "/myassessment/basicdetails",
                            query: { id: item.id },
                          }}
                        >
                          <strong onClick={() => handleIdPass(item.id,false)}>
                            {item.name}
                          </strong>
                        </Link>
                        <label>
                          <BiDotsVerticalRounded
                            onClick={() => handlePopupToggle(index)}
                          />
                        </label>
                      </div>
                      <div className={`${styles.Para} mt-2`}>
                        <p>{item.description}</p>
                      </div>
                      <div className={`${styles.Status} d-flex`}>
                        <label>Status:</label>
                        <span
                          className={styles.statusBullet}
                          style={{
                            backgroundColor: getStatusBulletColor(item.status),
                            display: "inline-block",
                            width: "10px",
                            height: "10px",
                            borderRadius: "50%",
                            marginRight: "5px",
                            marginTop: "3px",
                          }}
                        ></span>
                        <div className={`${styles.StatusTitle}`}>
                          {item.status}
                        </div>
                      </div>
                      <div className={`${styles.Status} d-flex mt-2`}>
                        <label>Questions Added:</label>
                        <span>{item?.draftQuestions.length}</span>
                      </div>
                      <div className={`${styles.Status} d-flex mt-2`}>
                        <label>Created On:</label>
                        <span>{item.createdAt}</span>
                      </div>
                    </div>
                    {selectedAssessment !== null &&
                      selectedAssessment === index && (
                        <Popup
                          itemId={item.id}
                          onDelete={handleDelete}
                          onClose={function (): void {
                            throw new Error("Function not implemented.");
                          }}
                        />
                      )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default NewAssessment;
