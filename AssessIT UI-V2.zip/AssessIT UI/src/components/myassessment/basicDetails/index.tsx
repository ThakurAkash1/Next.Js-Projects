"use client";
import React, { useState, useEffect } from "react";
import styles from "@/components/myassessment/basicDetails/styles.module.css";
import Image from "next/image";
import uploadimgage from "/public/images/uploadimg.svg";
import { BsPlusSquare, BsPencil } from "react-icons/bs";
import { TbMathGreater } from "react-icons/tb";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import { useRouter, useSearchParams } from "next/navigation";
import { CallApi } from "@/utils/util";

interface AssessmentData {
  id: string;
  name: string;
  description: string;
  testLanguage: string;
  categoryId?: string;
  createdAt?: string;
  createdBy?: string;
  draftQuestions?: Array<{
    questionId?: string;
    subcategoryId?: string;
    question?: string;
    questionType?: string;
    multipleChoice?: boolean;
    totalWeightage?: number;
    answer?: Array<string>;
    options?: Array<{
      option?: string;
      weightage?: number;
    }>;
  }>;
  duration?: string;
  perQuestionDuration?: string;
  status?: string;
  thumbnailImg?: string;
  totalScore?: number;
  updatedAt?: string;
}

const BasicDetails: React.FC = () => {
  const [assessmentData, setAssessmentData] = useState<AssessmentData | null>(
    null
  );
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [isEditing, setEditing] = useState(false);
  const [editedData, setEditedData] = useState<Partial<AssessmentData>>({});
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const router = useRouter();
  const searchParam = useSearchParams();
  // const assessmentId = searchParam.get("id");
  const [assessmentId, setAssessmentId] = useState<string | null>(null);

  useEffect(() => {
    const id = searchParam.get("id");
    const editable = searchParam.get("editable");
    if (id) {
      setAssessmentId(id);
    }
    if(editable) setEditing(true);
  }, [searchParam]);

  const navigate = (page: string, assessmentId?: string) => {
    const id = assessmentId || searchParam.get("assessmentId");
    if (id) {
      router.push(`/myassessment/${page}?assessmentId=${id}`);
    } else {
      router.push(`/myassessment/${page}`);
    }
  };

  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };

  useEffect(() => {
    if (!assessmentId) return;

    const fetchData = async () => {
      const myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");
      const graphql = JSON.stringify({
        query: `query {
          assessmentById(id: "${assessmentId}") {
            id
            name
            description
            testLanguage
            categoryId
            createdAt
            createdBy
            draftQuestions {
              questionId
              subcategoryId
              question
              questionType
              multipleChoice
              totalWeightage
              answer
              options {
                option
                weightage
              }
            }
            duration
            perQuestionDuration
            status
            thumbnailImg
            totalScore
            updatedAt
          }
        }`,
        variables: { id: assessmentId },
      });

      const requestOptions: RequestInit = {
        method: "POST",
        headers: myHeaders,
        body: graphql,
        redirect: "follow" as RequestRedirect,
      };

      try {
        const response = await fetch(
          "http://localhost:9001/graphql",
          requestOptions
        );
        const result = await response.json();
        const assessment = result.data.assessmentById;
        if (assessment) {
          setSelectedImage(assessment.thumbnailImg || null);
          setAssessmentData(assessment);
          if (isEditing) {
            setEditedData({
              name: assessment.name,
              description: assessment.description,
              testLanguage: assessment.testLanguage,
              thumbnailImg: assessment.thumbnailImg,
            });
          }
        }
      } catch (error) {
        console.error("Error fetching data", error);
      }
    };

    fetchData();
  }, [assessmentId]);

  const mutationQuery = `
    mutation {
      updateAssessmentDetails(id: "${assessmentId}", assessmentInput: {
        name: "${editedData.name || assessmentData?.name || ""}",
        description: "${
          editedData.description || assessmentData?.description || ""
        }",
        testLanguage: "${
          editedData.testLanguage || assessmentData?.testLanguage || ""
        }",
        categoryId: "ffe30c36-5170-44d2-bd1c-f7ca87f7eb57",
        totalScore: ${assessmentData?.totalScore || 0},
        draftQuestions: [
          ${
            assessmentData?.draftQuestions
              ?.map(
                (question) => `{
              questionId: "${question.questionId || ""}",
              subcategoryId: "${question.subcategoryId || ""}",
              question: "${question.question || ""}",
              questionType: "${question.questionType || ""}",
              multipleChoice: ${question.multipleChoice || false},
              totalWeightage: ${question.totalWeightage || 0},
              answer: ${JSON.stringify(question.answer || [])},
              options: [
                ${question.options
                  ?.map(
                    (opt) => `{
                  option: "${opt.option || ""}",
                  weightage: ${opt.weightage || 0}
                }`
                  )
                  .join(",\n")}
              ]
            }`
              )
              .join(",\n") || ""
          }
        ],
        thumbnailImg: "${
          editedData.thumbnailImg ||
          assessmentData?.thumbnailImg ||
          "image.jpeg"
        }",
        perQuestionDuration: "${assessmentData?.perQuestionDuration || ""}",
        duration: "${assessmentData?.duration || ""}",
        status: "${assessmentData?.status || "draft"}",
        subCategoryId: "663b1b5063027d7a5be9a1f1",
        createdBy: "${assessmentData?.createdBy || "Akash"}"
      }) {
        name
        description
        testLanguage
        id
        createdBy
        draftQuestions {
          questionId
          multipleChoice
          question
          questionType
          totalWeightage
          answer
          options {
            option
            weightage
          }
        }
      }
    }
  `;

  const callApi = async (mutationQuery: string) => {
    try {
      const response = await CallApi({ query: mutationQuery, token: "" });
      console.log("Response:", response);

      if (
        !response ||
        !response.data ||
        !response.data.updateAssessmentDetails ||
        !response.data.updateAssessmentDetails.id
      ) {
        throw new Error("Invalid response structure");
      }

      const id = response.data.updateAssessmentDetails.id;
      setAssessmentId(id);
      console.log("ID:>>>>>>>>>>>", id);

      return id;
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  const handleSaveClick = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const id = await callApi(mutationQuery);
    } catch (error) {
      console.error("Error:", error);
    }
    if (setEditing) {
      setEditing(false);
    }
  };

  const handleEditClick = () => {
    if (assessmentData) {
      setEditing(true);
      setEditedData({
        name: assessmentData.name,
        description: assessmentData.description,
        testLanguage: assessmentData.testLanguage,
        thumbnailImg: assessmentData.thumbnailImg,
      });
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setSelectedImage(base64String);
        setEditedData((prevData) => ({
          ...prevData,
          thumbnailImg: base64String,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const questionDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Add any additional logic or API calls here
      router.push(
        `/myassessment/allquestiondetails?assessmentId=${assessmentId}`
      );
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const settingDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Add any additional logic or API calls here
      router.push(`/myassessment/settingdetails?assessmentId=${assessmentId}`);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div
      className={`h-100 w-99 d-flex flex-column`}
      onBlur={handleOutsideClick}
    >
      {/* {isSidebarOpen && <div className={styles.overlay} />} */}
      {/* {isSidebarOpen && (
        <AssessmentMobileSideBar
          setMobileSidebarSelect={() => {}}
          isOpen={isSidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
      )} */}
      <form>
        <div className={`${styles.total_card} row `}>
          <div className="d-flex gap-3 align-items-center justify-content-start">
            <div className="d-flex gap-2 align-items-center justify-content-center ">
              <h5 className={` h6 text-dark d-none d-md-block`}>Test</h5>
            </div>

            <div className="d-flex gap-2 align-items-center justify-content-center">
              <h5
                className={`${styles.reports_tab} ${styles.myAssessment}`}
                onClick={() => navigate("newassessment")}
              >
                My Assessment
                <span className={`${styles.greater_than_symbol} ms-1 `}>
                  <TbMathGreater />
                </span>
              </h5>
              <h6 className={` ${styles.activity_log_tab}`}>
                Assessment Details
              </h6>
            </div>
          </div>
        </div>
        <div className={`row ${styles.create_assessment}`}>
          <div className="col-3 d-none d-md-block">
            <div className={`${styles.DetailsOptions}`}>
              <div className="d-flex  flex-column justify-content-between">
                <div className="d-flex align-items-center">
                  <div className={`${styles.Detailbox}`}>
                    <div className={`${styles.Detailboxtext}`}>
                      Basic Detail
                    </div>
                  </div>
                  <div className={`${styles.VerticalLine}`}></div>
                </div>
                <div
                  className="p-3"
                  // onClick={(e) => navigate("allquestiondetails")}
                  onClick={(e) => {
                    questionDetails(e);
                  }}
                >
                  Questions
                </div>
                <div
                  className="p-3"
                  onClick={(e) => {
                    settingDetails(e);
                  }}
                >
                  Settings
                </div>
                <div
                  className="p-3"
                  //   onClick={() => props.stepChange(props.step + 3)}
                >
                  Result&nbsp;Table
                </div>
              </div>
            </div>
          </div>
          <div
            className={`col-9 d-flex align-items-start  flex-column bg-white ${styles.Detailsdata}`}
          >
            <div className="row mt-2">
              <div className="col-6 mt-2">
                <div className="d-flex align-items-center ">
                  <div
                    className={`${styles.DetailSidebar} d-lg-none d-md-none`}
                  >
                    <>
                      <button
                        className={`${styles.btnnewDraftarrow} me-2`}
                        onClick={handleNewButtonClick}
                      >
                        <MdOutlineKeyboardDoubleArrowRight
                          className={`${styles.iconArrorw}`}
                        />
                      </button>
                    </>
                  </div>
                  <h5 className={styles["custom-heading"]}>BasicDetails</h5>
                </div>
              </div>
              <div className="col-6">
                {!isEditing && (
                  <button
                    id="editbutton"
                    className={`${styles.btnedit}`}
                    onClick={handleEditClick}
                  >
                    <BsPencil
                      className={`${styles.iconplus} ${styles.gapfirst}`}
                    />
                    Edit
                  </button>
                )}
              </div>
            </div>
            {assessmentData && (
              <div className={`${styles.AllQstTitle}`}>
                <div className={`${styles.PassdataCreate}`}>
                  <div className="row mt-4 ">
                    <div className="col-md-8 h-15 ">
                      <div className={`${styles.fomgroupcreate}`}>
                        <label htmlFor="assessmentName">Assessment Name</label>
                        <input
                          type="text"
                          placeholder="Enter Name"
                          id="name"
                          className={`${styles.formcontrolname}`}
                          value={
                            isEditing ? editedData.name : assessmentData.name
                          }
                          onChange={(e) =>
                            setEditedData({
                              ...editedData,
                              name: e.target.value,
                            })
                          }
                          readOnly={!isEditing}
                        />
                      </div>
                    </div>

                    <div className="col d-lg-none d-md-none  mx-auto">
                      <div
                        className={`${styles.Uploadimg} ${styles.dashedBorder}`}
                      >
                        <div
                          className={`${styles.Uploadimg} d-flex flex-column align-items-center`}
                        >
                          {selectedImage ? (
                            <img
                              className={`${styles.uploadedImage} mt-1 mb-2`}
                              alt="Thumbnail"
                              src={selectedImage}
                              onClick={() =>
                                isEditing &&
                                document.getElementById("fileInput")?.click()
                              }
                            />
                          ) : (
                            <>
                              <label htmlFor="fileInput" className="mt-5 mb-2">
                                <Image alt="#" src={uploadimgage} />
                              </label>
                              <div
                                className={`${styles.Uploadimgtxt} text-center`}
                              >
                                <h6 className={`${styles.UploadimgTitle}`}>
                                  Upload Thumbnail
                                </h6>
                                <p className={`${styles.UploadimgDesc}`}>
                                  Supported formats: JPEG, PNG
                                </p>
                              </div>
                            </>
                          )}
                        </div>
                        {isEditing && (
                          <input
                            id="fileInput"
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            style={{ display: "none" }}
                          />
                        )}
                      </div>
                    </div>

                    <div className={`col-md-8 h-65 mt-2 ${styles.UploadDesc}`}>
                      <div>
                        <label htmlFor="description">Description</label>
                        <textarea
                          id="description"
                          placeholder="Lorem ipsum dolor sit amet"
                          className={`${styles.formcontrol}`}
                          value={
                            isEditing
                              ? editedData.description
                              : assessmentData.description
                          }
                          onChange={(e) =>
                            setEditedData({
                              ...editedData,
                              description: e.target.value,
                            })
                          }
                          readOnly={!isEditing}
                          // onChange={handleInputChange}
                        ></textarea>
                      </div>
                    </div>
                    <div className="col d-none d-md-block">
                      <div
                        className={`${styles.Uploadimg} ${styles.dashedBorder}`}
                      >
                        <div
                          className={`${styles.Uploadimg} d-flex flex-column align-items-center`}
                        >
                          {selectedImage ? (
                            <img
                              className={`${styles.uploadedImage} mt-1 mb-2 `}
                              alt="Thumbnail"
                              src={selectedImage}
                              onClick={() =>
                                isEditing &&
                                document.getElementById("fileInput")?.click()
                              }
                            />
                          ) : (
                            <>
                              <label htmlFor="fileInput" className="mt-5 mb-2">
                                <Image alt="#" src={uploadimgage} />
                              </label>
                              <div
                                className={`${styles.Uploadimgtxt} text-center`}
                              >
                                <h6 className={`${styles.UploadimgTitle}`}>
                                  Upload Thumbnail
                                </h6>
                                <p className={`${styles.UploadimgDesc}`}>
                                  Supported formats: JPEG, PNG
                                </p>
                              </div>
                            </>
                          )}
                        </div>
                        {isEditing && (
                          <input
                            id="fileInput"
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            style={{ display: "none" }}
                          />
                        )}
                      </div>
                    </div>
                    <div className="col-md-8  h-85">
                      <div className={`${styles.grouptitile}`}>
                        <label htmlFor="group">Group</label>
                        <select
                          id="group"
                          className={`${styles.groupOption}`}
                          // value={assessmentData.assessmentGroup}
                          // value={isEditing ? editedData.assessmentGroup : assessmentData.assessmentGroup}
                          // onChange={(e) =>
                          //   setEditedData({
                          //     ...editedData,
                          //     assessmentGroup: e.target.value,
                          //   })
                          // }
                          // readOnly={!isEditing}
                          // onChange={handleInputChange}
                        >
                          <option value="Select" hidden>
                            Select
                          </option>
                          <option value="Developer">Developer</option>
                          <option value="Infra Team">Infra Team</option>
                          <option value="Backend">Backend</option>
                          <option value="Finance">Finance</option>
                          <option value="Design">Design</option>
                        </select>
                      </div>
                    </div>
                    <div className={` col-md-4 h-85 ${styles.Creategroupbtn}`}>
                      <button type="button" className={`${styles.CreateGroup}`}>
                        <BsPlusSquare className={`${styles.iconCreate}`} />
                        Create Group
                      </button>
                    </div>
                    <div className="col-md-12 h-50">
                      <div className={`${styles.formgrouptext}`}>
                        <label htmlFor="language">Text Language</label>
                        <select
                          id="language"
                          className={`${styles.formlanguage}`}
                          value={
                            isEditing
                              ? editedData.testLanguage
                              : assessmentData.testLanguage
                          }
                          onChange={(e) =>
                            setEditedData({
                              ...editedData,
                              testLanguage: e.target.value,
                            })
                          }
                        >
                          <option value="Select" hidden>
                            Select
                          </option>
                          <option value="English">English</option>
                          <option value="Hindi">Hindi</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {isEditing && (
              <div className="container">
                <div className="row">
                  <div className={`col-md-12 ${styles.createbtnnext}`}>
                    <button
                      id="btnbox1"
                      className={`${styles.createnextbutton}`}
                      onClick={handleSaveClick}
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};

export default BasicDetails;
