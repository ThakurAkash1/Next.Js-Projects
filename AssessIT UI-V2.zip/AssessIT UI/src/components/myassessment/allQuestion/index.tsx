"use client";
import React, { useState, useEffect } from "react";
import styles from "@/components/myassessment/allQuestion/styles.module.css";
import Image from "next/image";
import document from "/public/images/StepperNum.svg";
import checkgreen from "/public/images/GreenStepper.svg";
import documentone from "/public/images/Stepperone.svg";
import docone from "/public/images/StepperNumone.svg";
import documenttwo from "/public/images/Steppertwo.svg";
import line from "/public/images/Line3.svg";
import linethree from "/public/images/LInethreeStraignt.svg";
import lineone from "/public/images/Line5.svg";
import { BsPlusSquare } from "react-icons/bs";
import { TbMathGreater } from "react-icons/tb";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { useSession } from "next-auth/react";
import ReceiveAllQuestions from "../receiveAllQuestions";
import { useRouter, useSearchParams } from "next/navigation";
import { CallApi } from "@/utils/util";

interface AllQuestionProps {
  // step: number;
  // stepChange: (step: number) => void;
  // question: any; // Adjust the type for question based on your needs
  // receivedQuestions: any[]; // Adjust the type for receivedQuestions based on your needs
  // assessmentId: string; // Adjust the type for assessmentId
}

const AllQuestion: React.FC<AllQuestionProps> = (props) => {
  const router = useRouter();
  const searchParam = useSearchParams();
  const [assessmentId, setAssessmentId] = useState<string | null>(null);
  const [questions, setQuestions] = useState<any>(null);
  const navigate = (page: String) => {
    router.push("/myassessment/" + page + "?assessmentId=" + assessmentId);
  };
  const addQuestionPage = (page: String) => {
    router.push("/myassessment/" + page + "?assessmentId=" + assessmentId);
  };

  useEffect(() => {
    const id = searchParam.get("assessmentId");
    console.log("assessmentID all question page", id);
    setAssessmentId(id);
  }, []);

  return (
    <div className={`h-100 w-99 d-flex flex-column`}>
      <div className={`${styles.total_card} row`}>
        <div className="d-flex gap-3 align-content-center justify-content-start">
          <div className="d-flex gap-2 align-items-center justify-content-center ">
            <h5 className={` h6 text-dark d-none d-md-block`}>
              Create Assessment
            </h5>
          </div>
          <div className="d-flex gap-2 align-items-center justify-content-center">
            <h5
              className={`${styles.reports_tab} ${styles.myAssessment}`}
              onClick={() => navigate("newassessment")}
            >
              My Assessment
              <span className={`${styles.greater_than_symbol} ms-1 `}>
                <TbMathGreater />
              </span>
            </h5>

            <h6 className={` ${styles.activity_log_tab}`}>Create New</h6>
          </div>
        </div>
      </div>
      <div className={`${styles.create_assessment}`}>
        <div
          className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 d-flex align-items-start ${styles.Stage}`}
        >
          <div className="row">
            <div className={`${styles.cointenerstg} col-sm-8 `}>
              <div className="row  row-cols-5">
                <div
                  className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex`}
                >
                  <span className={`${styles.numbercreate}`}>
                    <Image
                      className={`mt-3 mb-5 ${styles.customImage}`}
                      alt="#"
                      src={checkgreen}
                    />
                  </span>
                  <div className={`col ${styles.customDiv}`}>
                    <span className={`${styles.textcreatebasic}`}>
                      Basic&nbsp;Details
                    </span>
                  </div>
                </div>
                <div
                  className={`${styles.cointenerstageline} col-lg-12 col-md-12`}
                >
                  <Image
                    className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                    alt="#"
                    src={line}
                  />
                  <Image
                    className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                    alt="#"
                    src={linethree}
                  />
                </div>
                <div
                  className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex`}
                >
                  <span className={`${styles.numbercreate}`}>
                    <Image
                      className={`mt-3 mb-5 ${styles.customImage}`}
                      alt="#"
                      src={docone}
                    />
                  </span>
                  <div className={`col ${styles.customDiv}`}>
                    <span className={`${styles.textcreatebasic}`}>
                      Add&nbsp;Questions
                    </span>
                  </div>
                </div>
                <div
                  className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}
                >
                  <Image
                    className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                    alt="#"
                    src={lineone}
                  />
                  <Image
                    className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                    alt="#"
                    src={linethree}
                  />
                </div>
                <div
                  className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex`}
                >
                  <span className={`${styles.numbercreate}`}>
                    <Image
                      className={`mt-3 mb-5 ${styles.customImage}`}
                      alt="#"
                      src={documenttwo}
                    />
                  </span>
                  <div className={`col ${styles.customDiv}`}>
                    <span className={`${styles.textcreatebasic}`}>
                      Other&nbsp;Settings
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div
          className="col-xl-9 col-lg-9 col-md-9 col-sm-12 "
          style={{
            display: "flex",
            flexDirection: "column",
            backgroundColor: "white",
            padding: "1.5rem",
          }}
        >
          <div className="d-flex align-items-center justify-content-between">
            <div>
              <h5 className={styles["custom-heading"]}>All Questions</h5>
            </div>
            <div>
              <button
                className={`${styles.questionGroups}`}
                onClick={() => addQuestionPage("addquestions")}
              >
                <BsPlusSquare className="iconAdd" />
                <span className="d-none d-md-inline">Add Question</span>
              </button>
            </div>
          </div>

          <ReceiveAllQuestions assessmentId={`${assessmentId}`} />
          <div className={`${styles.ContainerAllQ}`}>
            <div className="row">
              <div className="col-lg-3 col-md-4 col-sm-4 col-6 ">
                <div className={`${styles.PreviousButtonAllQ}`}>
                  <button
                    className={`${styles.PreviousBtnset}`}
                    onClick={() => navigate("addquestions")}
                  >
                    Previous
                  </button>
                </div>
              </div>
              <div className="col-lg-9 col-md-8 col-sm-8 col-6 ">
                <div className={`${styles.btnallq}`}>
                  <button
                    className={`${styles.btnallqstn}`}
                    onClick={() => navigate("settings")}
                  >
                    {" "}
                    Next{" "}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AllQuestion;
