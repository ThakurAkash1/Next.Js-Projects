"use client";
import styles from "@/components/myassessment/AddQuestions/styles.module.css";
import documenttwo from "/public/images/Steppertwo.svg";
import checkgreen from "/public/images/GreenStepper.svg";
import docone from "/public/images/StepperNumone.svg";
import line from "/public/images/Line3.svg";
import lineone from "/public/images/Line5.svg";
import linethree from "/public/images/LInethreeStraignt.svg";
import Image from "next/image";
import { BsPlusSquare } from "react-icons/bs";
import { BsFillPenFill, BsPaperclip, BsImageFill } from "react-icons/bs";
import { MdAddToDrive, MdLockClock, MdAttachment } from "react-icons/md";
import { CgSmileMouthOpen } from "react-icons/cg";
import { RiFontColor, RiDeleteBin6Line } from "react-icons/ri";
import { TbMathGreater } from "react-icons/tb";
import React, { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { CallApi } from "@/utils/util";
import test from "node:test";
import Link from "next/link";

interface Props {}
const AddQuestions: React.FC<Props> = () => {
  const router = useRouter();
  const searchParam = useSearchParams();
  const [assessmentId, setAssessmentId] = useState<string | null>(null);
  const [allDraftQuestions, setAllDraftQuestions] = useState<any[]>([]);
  const [selectedOption, setSelectedOption] = useState("");
  const [options, setOptions] = useState([
    { id: 1, EnterOption: "", groupscore: "" },
  ]);
  const answerArray = options
    .filter((opt) => opt.groupscore !== "0")
    .map((opt) => opt.EnterOption);
  const [assessmentData, setAssessmentData] = useState<any>(null);

  const navigate = (page: string, assessmentId?: string) => {
    const id = assessmentId || searchParam.get("assessmentId");
    if (id) {
      router.push(`/myassessment/${page}?assessmentId=${id}`);
    } else {
      router.push(`/myassessment/${page}`);
    }
  };

  const query = `
    query MyQuery {
      assessmentById(id: "${assessmentId}") {
        categoryId
        createdAt
        createdBy
        description
        draftQuestions {
          answer
          createdAt
          multipleChoice
          options {
            weightage
            option
          }
          question
          questionId
          questionType
          subcategoryId
          totalWeightage
          updatedAt
        }
        duration
        id
        name
        perQuestionDuration
        status
        testLanguage
        thumbnailImg
        totalScore
        updatedAt
      }
    }
  `;

  useEffect(() => {
    const id = searchParam.get("assessmentId");
    setAssessmentId(id);

    const fetchData = async () => {
      try {
        console.log("Fetching data for assessmentId:", id);

        const response = await CallApi({ query: query, token: "" });
        console.log("API response:", response);

        const assessmentData = response.data?.assessmentById;

        // Ensure assessmentData is not null
        if (assessmentData) {
          setAssessmentData(assessmentData);
          setAllDraftQuestions(assessmentData.draftQuestions || []);
        } else {
          console.log("No assessment data found");
        }
      } catch (error) {
        console.error("Error:", error);
      }
    };

    if (query && id) {
      fetchData();
    }
  }, [query, searchParam]);

  const handleAddOption = () => {
    setOptions((prevOptions) => [
      ...prevOptions,
      { id: prevOptions.length + 1, EnterOption: "", groupscore: "" },
    ]);
  };

  const handleDeleteOption = (id: number) => {
    setOptions((prevOptions) =>
      prevOptions.filter((option) => option.id !== id)
    );
  };

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = event.target;
    setFormData((prevState) => ({
      ...prevState,
      draftQuestions: prevState.draftQuestions.map((question, index) =>
        index === 0 ? { ...question, [id]: value } : question
      ),
    }));
  };

  const handleOptionInputChange = (
    index: number,
    field: string,
    value: string
  ) => {
    setOptions((prevOptions) =>
      prevOptions.map((option, i) =>
        i === index ? { ...option, [field]: value } : option
      )
    );
  };

  const [formData, setFormData] = useState({
    draftQuestions: [
      {
        question: "",
        questionType: "",
        options: [
          {
            option: "",
            weightage: "",
          },
        ],
      },
    ],
  });

  const mutationQuery = `
    mutation {
      updateAssessmentDetails(id: "${assessmentId}", assessmentInput: {
        name: "${assessmentData?.name}",
        description: "${assessmentData?.description}",
        testLanguage: "${assessmentData?.testLanguage}",
        categoryId: "ffe30c36-5170-44d2-bd1c-f7ca87f7eb57",
        totalScore: 500.00,
        draftQuestions: [
          ${allDraftQuestions
            .map(
              (question) => `{
              questionId: "${question.questionId || ""}",
              subcategoryId: "${question.subcategoryId || ""}",
              question: "${question.question || ""}",
              questionType: "${question.questionType || ""}",
              multipleChoice: ${
                question.multipleChoice !== undefined
                  ? question.multipleChoice
                  : false
              },
              totalWeightage: ${question.totalWeightage || 1.0},
              answer: ${JSON.stringify(question.answer || [])},
              options: [
                ${question.options
                  .map(
                    (opt: { option: any; weightage: any }) => `{
                    option: "${opt.option || ""}",
                    weightage: ${opt.weightage || 0}
                  }`
                  )
                  .join(",\n")}
              ]    
            }`
            )
            .join(",\n")}
          ${formData.draftQuestions
            .map(
              (question) => `{
              questionId: "",
              subcategoryId: "",
              question: "${question.question || ""}",
              questionType: "${question.questionType || selectedOption}",
              multipleChoice: ${
                options.filter((opt) => opt.groupscore !== "0").length > 1
                  ? "true"
                  : "false"
              },
              totalWeightage: ${options.reduce(
                (totalSum, { groupscore }) =>
                  totalSum +
                  groupscore.split(",").reduce((a, b) => a + Number(b), 0),
                0
              )},
              answer: ${JSON.stringify(answerArray)},
              options: [
                ${options
                  .map(
                    (opt) => `{
                    option: "${opt.EnterOption}",
                    weightage: ${opt.groupscore || 0}
                  }`
                  )
                  .join(",\n")}
              ]    
            }`
            )
            .join(",\n")}
        ],
        thumbnailImg: "${assessmentData?.thumbnailImg}",
        perQuestionDuration: "3",
        duration: "60",
        status: "draft",
        subCategoryId: "663b1b5063027d7a5be9a1f1",
        createdBy: "${assessmentData?.createdBy}"
      }) {
        name
        description
        testLanguage
        id
        draftQuestions {
          questionId
          question
          questionType
          answer
          options {
            option
            weightage
          }
        }
      }
    }
  `;

  const callApi = async (mutationQuery: string) => {
    try {
      const response = await CallApi({ query: mutationQuery, token: "" });

      if (
        !response ||
        !response.data ||
        !response.data.updateAssessmentDetails ||
        !response.data.updateAssessmentDetails?.id
      ) {
        throw new Error("Invalid response structure");
      }

      const id = response.data.updateAssessmentDetails.id;
      setAssessmentId(id);
      return id;
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.draftQuestions[0].question) {
      alert("Please fill in all required fields.");
    } else {
      try {
        setAllDraftQuestions((prev) => prev.concat(formData.draftQuestions));
        const id = await callApi(mutationQuery);
        setFormData({
          draftQuestions: [
            {
              question: "",
              questionType: "",
              options: [
                {
                  option: "",
                  weightage: "",
                },
              ],
            },
          ],
        });
        setSelectedOption("");
        setOptions([{ id: 1, EnterOption: "", groupscore: "" }]);
        router.push(`/myassessment/addquestionassessment?assessmentId=${id}`);
      } catch (error) {
        console.error("Error:", error);
      }
    }
  };

  const saveandexit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.draftQuestions[0].question) {
      alert("Please fill in all required fields.");
    } else {
      try {
        setAllDraftQuestions((prev) => prev.concat(formData.draftQuestions));
        const id = await callApi(mutationQuery);
        setSelectedOption("");
        setOptions([{ id: 1, EnterOption: "", groupscore: "" }]);
        router.push(`/myassessment/allquestion?assessmentId=${id}`);
      } catch (error) {
        console.error("Error:", error);
      }
    }
  };

  return (
    <div className={` h-100 w-99 d-flex flex-column`}>
      <form>
        <div className={`${styles.total_card} row`}>
          <div className="d-flex gap-3 align-content-center justify-content-start">
            <div className="d-flex gap-2 align-items-center justify-content-center ">
              <h5 className={` h6 text-dark d-none d-md-block`}>
                Create Assessment
              </h5>
            </div>
            <div className="d-flex gap-2 align-items-center justify-content-center">
              <h5
                className={`${styles.reports_tab} ${styles.myAssessment}`}
                onClick={() => navigate("newassessment")}
              >
                My Assessment
                <span className={`${styles.greater_than_symbol} ms-1 `}>
                  <TbMathGreater />
                </span>
              </h5>

              <h6 className={` ${styles.activity_log_tab}`}>Create New</h6>
            </div>
          </div>
        </div>
        <div className={`${styles.create_assessment}`}>
          <div
            className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 d-flex align-items-start ${styles.Stage}`}
          >
            <div className="row">
              <div className={`${styles.cointenerstg} col-sm-8 `}>
                <div className="row  row-cols-4">
                  {/* Stage 1 */}
                  <div
                    className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={checkgreen}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Basic&nbsp;Details
                      </span>
                    </div>
                  </div>
                  <div
                    className={`${styles.cointenerstageline} col-lg-12 col-md-12`}
                  >
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                      alt="#"
                      src={line}
                    />
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                      alt="#"
                      src={linethree}
                    />
                  </div>
                  {/* Stage 2 */}
                  <div
                    className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={docone}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Add&nbsp;Questions
                      </span>
                    </div>
                  </div>
                  <div
                    className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}
                  >
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                      alt="#"
                      src={lineone}
                    />
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                      alt="#"
                      src={linethree}
                    />
                  </div>
                  {/* Stage 3 */}
                  <div
                    className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={documenttwo}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Other&nbsp;Settings
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="col-xl-9 col-lg-9 col-md-9 col-sm-12"
            style={{
              display: "flex",
              flexDirection: "column",
              backgroundColor: "white",
              padding: "1.5rem",
            }}
          >
            <div className={`row mt-4 ${styles.scrollableRow}`}>
              <div className="col-12">
                <div className={`${styles.MessageboxAdd}`}>
                  <div className={`${styles.AddQuestionTitle} ml-4 mt-2`}>
                    <h5>Add Questions</h5>
                  </div>
                  <h2 className={`${styles.headingQuestion}`}>Question 1</h2>
                  <div className={`${styles.fomgrpquestion}`}>
                    <label htmlFor="question">Enter Question</label>
                    <input
                      type="text"
                      placeholder="Enter your question"
                      id="question"
                      className={`${styles.formcontrolquestion}`}
                      value={formData.draftQuestions[0].question}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
              </div>
              <div className="col-12">
                <div className={`${styles.grouptitile}`}>
                  <label htmlFor="subCategory">SubCategory</label>
                  <select
                    id="subCategory"
                    className={`${styles.groupOption}`}
                    // value={formData.group}
                    // onChange={handleInputChange}
                  >
                    <option value="" hidden>
                      Select
                    </option>
                    <option value="Developer">Frontend</option>
                    <option value="Infra Team">Backend</option>
                    <option value="Backend">HR</option>
                    <option value="Finance">Account</option>
                    <option value="Design">UI/UX</option>
                  </select>
                </div>
              </div>
              <div className="col-12">
                <div className={`${styles.fomgrpquestionone} col-12`}>
                  <label htmlFor="questionType">Answer Type</label>
                  <select
                    id="questionType"
                    className={`${styles.formcontrolquestionone}`}
                    value={selectedOption}
                    onChange={(e) => {
                      setSelectedOption(e.target.value);
                      setOptions([{ id: 1, EnterOption: "", groupscore: "" }]);
                    }}
                    required
                  >
                    <option value="select" hidden>
                      Select
                    </option>
                    <option value="multiple-choice">Multiple Choice</option>
                    <option value="true-false">True/False</option>
                    <option value="textual">Textual</option>
                  </select>

                  {selectedOption === "multiple-choice" && (
                    <div
                      id="multiple-choice"
                      className={styles.contentdropdown}
                    >
                      <div className="col ml-4 mt-3">
                        <h6>
                          Select the correct answer and mention score for each
                          correct answer
                        </h6>
                      </div>
                      <div className="row">
                        {options.map((option, index) => (
                          <div
                            className="col-lg-6 col-md-6 col-sm-12 mt-2"
                            key={index}
                          >
                            {index >= 2 && (
                              <div
                                className={`${styles.DeleteOne} `}
                                onClick={() => handleDeleteOption(index)}
                              >
                                <RiDeleteBin6Line />
                              </div>
                            )}
                            <div className={`${styles.checkBox}`}>
                              <input
                                type="checkbox"
                                className={`${styles.CheckOne}`}
                                checked={Number(option.groupscore) > 0} // Check if score is more than zero
                                onChange={(e) => {
                                  const newScore = e.target.checked
                                    ? option.groupscore
                                    : "0"; // Example logic to toggle score
                                  handleOptionInputChange(
                                    index,
                                    "groupscore",
                                    newScore.toString()
                                  );
                                }}
                              />
                            </div>
                            <div
                              className={`question-box ${styles["question-box"]}`}
                            >
                              <textarea
                                id={`EnterOption_${index}`}
                                className={`${styles.Textelement}`}
                                value={option.EnterOption}
                                onChange={(e) =>
                                  handleOptionInputChange(
                                    index,
                                    "EnterOption",
                                    e.target.value
                                  )
                                }
                              />
                              <div className={`${styles.groupIcons}`}>
                                <RiFontColor />
                                <BsPaperclip />
                                <MdAttachment />
                                <CgSmileMouthOpen />
                                <MdAddToDrive />
                                <BsImageFill />
                                <MdLockClock />
                                <BsFillPenFill />
                              </div>
                            </div>
                            <div className={`col-sm ${styles.Scoreone}`}>
                              <label htmlFor="group">Score:</label>
                              <input
                                type="text"
                                id={`groupscore_${index}`}
                                className={`${styles.formsropeone}`}
                                value={option.groupscore}
                                onChange={(e) =>
                                  handleOptionInputChange(
                                    index,
                                    "groupscore",
                                    e.target.value
                                  )
                                }
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="col-12">
                        <div className={`${styles.Addoption} mt-4 mb-2`}>
                          <button
                            type="button"
                            className={`${styles.Addoptionbutton}`}
                            onClick={handleAddOption}
                          >
                            <BsPlusSquare className={`${styles.iconoption}`} />{" "}
                            Add Option
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                  {selectedOption === "true-false" && (
                    <div className={`${styles.textualDropdown}`}>
                      <h6>Select the correct option </h6>
                      <div className="row ">
                        {/* Options */}
                        {options.map((option, index) => (
                          <div
                            className="col-lg-6 col-md-6 col-sm-12"
                            key={index}
                          >
                            <div className={`${styles.checkBox}`}>
                              <input
                                type="radio"
                                className={`${styles.CheckOne}`}
                              />
                            </div>
                            <div
                              className={`question-boxarea ${styles["question-boxarea"]}`}
                            >
                              <textarea
                                id={`EnterOption_${index}`}
                                className={`${styles.Textelementarea}`}
                                value={option.EnterOption}
                                onChange={(e) =>
                                  handleOptionInputChange(
                                    index,
                                    "EnterOption",
                                    e.target.value
                                  )
                                }
                              />
                              <div className={`${styles.groupIcons}`}>
                                <RiFontColor />
                                <BsPaperclip />
                                <MdAttachment />
                                <CgSmileMouthOpen />
                                <MdAddToDrive />
                                <BsImageFill />
                                <MdLockClock />
                                <BsFillPenFill />
                              </div>
                            </div>
                          </div>
                        ))}
                        {/* Options */}
                        {/* {options.map((option, index) => ( */}
                        <div className="col-lg-6 col-md-6 col-sm-12">
                          <div className={`${styles.checkBox}`}>
                            <input
                              type="radio"
                              className={`${styles.Checktwo}`}
                            />
                          </div>
                          <div
                            className={`question-boxareaone ${styles["question-boxareaone"]}`}
                          >
                            <textarea
                              // id={`EnterOption_${index}`}
                              className={`${styles.Textelementarea}`}
                              // value={option.EnterOption}
                              // onChange={(e) =>
                              //   handleOptionInputChange(
                              //     index,
                              //     "EnterOption",
                              //     e.target.value
                              //   )
                              // }
                            />
                            <div className={`${styles.groupIcons}`}>
                              <RiFontColor />
                              <BsPaperclip />
                              <MdAttachment />
                              <CgSmileMouthOpen />
                              <MdAddToDrive />
                              <BsImageFill />
                              <MdLockClock />
                              <BsFillPenFill />
                            </div>
                          </div>
                        </div>
                        {/* ))} */}
                      </div>
                    </div>
                  )}
                  {selectedOption === "textual" && (
                    <div id="textual" className={styles.contentdropdown}>
                      <div className="col ml-4 mt-3">
                        <h6>Enter Answer below</h6>
                      </div>
                      <div className="row row-col-12">
                        {options.map((option, index) => (
                          <div className="col-12" key={index}>
                            <div className={`${styles.Textualbox}`}>
                              <textarea
                                placeholder="Add possible answer to the question"
                                id="textBox"
                                className="form-control"
                                value={option.EnterOption}
                                onChange={(e) =>
                                  handleOptionInputChange(
                                    index,
                                    "EnterOption",
                                    e.target.value
                                  )
                                }
                                style={{ height: "130px" }}
                              ></textarea>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className={`${styles.ContainerAddQ}`}>
              <div
                className={` ${styles.footer} d-grid grid-template-columns-auto gap-3`}
              >
                <div>
                  <div className={`${styles.PreviousButton}`}>
                    <button
                      className={`${styles.PreviousBtn}`}
                      onClick={() => navigate("createassessment")}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
                <div>
                  <div className={`${styles.nextBtnn}`}>
                    <button
                      className={`${styles.nextbuttonn}`}
                      onClick={(e) => {
                        saveandexit(e);
                      }}
                    >
                      Save and exit
                    </button>
                  </div>
                </div>
                <div>
                  <div className={`${styles.nextBtnnone}`}>
                    <button
                      className={`${styles.nextbuttonnone}`}
                      onClick={(e) => {
                        handleSubmit(e);
                      }}
                    >
                      Save and add next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddQuestions;
