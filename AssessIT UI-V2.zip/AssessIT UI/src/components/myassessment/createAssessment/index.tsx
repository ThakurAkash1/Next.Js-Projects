"use client";
import React, { useState } from "react";
import styles from "@/components/myassessment/createassessment/styles.module.css";
import Image from "next/image";
import document from "/public/images/StepperNum.svg";
import documentone from "/public/images/Stepperone.svg";
import documenttwo from "/public/images/Steppertwo.svg";
import line from "/public/images/Line3.svg";
import linethree from "/public/images/LInethreeStraignt.svg";
import lineone from "/public/images/Line5.svg";
import { BsPlusSquare } from "react-icons/bs";
import { TbMathGreater } from "react-icons/tb";
import uploadimgage from "/public/images/uploadimg.svg";
import { useRouter } from "next/navigation";
import { CallApi } from "@/utils/util";
import { useSession } from "next-auth/react";
const jwt = require("jsonwebtoken");

interface FormData {
  assessmentName: string;
  description: string;
  thumbnailImg: string;
  language: string;
}

interface Props {
  step: number;
  stepChange: (step: number, id?: string | null) => void;
  onGetId: (id: string | null) => void;
}

const CreateAssessment: React.FC = () => {
  const { data: session, status } = useSession();
  const router = useRouter();
  const navigate = (page: String) => {
    router.push("/myassessment/" + page);
  };

  // Example token from your session object
  const token = session?.user?.access_token;

  function decodeToken(token: any) {
    try {
      const decoded = jwt.decode(token);
      return decoded.name; // or decoded.preferred_username, depending on what field you want
    } catch (error) {
      console.error("Error decoding token:", error);
      return null;
    }
  }

  const createdBy = decodeToken(token);

  // var getId
  const [assessmentId, setAssessmentId] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    categoryId: "",
    totalScore: "",
    draftQuestions: [
      {
        questionId: "",
        subcategoryId: "",
        question: "",
        questionType: "",
        multipleChoice: true,
        totalWeightage: 1.5,
        answer: "",
        options: {
          option: "",
          weightage: "",
        },
      },
    ],
    testLanguage: "",
    thumbnailImg: "",
    perQuestionDuration: "",
    duration: "",
    status: "",
    subCategoryId: "",
    createdBy: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }));
  };

  const mutationQuery = `
  mutation {
    addAssessment(assessmentInput: {
      name: "${formData.name}",
      description: "${formData.description}",
      testLanguage: "${formData.testLanguage}",
      categoryId: "ffe30c36-5170-44d2-bd1c-f7ca87f7eb57",
      totalScore: 500.00,
      draftQuestions: [{
        questionId: "",
        subcategoryId: "663b1b5063027d7a5be9a1f1",
        question: "Test Question",
        questionType: "textual",
        multipleChoice: true,
        totalWeightage: 1.5,
        answer: "java",
        options: {
          option: "folk",
          weightage: 1.5
        }
      }],
      thumbnailImg: "${formData.thumbnailImg}",
      perQuestionDuration: "3",
      duration: "60",
      status: "published",
      subCategoryId: "663b1b5063027d7a5be9a1f1",
      createdBy: "${createdBy}"
    }) {
      name
      description
      testLanguage
      thumbnailImg
      id
      createdBy
    }
  }
`;

  const callApi = async (mutationQuery: string) => {
    try {
      const response = await CallApi({ query: mutationQuery, token: "" });
      console.log("Response:", response);

      const id = response.data.addAssessment.id;
      setAssessmentId(id);
      console.log("ID:>>>>>>>>>>>", id);

      console.log("ID:", id);

      return id;
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  const handlesubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.description || !formData.testLanguage) {
      alert("Please fill in all required fields.");
    } else {
      try {
        const id = await callApi(mutationQuery);
        router.push(`/myassessment/addquestionassessment?assessmentId=${id}`);
      } catch (error) {
        console.error("Error:", error);
      }
    }
  };
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isHovered, setIsHovered] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setSelectedImage(base64String);
        setFormData((prevData) => ({
          ...prevData,
          thumbnailImg: base64String,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  return (
    <div className={` h-100 w-99 d-flex flex-column`}>
      <form>
        <div className={`${styles.total_card} row`}>
          <div className="d-flex gap-3 align-items-center justify-content-start">
            <div className="d-flex gap-2 align-items-center justify-content-center ">
              <h5 className={` h6 text-dark d-none d-md-block`}>
                Create Assessment
              </h5>
            </div>
            <div className="d-flex gap-2 align-items-center justify-content-center">
              <h5
                className={`${styles.reports_tab} ${styles.myAssessment}`}
                onClick={() => navigate("newassessment")}
              >
                My Assessment
                <span className={`${styles.greater_than_symbol} ms-1 `}>
                  <TbMathGreater />
                </span>
              </h5>

              <h6 className={` ${styles.activity_log_tab}`}>Create New</h6>
            </div>
          </div>
        </div>
        <div className={`row ${styles.create_assessment}`}>
          <div
            className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 d-flex align-items-start  ${styles.Stage}`}
          >
            <div className="row">
              <div className={`${styles.cointenerstg} col-sm-8 `}>
                <div className="row  row-cols-5">
                  <div
                    className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={document}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Basic Details
                      </span>
                    </div>
                  </div>
                  <div
                    className={`${styles.cointenerstageline} col-lg-12 col-md-12`}
                  >
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                      alt="#"
                      src={line}
                    />
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                      alt="#"
                      src={linethree}
                    />
                  </div>
                  <div
                    className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={documentone}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Add Questions
                      </span>
                    </div>
                  </div>
                  <div
                    className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}
                  >
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                      alt="#"
                      src={lineone}
                    />
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                      alt="#"
                      src={linethree}
                    />
                  </div>
                  <div
                    className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={documenttwo}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Other Settings
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="col-xl-9 col-lg-9 col-md-9 col-sm-12"
            style={{
              display: "flex",
              flexDirection: "column",
              backgroundColor: "white",
              height: "fit-content",
              padding: "1.5rem",
            }}
          >
            <div className={`${styles.PassdataCreate}`}>
              <div
                className={`col-12 mt-2 d-none d-md-block ${styles.headertitle}`}
              >
                <label>Basic Details</label>
              </div>
              <div className="row mt-4 ">
                <div className="col-md-8 h-15 ">
                  <div className={`${styles.fomgroupcreate}`}>
                    <label htmlFor="assessmentName">Assessment Name</label>
                    <input
                      type="text"
                      placeholder="Enter Name"
                      id="name"
                      className={`${styles.formcontrolname}`}
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="col d-lg-none d-md-none  mx-auto">
                  <div
                    className={`${styles.Uploadimg} ${styles.dashedBorder}`}
                    onMouseEnter={handleMouseEnter}
                    onMouseLeave={handleMouseLeave}
                  >
                    <div
                      className={`${styles.Uploadimg} d-flex flex-column align-items-center`}
                    >
                      {selectedImage && !isHovered ? (
                        <img
                          className={`${styles.uploadedImage} mt-1 mb-2`}
                          alt="#"
                          src={selectedImage || undefined}
                        />
                      ) : (
                        <>
                          <label htmlFor="fileInput" className="mt-5 mb-2">
                            <Image alt="#" src={uploadimgage} />
                          </label>
                          <div
                            className={`${styles.Uploadimgtxt} text-center mt-5`}
                          >
                            <h6 className={`${styles.UploadimgTitle}`}>
                              Upload Thumbnail
                            </h6>
                            <p className={`${styles.UploadimgDesc}`}>
                              Supported formats: JPEG, PNG
                            </p>
                          </div>
                        </>
                      )}
                      <input
                        id="fileInput"
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        style={{ display: "none" }}
                      />
                    </div>
                  </div>
                </div>

                <div className={`col-md-8 h-65 mt-2 ${styles.UploadDesc}`}>
                  <div>
                    <label htmlFor="description">Description</label>
                    <textarea
                      id="description"
                      placeholder="Lorem ipsum dolor sit amet"
                      className={`${styles.formcontrol}`}
                      //   rows="4"
                      value={formData.description}
                      onChange={handleInputChange}
                      required
                    ></textarea>
                  </div>
                </div>
                <div className="col d-none d-md-block">
                  <div
                    className={`${styles.Uploadimg} ${styles.dashedBorder}`}
                    onMouseEnter={handleMouseEnter}
                    onMouseLeave={handleMouseLeave}
                  >
                    <div
                      className={`${styles.Uploadimg} d-flex flex-column align-items-center`}
                    >
                      {selectedImage && !isHovered ? (
                        <img
                          className={`${styles.uploadedImage} mt-1 mb-2`}
                          alt="#"
                          src={selectedImage || undefined}
                        />
                      ) : (
                        <>
                          <label htmlFor="fileInput" className="mt-5 mb-2">
                            <Image alt="#" src={uploadimgage} />
                          </label>
                          <div
                            className={`${styles.Uploadimgtxt} text-center mt-5`}
                          >
                            <h6 className={`${styles.UploadimgTitle}`}>
                              Upload Thumbnail
                            </h6>
                            <p className={`${styles.UploadimgDesc}`}>
                              Supported formats: JPEG, PNG
                            </p>
                          </div>
                        </>
                      )}
                      <input
                        id="fileInput"
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        style={{ display: "none" }}
                      />
                    </div>
                  </div>
                </div>

                <div className="col-md-8  h-85">
                  <div className={`${styles.grouptitile}`}>
                    <label htmlFor="category">Category</label>
                    <select
                      id="category"
                      className={`${styles.groupOption}`}
                      // value={formData.group}
                      // onChange={handleInputChange}
                      required
                    >
                      <option value="" hidden>
                        Select
                      </option>
                      <option value="Developer">Development</option>
                      <option value="Infra Team">Infra Team</option>
                      <option value="Backend">Backend</option>
                      <option value="Finance">Finance</option>
                      <option value="Design">Design</option>
                    </select>
                  </div>
                </div>
                <div className={` col-md-4 h-85 ${styles.Creategroupbtn}`}>
                  <button className={`${styles.CreateGroup}`}>
                    <BsPlusSquare className={`${styles.iconCreate}`} />
                    Create Category
                  </button>
                </div>
                <div className="col-md-12 h-50">
                  <div className={`${styles.formgrouptext}`}>
                    <label htmlFor="language">Text Language</label>
                    <select
                      id="testLanguage"
                      className={`${styles.formlanguage}`}
                      value={formData.testLanguage}
                      onChange={handleInputChange}
                      required
                    >
                      <option value="" hidden>
                        Select
                      </option>
                      <option value="English">English</option>
                      <option value="Hindi">Hindi</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div className="container">
              <div className="row">
                <div className={`col-md-12 ${styles.createbtnnext}`}>
                  {/* <Link href='/myassessment/addQuestionAssessment'> */}
                  <button
                    id="btnbox1"
                    className={`${styles.createnextbutton}`}
                    onClick={(e) => handlesubmit(e)}
                  >
                    Next
                  </button>
                  {/* </Link> */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default CreateAssessment;
