"use client";
import React, { useState, useEffect } from "react";
import styles from "@/components/myassessment/allQuestionDetails/styles.module.css";
import Image from "next/image";
import uploadimgage from "/public/images/uploadimg.svg";
import { BsPlusSquare, BsPencil } from "react-icons/bs";
import { TbMathGreater } from "react-icons/tb";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
// import AssessmentMobileSideBar from './AssessmentMobileSideBar';
import { BiDotsVerticalRounded } from "react-icons/bi";
import { useSession } from "next-auth/react";
import ReceiveAllQuestions from "../receiveAllQuestions";
import { useRouter, useSearchParams } from "next/navigation";

interface AllQuestionDetailsProps {
  // step: number;
  // setStep: React.Dispatch<React.SetStateAction<number>>;
  // assessmentId: string;
  // question: any; // Adjust the type for 'question' based on your needs
  // receivedQuestions: any[]; // Adjust the type for 'receivedQuestions' based on your needs
}

const AllQuestionDetails: React.FC<AllQuestionDetailsProps> = (props) => {
  const searchParam = useSearchParams();
  const [assessmentId, setAssessmentId] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const id = searchParam.get("assessmentId");
    console.log("assessmentID all", id);
    setAssessmentId(id);
  }, [searchParam]);

  const navigate = (page: String) => {
    router.push("/myassessment/" + page);
  };

  const addQuestionDetails = (page: String) => {
    router.push("/myassessment/" + page + "?assessmentId=" + assessmentId);
  };

  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const handleNewButtonClick = () => {
    setSidebarOpen(!isSidebarOpen);
  };
  const handleOutsideClick = () => {
    setSidebarOpen(false);
  };
  const settingsDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Add any additional logic or API calls here
      router.push(`/myassessment/settingdetails?assessmentId=${assessmentId}`);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const basicDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Add any additional logic or API calls here
      router.push(`/myassessment/basicdetails?id=${assessmentId}`);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div
      className={`h-100 w-99 d-flex flex-column`}
      onBlur={handleOutsideClick}
    >
      <form onSubmit={(e) => e.preventDefault()}>
        <div className={`${styles.total_card} row `}>
          <div className="d-flex gap-3 align-items-center justify-content-start">
            <div className="d-flex gap-2 align-items-center justify-content-center ">
              <h5 className={` h6 text-dark d-none d-md-block`}>Test</h5>
            </div>

            <div className="d-flex gap-2 align-items-center justify-content-center">
              <h5
                className={`${styles.reports_tab} ${styles.myAssessment}`}
                onClick={() => navigate("newassessment")}
              >
                My Assessment
                <span className={`${styles.greater_than_symbol} ms-1 `}>
                  <TbMathGreater />
                </span>
              </h5>
              <h6 className={` ${styles.activity_log_tab}`}>
                Assessment Details
              </h6>
            </div>
          </div>
        </div>
        <div className={`row ${styles.create_assessment}`}>
          <div className="col-3 d-none d-md-block">
            <div className={`${styles.DetailsOptions}`}>
              <div className="d-flex  flex-column justify-content-between">
                <div
                  className="p-3"
                  onClick={(e) => {
                    basicDetails(e);
                  }}
                >
                  Basic Details
                </div>
                <div className="d-flex align-items-center">
                  <div className={`${styles.Detailbox}`}>
                    <div className={`${styles.Detailboxtext}`}>Questions</div>
                  </div>
                  <div className={`${styles.VerticalLine}`}></div>
                </div>
                <div
                  className="p-3"
                  onClick={(e) => {
                    settingsDetails(e);
                  }}
                >
                  Settings
                </div>
                <div
                  className="p-3"
                  //   onClick={() => props.stepChange(props.step + 2)}
                >
                  Result&nbsp;Table
                </div>
              </div>
            </div>
          </div>
          <div
            className={`col-9 d-flex flex-column bg-white ${styles.Detailsdata}`}
          >
            <div className="d-flex  align-items-center justify-content-between">
              <div className="col-6 mt-2">
                <div className="d-flex align-items-center ">
                  <div
                    className={`${styles.DetailSidebar} d-lg-none d-md-none`}
                  >
                    <>
                      <button
                        className={`${styles.btnnewDraftarrow} me-2`}
                        onClick={handleNewButtonClick}
                      >
                        <MdOutlineKeyboardDoubleArrowRight
                          className={`${styles.iconArrorw}`}
                        />
                      </button>
                    </>
                  </div>
                  <h5 className={styles["custom-heading"]}>All Questions</h5>
                </div>
              </div>
              <div className="col-6 d-flex  justify-content-end">
                {/* <div className={`mr-4 mt-2 ${styles.questionContainer}`}> */}
                {/* <div className={`${styles.questionTextdiv}`}> */}
                <button
                  type="button"
                  className={`${styles.questionGroups}`}
                  onClick={() => addQuestionDetails("addquestions")}
                >
                  <div>
                    <BsPlusSquare className="iconAdd" />
                  </div>
                  <div className="d-none d-md-inline text-dark">
                    Add Question
                  </div>
                </button>
                {/* </div> */}
              </div>
            </div>
            <ReceiveAllQuestions assessmentId={`${assessmentId}`} />
          </div>
        </div>
      </form>
    </div>
  );
};

export default AllQuestionDetails;
