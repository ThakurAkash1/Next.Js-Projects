"use client";
import React, { useState, useEffect, ChangeEvent } from "react";
import styles from "@/components/myassessment/Settings/styles.module.css";
import Image from "next/image";
import checkgreen from "/public/images/GreenStepper.svg";
import doctwo from "/public/images/StepperNumtwo.svg";
import line from "/public/images/Line3.svg";
import lineone from "/public/images/Line5.svg";
import linethree from "/public/images/LInethreeStraignt.svg";
import success from "../../../../public/images/success.svg";
import { TbMathGreater } from "react-icons/tb";
import { BsExclamationCircle } from "react-icons/bs";
import { MdOutlineCopyAll } from "react-icons/md";
import { useSession } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import { CallApi } from "@/utils/util";

interface Props {
  // assessmentId: string;
  // onGetId: (id: string) => void;
  // step: number;
  // stepChange: (step: number) => void;
}

interface FormData {
  duration: string;
  perQuestionDuration: string;

  // Add other fields as needed
}

const Settings: React.FC<Props> = (props) => {
  const router = useRouter();
  const [showPopup, setShowPopup] = useState(false);
  const searchParam = useSearchParams();
  const [assessmentId, setAssessmentId] = useState<string | null>(null);

  const navigate = (page: String) => {
    router.push("/myassessment/" + page);
  };

  const allQuestionPage = (page: String) => {
    router.push("/myassessment/" + page + "?assessmentId=" + assessmentId);
  };

  const [options, setOptions] = useState([
    { id: 1, EnterOption: "", groupscore: "" },
  ]);

  const [status, setStatus] = useState<string | null>(null);

  //   const { data: session } = useSession();
  const [selectedOption, setSelectedOption] = useState("");

  const handleRadioChange = (event: any) => {
    setSelectedOption(event.target.value);
  };

  const [assessmentTime, setAssessmentTime] = useState("");
  const [questionTime, setQuestionTime] = useState("");
  const [timer, setTimer] = useState(0);
  const [isValidDuration, setIsValidDuration] = useState<boolean>(true);
  const [isValidPerQuestionDuration, setIsValidPerQuestionDuration] =
    useState<boolean>(true);

  const [assessmentData, setAssessmentData] = useState<any>(null);

  const query = `
  query MyQuery {
    assessmentById(id: "${assessmentId}") {
      categoryId
      createdAt
      createdBy
      description
      draftQuestions {
        answer
        createdAt
        multipleChoice
        options {
          weightage
          option
        }
        question
        questionId
        questionType
        subcategoryId
        totalWeightage
        updatedAt
      }
      duration
      id
      name
      perQuestionDuration
      status
      testLanguage
      thumbnailImg
      totalScore
      updatedAt
    }
  }
  `;
  useEffect(() => {
    const id = searchParam.get("assessmentId");
    console.log("assessmentID", id);
    setAssessmentId(id);

    const fetchData = async () => {
      try {
        const response = await CallApi({ query: query, token: "" });
        console.log("Response:", response);

        const assessmentData = response.data.assessmentById;

        setAssessmentData(assessmentData);
        console.log("Assessment Data:", assessmentData);
      } catch (error) {
        console.error("Error:", error);
        // Handle errors gracefully
      }
    };

    if (query && id) {
      // Check if both query and id are available
      fetchData();
    }
  }, [query, searchParam]);

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    categoryId: "",
    totalScore: "",
    draftQuestions: [
      {
        questionId: "",
        subcategoryId: "",
        question: "",
        questionType: "",
        multipleChoice: true,
        totalWeightage: 1.0,
        answer: [],
        options: [
          {
            option: "",
            weightage: "",
          },
        ],
      },
    ],
    testLanguage: "",
    thumbnailImg: "",
    perQuestionDuration: "",
    duration: "",
    status: "",
    subCategoryId: "",
    createdBy: "",
  });

  const callApi = async (mutationQuery: string) => {
    try {
      const response = await CallApi({ query: mutationQuery, token: "" });
      console.log("Response:", response);

      if (
        !response ||
        !response.data ||
        !response.data.updateAssessmentDetails ||
        !response.data.updateAssessmentDetails?.id
      ) {
        throw new Error("Invalid response structure");
      }

      const id = response.data.updateAssessmentDetails.id;
      setAssessmentId(id);
      console.log("ID:>>>>>>>>>>>", id);

      // console.log("ID:", id)

      return id;
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  const handlesubmit = async (e: React.FormEvent, action: string) => {
    e.preventDefault(); // Prevent default form submission

    try {
      const updatedStatus = action === "publish" ? "PUBLISHED" : "DRAFT";
      setStatus(updatedStatus);
      console.log(updatedStatus);

      const mutationQuery = `
      mutation {
        updateAssessmentDetails(id: "${assessmentId}", assessmentInput: {
          name: "${assessmentData?.name}",
          description: "${assessmentData?.description}",
          testLanguage: "${assessmentData?.testLanguage}",
          categoryId: "ffe30c36-5170-44d2-bd1c-f7ca87f7eb57",
          totalScore: 500.00,
          draftQuestions: [
            ${assessmentData?.draftQuestions
              .map(
                (question: any) => `{
                questionId: "${question.questionId || ""}",
                subcategoryId: "${question.subcategoryId || ""}",
                question: "${question.question || ""}",
                questionType: "${question.questionType || ""}",
                multipleChoice: ${
                  question.multipleChoice !== undefined
                    ? question.multipleChoice
                    : false
                },
                totalWeightage: ${question.totalWeightage || 1.0},
                answer: ${JSON.stringify(question.answer || [])},
                options: [
                  ${question.options
                    .map(
                      (opt: any) => `{
                        option: "${opt.option || ""}",
                        weightage: ${opt.weightage || 0}
                      }`
                    )
                    .join(",\n")}
                ]
              }`
              )
              .join(",\n")}
          ],
          thumbnailImg: "${assessmentData?.thumbnailImg}",
          perQuestionDuration: "${formData.perQuestionDuration}",
          duration: "${formData.duration}",
          status:"${updatedStatus}",
          subCategoryId: "663b1b5063027d7a5be9a1f1",
          createdBy: "${assessmentData?.createdBy}"
        }) {
          name
          description
          testLanguage
          id
          createdBy
          draftQuestions {
            questionId
            multipleChoice
            question
            questionType
            totalWeightage
            answer
            options {
              option
              weightage
            }
          }
        }
      }
    `;

      const id = await callApi(mutationQuery); // Your API call

      if (action === "publish") {
        setShowPopup(true);

        setTimeout(() => {
          setShowPopup(false);
          router.push(`/myassessment/newassessment`);
        }, 5000);
      } else {
        router.push(`/myassessment/newassessment`);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const handleAssessmentTimeChange = (event: ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    const timePattern = /^(?:[01]\d|2[0-3]):[0-5]\d$/;

    if (timePattern.test(value)) {
      setIsValidDuration(true);
      setFormData({
        ...formData,
        duration: value,
      });
    } else {
      setIsValidDuration(false);
      setFormData({
        ...formData,
        duration: value,
      });
    }
  };

  const handleQuestionTimeChange = (event: ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    const timePattern = /^[0-5]\d:[0-5]\d$/;

    if (timePattern.test(value)) {
      setIsValidPerQuestionDuration(true);
      setFormData({
        ...formData,
        perQuestionDuration: value,
      });
    } else {
      setIsValidPerQuestionDuration(false);
      setFormData({
        ...formData,
        perQuestionDuration: value,
      });
    }
  };

  return (
    <div className={`h-100 w-99 d-flex flex-column`}>
      <form onSubmit={(e) => handlesubmit(e, "draft")}>
        <div className={`${styles.total_card} row`}>
          <div className="d-flex gap-3 align-content-center justify-content-start">
            <div className="d-flex gap-2 align-items-center justify-content-center ">
              <h5 className={` h6 text-dark d-none d-md-block`}>
                Create Assessment
              </h5>
            </div>
            <div className="d-flex gap-2 align-items-center justify-content-center">
              <h5
                className={`${styles.reports_tab} ${styles.myAssessment}`}
                onClick={() => navigate("newassessment")}
              >
                My Assessment
                <span className={`${styles.greater_than_symbol} ms-1 `}>
                  <TbMathGreater />
                </span>
              </h5>

              <h6 className={` ${styles.activity_log_tab}`}>Create New</h6>
            </div>
          </div>
        </div>
        <div className={`${styles.create_assessment}`}>
          <div
            className={`col-sm-12 col-md-3 col-lg-3 col-xl-3 ${styles.Stage}`}
          >
            <div className="row">
              <div className={`${styles.cointenerstg} col-sm-8 `}>
                <div className="row  row-cols-5">
                  <div
                    className={`${styles.cointenerstage} col-xl-12 col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={checkgreen}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Basic&nbsp;Details
                      </span>
                    </div>
                  </div>
                  <div
                    className={`${styles.cointenerstageline} col-lg-12 col-md-12`}
                  >
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                      alt="#"
                      src={line}
                    />
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                      alt="#"
                      src={linethree}
                    />
                  </div>
                  <div
                    className={`${styles.cointenerstageone} col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={checkgreen}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Add&nbsp;Questions
                      </span>
                    </div>
                  </div>
                  <div
                    className={`${styles.cointenerstagelineone} col-lg-12 col-md-12 `}
                  >
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-none d-md-block`}
                      alt="#"
                      src={lineone}
                    />
                    <Image
                      className={`${styles.rotatedImage} mt-3 mb-5 d-lg-none d-md-none  mx-auto`}
                      alt="#"
                      src={linethree}
                    />
                  </div>
                  <div
                    className={`${styles.cointenerstagetwo} col-lg-12 col-md-12 d-flex`}
                  >
                    <span className={`${styles.numbercreate}`}>
                      <Image
                        className={`mt-3 mb-5 ${styles.customImage}`}
                        alt="#"
                        src={doctwo}
                      />
                    </span>
                    <div className={`col ${styles.customDiv}`}>
                      <span className={`${styles.textcreatebasic}`}>
                        Other&nbsp;Settings
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="col-xl-9 col-lg-9 col-md-9 col-sm-12 "
            style={{
              display: "flex",
              flexDirection: "column",
              backgroundColor: "white",
              padding: "1.5rem",
            }}
          >
            <div className="row mt-2">
              <div className="col-12">
                <div className={`${styles.Setting}`}>
                  <div className="ml-4 mt-2">
                    <h5 className="d-none d-md-block">Other settings</h5>
                  </div>
                  <h5 className={`${styles.headingSetting}`}>
                    Select test duration measuring method
                  </h5>
                </div>
              </div>
              <div className="col-12">
                <div className={`${styles.Radio}`}>
                  <div className={`${styles.Inputone} row align-items-center`}>
                    <div className="col-12 col-md-auto ">
                      <input
                        type="radio"
                        name="flexRadioDefault"
                        className={`${styles.Inputbox}`}
                        defaultChecked
                        // onChange={handleAssessmentTimeChange}
                      />
                      <label
                        className={`${styles.Inputtext} ms-2`}
                        htmlFor="duration"
                      >
                        Time to complete the assessment:
                      </label>
                    </div>
                    <div className="col-12 col-md d-flex align-items-center">
                      <input
                        id="duration"
                        type="text"
                        className={`form-control  ${styles.TextInputone}    ${styles.SmallInput}`}
                        value={formData.duration}
                        onChange={handleAssessmentTimeChange}
                      />
                      <p
                        className={`${styles.Inputparaone} align-self-center ms-2`}
                      >
                        (hh:mm)
                      </p>
                    </div>
                    {!isValidDuration && (
                      <div className="col-12">
                        <p className="text-danger">
                          Invalid time format. Please use hh:mm format.
                        </p>
                      </div>
                    )}
                  </div>

                  <div className={`${styles.Inputtwo} row align-items-center`}>
                    <div className="col-12 col-md-auto">
                      <input
                        type="radio"
                        name="flexRadioDefault"
                        className={`${styles.Inputboxone}`}
                        // onChange={handleQuestionTimeChange}
                      />
                      <label
                        className={`${styles.Inputtext} ms-2`}
                        htmlFor="perQuestionDuration"
                      >
                        Time limit for each question:
                      </label>
                    </div>

                    <div className="col-12 col-md d-flex align-items-center">
                      <input
                        id="perQuestionDuration"
                        type="text"
                        className={`form-control ${styles.TextInputone} flex-grow-auto ${styles.SmallInput}`}
                        value={formData.perQuestionDuration}
                        onChange={handleQuestionTimeChange}
                      />
                      <p
                        className={`ms-2 ${styles.Inputparaone} align-self-center`}
                      >
                        (mm:ss)
                      </p>
                    </div>
                    {!isValidPerQuestionDuration && (
                      <div className="col-12">
                        <p className="text-danger">
                          Invalid time format. Please use mm:ss format.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-12">
                  <div className={`${styles.Accesstype}`}>
                    <div className="ml-4 mt-4">
                      <h5>Access Type</h5>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-3 col-lg-2">
                  <div className="form-check form-check-inline">
                    <input
                      className="form-check-input form-check-lg"
                      type="radio"
                      name="inlineRadioOptions"
                      id="inlineRadio1"
                      value="option1"
                      checked={selectedOption === "option1"}
                      onChange={handleRadioChange}
                      defaultChecked
                    />
                    <label className={`${styles.RedioTextLine}`}>Public</label>
                  </div>
                </div>
                <div className="col-12 col-md-3 col-lg-2">
                  <div className="form-check form-check-inline">
                    <input
                      className="form-check-input form-check-lg"
                      type="radio"
                      name="inlineRadioOptions"
                      id="inlineRadio2"
                      value="option2"
                      checked={selectedOption === "option2"}
                      onChange={handleRadioChange}
                    />
                    <label className={`${styles.RedioTextLine}`}>Private</label>
                  </div>
                </div>
                <div className="col-12 col-md-6 col-lg-8">
                  <div className="form-check form-check-inline">
                    <input
                      className="form-check-input form-check-lg"
                      type="radio"
                      name="inlineRadioOptions"
                      id="inlineRadio3"
                      value="option3"
                      checked={selectedOption === "option3"}
                      onChange={handleRadioChange}
                    />
                    <label className={`${styles.RedioTextLine}`}>
                      Specific Group
                    </label>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-12">
                  {selectedOption === "option1" && (
                    <div className={`${styles.PublicRadiobtn}`}>
                      <div
                        className={`alert alert-success ${styles["custom-alert"]}`}
                        role="alert"
                      >
                        <BsExclamationCircle /> Anyone in your team can take the
                        assessment
                      </div>
                    </div>
                  )}

                  {selectedOption === "option2" && (
                    <div className={`${styles.PraivateRadiobtn} mb-2`}>
                      <div
                        className={`alert alert-success ${styles["custom-alert"]}`}
                        role="alert"
                      >
                        <BsExclamationCircle /> Anyone in your team can take the
                        assessment
                      </div>
                      <div className="row">
                        <div className="col-12 col-md-9">
                          <div
                            className={`alert alert-light ${styles["custom-alert1"]}`}
                            role="alert"
                          >
                            https://www.assessit/test
                          </div>
                        </div>
                        <div className="col-12 col-md-3">
                          <div className={`${styles.copyRedio}`}>
                            <button className={`${styles.Copytext}`}>
                              <MdOutlineCopyAll /> Copy Link
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="row mt-2 mb-4">
                        <div className="col-12">
                          <div className={`${styles.emailContainer}`}>
                            <div className={`${styles.emailSelector}`}>
                              <textarea
                                className={`${styles.emailTextarea} form-control`}
                                style={{ width: "100%" }}
                                placeholder="Enter email ID to add"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedOption === "option3" && (
                    <div className={`${styles.specificRediobtn} mb-2`}>
                      {/* <label htmlFor="language">Text Language</label> */}
                      <select
                        id="language"
                        className={`${styles.redioSpecificbtn}`}
                      >
                        <option value="Select" disabled selected hidden>
                          Select
                        </option>
                        <option value="Development">
                          <input type="checkbox" className={styles.checkbox} />{" "}
                          Development
                        </option>
                        <option value="Infra">
                          <input type="checkbox" className={styles.checkbox} />{" "}
                          Infra
                        </option>
                        <option value="Hr">
                          <input type="checkbox" className={styles.checkbox} />{" "}
                          HR
                        </option>
                      </select>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className={`${styles.ContainerSett}`}>
              <div
                className={` ${styles.footer} d-grid grid-template-columns-auto gap-3`}
              >
                <div className={`${styles.PreviousButtonset}`}>
                  <button
                    className={`${styles.PreviousBtnset}`}
                    onClick={() => allQuestionPage("allquestion")}
                  >
                    Previous
                  </button>
                </div>

                <div>
                  <div className={`${styles.nextBtnnset}`}>
                    <button
                      className={`${styles.nextbuttonnset}`}
                      onClick={(e) => handlesubmit(e, "draft")}
                    >
                      Save as Draft
                    </button>
                  </div>
                </div>
                <div>
                  <div className={`${styles.nextBtnnoneset}`}>
                    <button
                      className={styles.nextbuttonnoneset}
                      onClick={(e) => handlesubmit(e, "publish")}
                    >
                      Save and Publish
                    </button>
                  </div>
                </div>
              </div>
            </div>
            {showPopup && (
              <div className={styles.popupContainer}>
                <div className={styles.popup}>
                  <div className={styles.circle}>
                    <Image src={success} alt="Success animation" />
                  </div>
                  <h3>Success</h3>
                  <p>Your assessment is successfully created.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};

export default Settings;
