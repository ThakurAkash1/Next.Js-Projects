"use client";
import React, { useState, useEffect } from "react";
import styles from "@/components/myassessment/ReceiveAllQuestions/styles.module.css";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { CallApi } from "@/utils/util";

interface ReceiveAllQuestionsProps {
  assessmentId: string;
}

const ReceiveAllQuestions: React.FC<ReceiveAllQuestionsProps> = ({
  assessmentId,
}) => {
  const [questions, setQuestions] = useState<any[]>([]);
  const [optionsData, setOptionsData] = useState<any>({});

  const Query = `
  query MyQuery2 {
    assessmentById(id: "${assessmentId}") {
      draftQuestions {
        questionType
        options {
          option
          weightage
        }
        question
        totalWeightage
      }
    }
  }
  `;
  useEffect(() => {
    console.log("asss", assessmentId);
    const fetchData = async () => {
      try {
        const response = await CallApi({ query: Query, token: "" });
        console.log("Response: ReceiveAllQuestions", response);

        const assessmentData = await response.data.assessmentById;
        // Check if assessmentData is defined and draftQuestions is not null or undefined
        if (
          assessmentData &&
          assessmentData.draftQuestions !== null &&
          assessmentData.draftQuestions !== undefined
        ) {
          const AllQuestions = assessmentData.draftQuestions;
          setQuestions(AllQuestions);
          console.log(
            "Assessment Data for all question page:ReceiveAllQuestions",
            AllQuestions
          );
        } else {
          console.error("Error: draftQuestions is null or undefined");
        }
      } catch (error) {
        console.error("Error:", error);
        // Handle errors gracefully
      }
    };

    if (Query) {
      // Check if both query and id are available
      fetchData();
    }
  }, [Query, assessmentId]);

  // Ensure that the 'optionsData' state is updated properly to contain options for each question

  return (
    <div>
      <div className={`${styles.AllQstTitle}`}>
        <div className={`${styles.PassdataCreate}`}>
          <div className="row">
            <div className="col">
              {questions.map((question: any, index: number) => (
                <div className={`${styles.AllQuestionBorder} mt-4`} key={index}>
                  <div className="row mt-4">
                    <div className={`col-6 ${styles.start}`}>
                      <div className={`${styles.questionscoreone}`}>
                        <label>Question {index + 1}</label>
                      </div>
                    </div>
                    <div className={`col-6 ${styles.end}`}>
                      <div className={`${styles.scoreContainer}`}>
                        <div className={`${styles.AllScore}`}>
                          Score: {question.totalWeightage}
                          <div className={`${styles.dots}`}>
                            <BiDotsVerticalRounded />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row mt-2">
                    <div className="col-12">
                      <label
                        htmlFor="assessmentName"
                        className={`${styles.boldLabel}`}
                      >
                        {question.question}
                      </label>
                    </div>
                  </div>
                  <div className="row mt-2">
                    {question.options.map(
                      (option: any, optionIndex: number) => (
                        <div
                          className="col-12 col-md-4 col-lg-3 col-xl-3"
                          key={optionIndex}
                        >
                          <div
                            className={`form-check form-check-inline ${styles.StateChoice}`}
                          >
                            {question.questionType !== "textual" && (
                            <input
                              className={`form-check-input form-check-lg ${styles.customCheckbox}`}
                              type="checkbox"
                              id={`checkbox${optionIndex}`}
                              // You might want to adjust how you handle the checked state based on your logic
                              defaultChecked={option.weightage > 0}
                            />
                            )}
                            <label
                              className={`form-check-label ${styles.labelCustom}`}
                              htmlFor={`checkbox${optionIndex}`}
                            >
                              {option.option}
                            </label>
                          </div>
                        </div>
                      )
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReceiveAllQuestions;
