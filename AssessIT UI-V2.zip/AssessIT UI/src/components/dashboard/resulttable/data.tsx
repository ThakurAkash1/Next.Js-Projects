export const dummyData: [string, number][] = [
    
  ];